
import React from 'react';
import ReactDOM from 'react-dom';

import { Router } from 'react-router-dom'
import { Provider } from 'mobx-react';
import Layout from './components/common/Layout';

import { RouterStore, syncHistoryWithStore } from 'mobx-react-router';
import AppStore from "./store/AppStore";
import ReportStore from "./store/ReportStore";
import QuestionStore from "./store/QuestionStore";
import ChannelStore from "./store/ChannelStore";
import VideoStore from "./store/VideoStore";
import UserStore from "./store/UserStore";
import StaticChannelStore from "./store/StaticChannelStore";
import RecommendedChannelStore from "./store/RecommendedChannelStore";



const browserHistory = require('history').createBrowserHistory();
const routingStore = new RouterStore();
const appStore = new AppStore();

const appStores = {
    routing: routingStore,
    app: appStore
};

const reportStore = new ReportStore()
const questionStore = new QuestionStore()
const channelStore = new ChannelStore()
const videoStore = new VideoStore()
const userStore = new UserStore()
const staticChannelStore = new StaticChannelStore()
const recommendedChannelStore = new RecommendedChannelStore()

const history = syncHistoryWithStore(browserHistory, routingStore);

import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

// Call it once in your app. At the root of your app is the best place
toast.configure()


ReactDOM.render(
    <Provider appStore={appStores}
              reportStore={reportStore}
              questionStore={questionStore}
              channelStore={channelStore}
              videoStore={videoStore}
              userStore={userStore}
              staticChannelStore={staticChannelStore}
              recommendedChannelStore={recommendedChannelStore}>

        <Router history={history}>

            <Layout/>

        </Router>

    </Provider>
    ,
    document.getElementById('app')
);