
import { observable,  action } from 'mobx'
import * as util from "../assets/js/util"
import { requestSearch } from '../action/SearchAction'
import {TABLE_CONST} from "../components/common/Const";
import {REPORT_STATUS, REPORT_TARGET} from "../components/report/ReportConst";


export default class ReportStore {

    @observable searchReportResults = []
    @observable searchResultPageSize = 0
    currentSearchParams = {}
    REQUEST_SIZE = TABLE_CONST.REPORT.DEFAULT_SIZE


    init() {
        this.searchReportResults = []
        this.searchResultPageSize = 0
        this.currentSearchParams = {}
    }

    @action
    async requestSearchReport(search_params) {
        console.log('requestSearchReport')
        console.log(search_params)

        this.searchReportResults = []
        this.searchResultPageSize = 0
        this.currentSearchParams = search_params

        return await this.requestSearchReportWithPage(0)
    }

    @action
    async requestSearchReportWithPage(page) {
        console.log('requestSearchReportWithPage')

        if (page < this.searchReportResults.length && this.searchReportResults[page] != null) {
            return {
                'isSuccess': true
            }
        }

        const search_params = this.currentSearchParams
        const from = page * this.REQUEST_SIZE

        let mustConditionList = [{
            "range": {
                "create_time": {
                    "gte": util.getTimeFromYmdt(search_params.start_ymd + " 00:00:00"),
                    "lte": util.getTimeFromYmdt(search_params.end_ymd + " 23:59:59")
                }
            }
        }]

        const status = search_params.report_status
        if (status != REPORT_STATUS.ALL) {
            mustConditionList.push({"match": {"status": REPORT_STATUS.PROPS[status].VALUE}})
        }
        const target = search_params.report_target
        if (target != REPORT_TARGET.ALL) {
            mustConditionList.push({"match": {"target": REPORT_TARGET.PROPS[target].VALUE}})
        }
        const targetKey = search_params.report_target_key
        if (targetKey.length > 0) {
            mustConditionList.push({"match": {"key": targetKey}})
        }
        const userId = search_params.report_user_id
        if (userId.length > 0) {
            mustConditionList.push({"match": {"uid": userId}})
        }

        console.log(mustConditionList)

        let res = await requestSearch('reports', mustConditionList, from, this.REQUEST_SIZE)
        this._setSearchResult(res)
        return res
    }

    _setSearchResult(res) {
        console.log('_setSearchResult')

        res.list.forEach((item) => {
            item.create_time = util.getYmdtFromTime(item.create_time)
            console.log(item)
        })

        console.log('response: ', res.list)
        this.searchReportResults.push(res.list)
        console.log('searchReportResult : ', this.searchReportResults)

        const totalPage = parseInt(res.totalCount / this.REQUEST_SIZE) + 1
        this.searchResultPageSize = totalPage
    }
}
