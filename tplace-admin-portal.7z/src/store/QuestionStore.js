
import { observable,  action } from 'mobx'
import * as util from "../assets/js/util"
import { requestSearch } from '../action/SearchAction'
import {QUESTION_STATUS, QUESTION_CATEGORY} from "../components/question/QuestionConst";
import {TABLE_CONST} from "../components/common/Const";


export default class QuestionStore {

    @observable searchQuestionResults = []
    @observable searchResultPageSize = 0
    currentSearchParams = {}
    REQUEST_SIZE = TABLE_CONST.QUESTION.DEFAULT_SIZE


    init() {
        this.searchQuestionResults = []
        this.searchResultPageSize = 0
        this.currentSearchParams = {}
    }

    @action
    async requestSearchQuestion(search_params) {
        console.log('requestSearchQuestion')
        console.log(search_params)

        this.searchQuestionResults = []
        this.searchResultPageSize = 0
        this.currentSearchParams = search_params

        return await this.requestSearchQuestionWithPage(0)
    }

    @action
    async requestSearchQuestionWithPage(page) {
        console.log('requestSearchQuestionWithPage')

        if (page < this.searchQuestionResults.length && this.searchQuestionResults[page] != null) {
            return {
                'isSuccess': true
            }
        }

        const search_params = this.currentSearchParams
        const from = page * this.REQUEST_SIZE

        let mustConditionList = [{
            "range": {
                "create_time": {
                    "gte": util.getTimeFromYmdt(search_params.start_ymd + " 00:00:00"),
                    "lte": util.getTimeFromYmdt(search_params.end_ymd + " 23:59:59")
                }
            }
        }]

        const status = search_params.question_status
        if (status != QUESTION_STATUS.ALL) {
            mustConditionList.push({"match": {"status": QUESTION_STATUS.PROPS[status].VALUE}})
        }
        const category = search_params.question_category
        if (category != QUESTION_CATEGORY.ALL) {
            mustConditionList.push({"match": {"category": QUESTION_CATEGORY.PROPS[category].VALUE}})
        }
        const userId = search_params.question_user_id
        if (userId.length > 0) {
            mustConditionList.push({"match": {"uid": userId}})
        }
        const userEmail = search_params.question_user_email
        if (userEmail.length > 0) {
            mustConditionList.push({"match": {"email": userEmail}})
        }

        console.log(mustConditionList)

        let res = await requestSearch('questions', mustConditionList, from, this.REQUEST_SIZE)
        this._setSearchResult(res)
        return res
    }

    _setSearchResult(res) {
        console.log('_setSearchResult')

        res.list.forEach((item) => {
            item.create_time = util.getYmdtFromTime(item.create_time)
            console.log(item)
        })

        console.log('response: ', res.list)
        this.searchQuestionResults.push(res.list)
        console.log('searchQuestionResults : ', this.searchQuestionResults)

        const totalPage = parseInt(res.totalCount / this.REQUEST_SIZE) + 1
        this.searchResultPageSize = totalPage
    }
}
