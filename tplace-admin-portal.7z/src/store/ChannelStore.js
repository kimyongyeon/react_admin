
import { observable,  action } from 'mobx'
import * as util from "../assets/js/util"
import {requestSearch} from '../action/SearchAction'
import {TABLE_CONST} from "../components/common/Const";


export default class ChannelStore {

    @observable searchChannelResults = []
    @observable searchResultPageSize = 0
    currentSearchParams = {}
    REQUEST_SIZE = TABLE_CONST.CHANNEL.DEFAULT_SIZE


    init() {
        this.searchChannelResults = []
        this.searchResultPageSize = 0
        this.currentSearchParams = {}
    }

    @action
    async requestSearchChannel(search_params) {
        console.log('requestSearchChannel')

        this.searchChannelResults = []
        this.searchResultPageSize = 0
        this.currentSearchParams = search_params

        return await this.requestSearchChannelWithPage(0)
    }

    @action
    async requestSearchChannelWithPage(page) {
        console.log('requestSearchChannelWithPage')

        if (page < this.searchChannelResults.length && this.searchChannelResults[page] != null) {
            return {
                'isSuccess': true
            }
        }

        const channelKey = this.currentSearchParams.channel_key
        const userId = this.currentSearchParams.user_id
        const title = this.currentSearchParams.title
        const from = page * this.REQUEST_SIZE

        if (channelKey.length > 0) {
            return await this._requestSearchUsingChannelKey(channelKey, from)

        }  else if (userId.length > 0) {
            return await this._requestSearchUsingUserId(userId, from)

        } else if (title.length > 0) {
            return await this._requestSearchUsingTitle(title, from)

        } else {
            return await this._requestSearchUsingDate(this.currentSearchParams, from)
        }
    }


    async _requestSearchUsingChannelKey(channelKey, from) {
        console.log('_requestSearchUsingChannelKey')

        let mustConditionList = {"match": {"channel_key": channelKey}}
        console.log(mustConditionList)

        let res = await requestSearch('channels', mustConditionList, from, this.REQUEST_SIZE)
        this._setSearchResult(res)
        return res
    }

    async _requestSearchUsingUserId(userId, from) {
        console.log('_requestSearchUsingUserId')

        let mustConditionList = {"match": {"uid": userId}}
        console.log(mustConditionList)

        let res = await requestSearch('channels', mustConditionList, from, this.REQUEST_SIZE)
        this._setSearchResult(res)
        return res
    }

    async _requestSearchUsingTitle(title, from) {
        console.log('_requestSearchUsingTitle')

        title = util.removeSpecialCharacters(title)

        let mustCondition = []
        let array = title.split(' ')
        array.forEach((string, index) => {
            let wildcard = {
                "wildcard" : {
                    'title.keyword': '*' + string + '*'
                }
            }
            mustCondition.push(wildcard)
        })

        let res = await requestSearch('channels', mustCondition, from, this.REQUEST_SIZE)
        this._setSearchResult(res)
        return res
    }

    async _requestSearchUsingDate(search_params, from) {
        console.log('_requestSearchUsingDate')
        let mustConditionList = [{
            "range": {
                "create_time": {
                    "gte": util.getTimeFromYmdt(search_params.start_ymd + " 00:00:00"),
                    "lte": util.getTimeFromYmdt(search_params.end_ymd + " 23:59:59")
                }
            }
        }]
        console.log(mustConditionList)

        let res = await requestSearch('channels', mustConditionList, from, this.REQUEST_SIZE)
        this._setSearchResult(res)
        return res
    }

    _setSearchResult(res) {
        console.log('_setSearchResult')
        res.list.forEach((item) => {
            item.create_time = util.getYmdtFromTime(item.create_time)
            console.log(item)
        })

        console.log('response: ', res.list)
        this.searchChannelResults.push(res.list)
        console.log('searchChannelResults : ', this.searchChannelResults)

        const totalPage = parseInt(res.totalCount / this.REQUEST_SIZE) + 1
        this.searchResultPageSize = totalPage
    }

}
