
import { observable,  action } from 'mobx'
import * as util from "../assets/js/util"
import { requestSearch } from '../action/SearchAction'
import {TABLE_CONST} from "../components/common/Const";
import {VIDEO_UNSAFE_LEVEL} from "../components/video/VideoConst";
import {store} from "../firebase";

export default class VideoStore {

    @observable searchVideoResult = []
    @observable searchResultPageSize = 0
    currentSearchParams = {}
    REQUEST_SIZE = TABLE_CONST.VIDEO.DEFAULT_SIZE

    init() {
        this.searchVideoResult = []
        this.searchResultPageSize = 0
        this.currentSearchParams = {}
    }

    @action
    async requestSearchVideo(search_params) {
        console.log('requestSearchVideo')

        this.searchVideoResult = []
        this.searchResultPageSize = 0
        this.currentSearchParams = search_params

        return await this.requestSearchVideoWithPage(0)
    }

    @action
    async requestSearchVideoWithPage(page) {
        console.log('requestSearchVideoWithPage')

        if (page < this.searchVideoResult.length && this.searchVideoResult[page] != null) {
            return {
                'isSuccess': true
            }
        }

        const videoKey = this.currentSearchParams.video_key
        const userId = this.currentSearchParams.user_id
        const title = this.currentSearchParams.title
        const tag = this.currentSearchParams.tag
        const unsafeLevel = this.currentSearchParams.unsafe_level
        const from = page * this.REQUEST_SIZE

        if (videoKey.length > 0) {
            return await this._requestSearchUsingVideoKey(videoKey, from)

        } else if (userId.length > 0) {
            return await this._requestSearchUsingUserId(userId, from)

        } else if (title.length > 0) {
            return await this._requestSearchUsingTitle(title, from)

        } else if (tag.length > 0) {
            return await this._requestSearchUsingTag(tag, from)

        } else if (unsafeLevel != VIDEO_UNSAFE_LEVEL.ALL) {
            return await this._requestSearchUsingUnsafeLevel(unsafeLevel, from)

        } else {
            return await this._requestSearchUsingDate(this.currentSearchParams, from)
        }
    }

    @action
    attachAddedVideoListener(lastCrateTime, callback){
        var query = store.collection('videos').orderBy('create_time','desc').where('create_time', '>', lastCrateTime);

        var observer = query.onSnapshot(querySnapshot => {
            console.log(`Received query snapshot of size ${querySnapshot.size}`);
            let list = [];
            querySnapshot.forEach((snap)=>{
                list.push(snap.data());
            })
            callback(list);
            // ...
        }, err => {
            console.log(`Encountered error: ${err}`);
        });
    }

    @action
    detachAddedVideoLinster(name){
        var unsub = store.collection('videos').onSnapshot(() => {});

        unsub();
    }

    async _requestSearchUsingVideoKey(videoKey, from) {
        console.log('_requestSearchUsingVideoKey')

        let mustConditionList = {"match": {"video_key": videoKey}}
        console.log(mustConditionList)

        let res = await requestSearch('videos', mustConditionList, from, this.REQUEST_SIZE)
        this._setSearchResult(res)
        return res
    }

    async _requestSearchUsingUserId(userId, from) {
        console.log('_requestSearchUsingUserId')

        let mustConditionList = {"match": {"uid": userId}}
        console.log(mustConditionList)

        let res = await requestSearch('videos', mustConditionList, from, this.REQUEST_SIZE)
        this._setSearchResult(res)
        return res
    }

    async _requestSearchUsingTitle(title, from) {
        console.log('_requestSearchUsingTitle')

        title = util.removeSpecialCharacters(title)

        let mustCondition = []
        let array = title.split(' ')
        array.forEach((string, index) => {
            let wildcard = {
                "wildcard" : {
                    'title.keyword': '*' + string + '*'
                }
            }
            mustCondition.push(wildcard)
        })

        let res = await requestSearch('videos', mustCondition, from, this.REQUEST_SIZE)
        this._setSearchResult(res)
        return res
    }

    async _requestSearchUsingTag(tag, from) {
        console.log('_requestSearchUsingTag')

        tag = util.removeSpecialCharacters(tag)

        let mustCondition = []
        let array = tag.split(' ')
        array.forEach((string, index) => {
            let wildcard = {
                "wildcard" : {
                    'tags.keyword': '*' + tag + '*'
                }
            }
            mustCondition.push(wildcard)
        })

        let res = await requestSearch('videos', mustCondition, from, this.REQUEST_SIZE)
        this._setSearchResult(res)
        return res
    }


    async _requestSearchUsingUnsafeLevel(unsafeLevel, from) {
        console.log('_requestSearchUsingUnsafeLevel')

        let mustConditionList = {"match": {"unsafe_level": unsafeLevel}}
        console.log(mustConditionList)

        let res = await requestSearch('videos', mustConditionList, from, this.REQUEST_SIZE)
        this._setSearchResult(res)
        return res
    }

    async _requestSearchUsingDate(search_params, from) {
        console.log('_requestSearchUsingDate')
        let mustConditionList = [{
            "range": {
                "create_time": {
                    "gte": util.getTimeFromYmdt(search_params.start_ymd + " 00:00:00"),
                    "lte": util.getTimeFromYmdt(search_params.end_ymd + " 23:59:59")
                }
            }
        }]
        console.log(mustConditionList)

        let res = await requestSearch('videos', mustConditionList, from, this.REQUEST_SIZE)
        this._setSearchResult(res)
        return res
    }




    _setSearchResult(res) {
        console.log('_setSearchResult')
        res.list.forEach((item) => {
            item.create_time = util.getYmdtFromTime(item.create_time)
            console.log(item)
        })

        console.log('response: ', res.list)
        this.searchVideoResult.push(res.list)
        console.log('searchVideoResults : ', this.searchVideoResult)

        const totalPage = parseInt(res.totalCount / this.REQUEST_SIZE) + 1
        this.searchResultPageSize = totalPage
    }
}
