
import { observable,  action } from 'mobx'
import {requestSearch} from "../action/SearchAction";
import {getMaxChunkNumber} from "../action/GetMaxChunkNumberAction";


export default class RecommendedChannelStore {

    @observable trashChunkResults = []
    @observable searchChunkResults = {}
    @observable searchChunkNumbers = []
    nextChunk = 0
    REQUEST_CHUNK_SIZE = 20
    TRASH_CHUNK_NUMBER = -1


    init() {
        this.trashChunkResults = []
        this.searchChunkResults = {}
        this.searchChunkNumbers = []
        this.nextChunk = 0
    }

    @action
    async requestSearchRecommendedChannel() {
        console.log('requestSearchRecommendedChannel')
        this.init()

        let response = await getMaxChunkNumber('channels')
        if (response.isSuccess && response.maxChunkNumber != null) {
            this.nextChunk = response.maxChunkNumber

            await this.requestSearchTrashChunkChannel()
            return await this.requestSearchMoreRecommendedChannel()
        } else {
            alert('maxChunk 를 조회하는데 실패하였습니다.')
        }
    }

    async requestSearchTrashChunkChannel() {
        let mustConditionList = {"match": {"chunk_num": -1}}
        console.log(mustConditionList)

        let res = await requestSearch('channels', mustConditionList, null, null)
        if (res.isSuccess) {
            console.log(res.list)
            this.trashChunkResults = res.list
        }
        return res
    }

    @action
    async requestSearchMoreRecommendedChannel() {
        let mustConditionList = {
            "range": {
                "chunk_num" : {
                    "gte" : (this.nextChunk - this.REQUEST_CHUNK_SIZE) > 0 ? (this.nextChunk - this.REQUEST_CHUNK_SIZE) : 0,
                    "lte" : this.nextChunk,
                }
            }
        }
        console.log(mustConditionList)

        let res = await requestSearch('channels', mustConditionList, null, null)
        if (res.isSuccess) {
            this._setSearchResult(res)
            this.nextChunk = this.nextChunk - this.REQUEST_CHUNK_SIZE - 1
        }
        return res
    }

    @action
    async requestSearchChunk(chunkNumber) {
        let mustConditionList = {
            "match": {
                "chunk_num" : chunkNumber
            }
        }
        console.log(mustConditionList)

        let res = await requestSearch('channels', mustConditionList, null, null)
        if (res.isSuccess) {
            if (chunkNumber == this.TRASH_CHUNK_NUMBER) {
                this.trashChunkResults = res.list
            } else {
                this._setSearchResult(res)
            }
        }
        return res
    }


    _setSearchResult(res) {
        console.log('_setSearchResult')
        console.log('response: ', res.list)

        let result = {}
        let numbers = []
        res.list.forEach((item) => {
            const chunkNumber = parseInt(item.chunk_num)

            if (result[chunkNumber] == null) {
                let array = [item]
                result[chunkNumber] = array
            } else {
                result[chunkNumber].push(item)
            }

            if (!numbers.includes(chunkNumber)) {
                numbers.push(chunkNumber)
            }
        })

        for (let key in result) {
            this.searchChunkResults[key] = result[key]
        }

        let sortedNumbers = numbers.sort((a, b) => b - a)
        sortedNumbers.forEach((value) => {
            if (!this.searchChunkNumbers.includes(value)) {
                this.searchChunkNumbers.push(value)
            }
        })

        console.log('searchChunkResults : ', this.searchChunkResults)
        console.log('searchChunkNumbers : ', this.searchChunkNumbers)
    }
}
