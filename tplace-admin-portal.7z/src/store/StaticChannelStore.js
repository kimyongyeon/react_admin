
import { observable,  action } from 'mobx'
import * as util from "../assets/js/util"
import {requestSearch} from "../action/SearchAction";
import {TABLE_CONST} from "../components/common/Const";
import {requestFunction} from "../action/FirebaseFunctionAction";


export default class StaticChannelStore {

    @observable staticChannelResults = []
    DEFAULT_SIZE = TABLE_CONST.STATIC_CHANNEL.DEFAULT_SIZE

    init() {
        this.staticChannelResults = []
    }

    @action
    async searchStaticChannel() {
        let mustConditionList = {"match": {"admin_pick": true}}
        console.log(mustConditionList)

        let res = await requestSearch('channels', mustConditionList, 0, this.DEFAULT_SIZE)

        res.list.forEach((item) => {
            item.pick_time = util.getYmdtFromTime(item.pick_time)
            console.log(item)
        })

        console.log('response: ', res.list)
        this.staticChannelResults = res.list

        console.log('staticChannelResults : ', this.staticChannelResults)
    }


    @action
    async addStaticChannel(key) {
        console.log('addStaticChannel : ', key)

        let param = {
            'channel_key': key,
            'admin_pick': true
        }
        return await requestFunction('updateChannelPick', param)
    }

    @action
    async removeStaticChannel(key) {
        console.log('removeStaticChannel : ', key)

        let param = {
            'channel_key': key,
            'admin_pick': false
        }
        return await requestFunction('updateChannelPick', param)
    }
}
