import {observable, action} from "mobx";
import {auth, authProvider} from "../firebase";
import {AUTH_CONST} from "../components/auth/AuthConst";
import { requestSearch } from '../action/SearchAction'

import {RET_CODE, PASSWORD_SALT} from '../common/constants';

const axios = require('axios');
const tplaceInstance = axios.create({
    baseURL: process.env.TPLACE_DOMAIN,
    timeout: 1000
});
const printf = require('printf');
const crypto = require('crypto');
const Cookies = require('js-cookie');
const COOKIE_TOKEN_KEY = 'tplace-token';
const jwt = require('jsonwebtoken')
import Inko from 'inko';
let inko = new Inko();


import { freeApi, authApi} from "../common/request";

export default class AppStore {
    @observable user = null;
    @observable authState = AUTH_CONST.STATE.NOT_DEFINED;
    @observable branchList = [];
    @observable menuList = [];
    @observable permission = {};
    @observable landingUrl = '';


    init() {
        this.user = null;
        this.authState = AUTH_CONST.STATE.NOT_LOGIN;
        this.branchList = [];
        this.menuList = [];
        this.permission = {};
        this.landingUrl = '';
        this.checkSeession();
    }

    checkSeession(){
        let token = Cookies.get(COOKIE_TOKEN_KEY);

        if(token) {
            this._checkToken()
        }
        else{
            this.authUser = null;
            this.authState = AUTH_CONST.STATE.NOT_LOGIN;
        }
    }

    @action
    requestBranchList(){
        this.branchList = [];
        freeApi('get','/admin/branch/list',{}).then((res)=>{this.onLoadBranchList(res)}).catch((err)=>{
            console.log(err);
        });

    }

    @action.bound
    onLoadBranchList(response){
        response.data.BRANCH_LIST.forEach((branch)=>{
            this.branchList.push(branch);
        })
        this.accessToken='abc';
    }

    @action
    requestSignUp(loginId, password, name, callback) {
        let salt = printf(PASSWORD_SALT, loginId);
        const hashedPassword = crypto.createHmac('sha256', salt)
            .update(password)
            .digest('hex');


        tplaceInstance.post('/admin/operator/signup',{
            LOGIN_ID:loginId,
            HASHED_PASSWORD:hashedPassword,
            NAME:name
        }).then((response)=>{
            callback(response.data.RET_CODE);
        }).catch((err)=>{
            let retCode = RET_CODE.ERROR;
            if(err.response.status === 403 && err.response.data && err.response.data.RET_CODE){
                retCode = err.response.data.RET_CODE;
            }

            callback(retCode);
        });

    }

    @action
    requestSignIn(loginId, password, branchId, callback) {
        let salt = printf(PASSWORD_SALT, loginId);
        const hashedPassword = crypto.createHmac('sha256', salt)
            .update(password)
            .digest('hex');
        //d38f23e23a094afbfbf78862441c4ec052e559fe72c9c3bda54d78d2d9871780
        //de4a79ec14c23dfba4862787f8814860e8a99b2d36691ea57ef296bef7acd55a
        console.log(`${branchId}, ${loginId},${salt}, ${password}, ${hashedPassword}`);
        freeApi('post','/admin/operator/signin',{
                LOGIN_ID:loginId,
                HASHED_PASSWORD:hashedPassword,
                BRANCH_ID:branchId
            }
        ).then((response)=>{
            this._onSignInComplete(response.data);
        }).catch((err)=>{
            let retCode = RET_CODE.ERROR;
            if(err.response && err.response.status === 403 && err.response.data && err.response.data.RET_CODE){
                retCode = err.response.data.RET_CODE;
            }

            callback(retCode);
        });
    }

    @action.bound
    _onSignInComplete(response){
        let token = response.ACCESS_TOKEN + '/' + response.REFRESH_TOKEN;
        Cookies.set(COOKIE_TOKEN_KEY, token);

        console.log(response);
        this._checkToken();
    }

    @action
    requestLogout() {
        authApi('post','/admin/operator/signout',{}, this._getAuth()).then((response)=>{
            this._cleanAuth();

        }).catch((err)=>{
            let retCode = RET_CODE.ERROR;
            if(err.response && err.response.status === 403 && err.response.data && err.response.data.RET_CODE){
                retCode = err.response.data.RET_CODE;
            }
            console.log(err);
        });
    }

    _getAuth(){
        let token = Cookies.get(COOKIE_TOKEN_KEY);
        let auth = null;
        if(token){
            let tokens = token.split('/');
            auth = {
                accessToken : tokens[0],
                refreshToken : tokens[1]
            };
        }
        return auth;
    }

    _cleanAuth(){
        this.user = null;
        this.authState = AUTH_CONST.STATE.NOT_LOGIN;
        Cookies.set(COOKIE_TOKEN_KEY, '');
    }

    @action
    _checkToken(){
        authApi('get','/admin/operator/my', {}, this._getAuth()).then((response)=>{
            this.user = response.data.OPERATOR;
            let decoded = jwt.decode(this._getAuth().accessToken);
            Object.assign(this.user, decoded);
            console.log(this.user);
            this.authState = AUTH_CONST.STATE.LOGIN
        }).catch((err)=>{
            this._cleanAuth();
        });
    }

    @action
    requestMenuList(serviceId) {
        authApi('get', `/admin/menu/my?SERVICE_ID=${serviceId}`,{}, this._getAuth()).then((response)=>{
            console.log(response.data);
            this._onCompleteRequestMenuList(response.data.MENU_LIST)
        }).catch((err)=>{
            console.log(err);
            this._onCompleteRequestMenuList([]);
        })

    }

    @action.bound
    _onCompleteRequestMenuList(list){
        let menus = [];
        while(list.length > 0){
            let menu = list.pop();
            if(menu.VISIBLE_YN ){
                if(menu.PARENT_MENU_ID === -1){
                    menus.push(menu);
                }
                else{
                    list.forEach((item)=>{
                        if(item.MENU_ID === menu.PARENT_MENU_ID){
                            if(item.CHILD_LIST){
                                item.CHILD_LIST.push(menu);
                            }
                            else{
                                item.CHILD_LIST = [menu];
                            }
                        }
                    });
                }

            }
            else{
                this.permission[menu.API] = menu;
            }
        }

        menus.sort((a,b)=>{
            return a.ORDER - b.ORDER;
        })

        this.menuList = menus;
    }

    @action
    setAdminPage(url) {
        this.landingUrl = url;
        console.log(this.landingUrl);
    }
}
