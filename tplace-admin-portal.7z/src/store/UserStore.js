
import { observable,  action } from 'mobx'
import * as util from "../assets/js/util"
import {requestSearch} from '../action/SearchAction'
import {TABLE_CONST} from "../components/common/Const";



export default class UserStore {

    @observable searchUserResult = []
    @observable searchResultPageSize = 0
    currentSearchParams = {}
    REQUEST_SIZE = TABLE_CONST.USER.DEFAULT_SIZE

    init() {
        this.searchUserResult = []
        this.searchResultPageSize = 0
        this.currentSearchParams = {}
    }

    @action
    async requestSearchUser(search_params) {
        console.log('requestSearchUser')

        this.searchUserResult = []
        this.searchResultPageSize = 0
        this.currentSearchParams = search_params

        return await this.requestSearchUserWithPage(0)
    }

    @action
    async requestSearchUserWithPage(page) {
        console.log('requestSearchUserWithPage')

        if (page < this.searchUserResult.length && this.searchUserResult[page] != null) {
            return {
                'isSuccess': true
            }
        }

        const userId = this.currentSearchParams.user_id
        const email = this.currentSearchParams.user_email
        const nickname = this.currentSearchParams.user_nickname
        const from = page * this.REQUEST_SIZE

        if (userId.length > 0) {
            return await this._requestSearchUsingUserId(userId, from)
        } else if (email.length > 0) {
            return await this._requestSearchUsingEmail(email, from)
        } else {
            return await this._requestSearchUsingNickname(nickname, from)
        }
    }


    async _requestSearchUsingUserId(userId, from) {
        console.log('_requestSearchUsingUserId')

        let mustConditionList = {"match": {"uid": userId}}
        console.log(mustConditionList)

        let res = await requestSearch('users', mustConditionList, from, this.REQUEST_SIZE)
        this._setSearchResult(res)
        return res
    }

    async _requestSearchUsingEmail(email, from) {
        console.log('_requestSearchUsingEmail')

        email = email.replace('@', ' ')

        let mustCondition = []
        let array = email.split(' ')
        array.forEach((string, index) => {
            let wildcard = {
                "wildcard" : {
                    'email': '*' + string + '*'
                }
            }
            mustCondition.push(wildcard)
        })

        let res = await requestSearch('users', mustCondition, from, this.REQUEST_SIZE)
        this._setSearchResult(res)
        return res
    }

    async _requestSearchUsingNickname(nickname, from) {
        console.log('_requestSearchUsingNickname')

        nickname = util.removeSpecialCharacters(nickname)

        let mustCondition = []
        let array = nickname.split(' ')
        array.forEach((string, index) => {
            let wildcard = {
                "wildcard" : {
                    'nickname.keyword': '*' + string + '*'
                }
            }
            mustCondition.push(wildcard)
        })

        let res = await requestSearch('users', mustCondition, from, this.REQUEST_SIZE)
        this._setSearchResult(res)
        return res
    }

    _setSearchResult(res) {
        console.log('_setSearchResult')
        res.list.forEach((item) => {
            item.create_time = util.getYmdtFromTime(item.create_time)
            console.log(item)
        })

        console.log('response: ', res.list)
        this.searchUserResult.push(res.list)
        console.log('searchVideoResults : ', this.searchUserResult)

        const totalPage = parseInt(res.totalCount / this.REQUEST_SIZE) + 1
        this.searchResultPageSize = totalPage
    }
}