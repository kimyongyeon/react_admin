const axios = require('axios');
const tplaceInstance = axios.create({
    baseURL: process.env.TPLACE_DOMAIN,
    timeout: 3000
});

export const freeApi = async (method, api, data) =>{
    return tplaceInstance.request({
        method:method,
        url:api,
        data:data,
    });
}

export const authApi = async (method, api, data, auth) =>{
    console.log(auth);
    const headers = {
        'x-access-token' : auth.accessToken
    };
    return tplaceInstance.request({
        method:method,
        headers:headers,
        url:api,
        data:data,
    });

}