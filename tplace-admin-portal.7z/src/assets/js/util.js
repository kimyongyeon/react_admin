


export function isDevelopment() {
  return process.env.IS_DEVELOPMENT == 1 ? true : false
}

export function checkYmd(startYMD, endYMD, range) {
  if (startYMD != '' && endYMD != '') {
    if (startYMD > endYMD) {
      alert("시작일은 종료일보다 작아야 합니다.")
      return false;
    }

    if ( range != null ) {
      var startDt = new Date(startYMD);
      var endDt = new Date(endYMD);
      if (endDt.getTime() - startDt.getTime() > 1000 * 60 * 60 * 24 * range) {
        alert("시작일과 종료일은 " + range + "일 이내 여야 합니다");
        return false;
      }
    }
  } else {
    alert("시작일 또는 종료일을 입력하세요.");
    return false;
  }
  return true;
}

export function getTimeFromYmdt(ymdt) {
  return new Date(ymdt).getTime();
}

export function getYmdtFromTime(time) {
  let d = new Date(time);
  return d.getFullYear().toString()
      + "-"
      + ((d.getMonth() + 1).toString().length == 2 ? (d.getMonth() + 1).toString() : "0" + (d.getMonth() + 1).toString())
      + "-"
      + (d.getDate().toString().length == 2 ? d.getDate().toString() : "0" + d.getDate().toString())
      + " "
      + (d.getHours().toString().length == 2 ? d.getHours().toString() : "0" + d.getHours().toString())
      + ":"
      + (d.getMinutes().toString().length == 2 ? d.getMinutes().toString() : "0" + d.getMinutes().toString())
      + ":"
      + (d.getSeconds().toString().length == 2 ? d.getSeconds().toString() : "0" + d.getSeconds().toString())
}

export function getYmd(date) {
  const d = date.getDate();
  const m = date.getMonth() + 1; //Month from 0 to 11
  const y = date.getFullYear();
  return '' + y + '-' + (m<=9 ? '0' + m : m) + '-' + (d <= 9 ? '0' + d : d);
}

export function getExtension(name) {
  return name.split('.').pop()
}

export function removeExtension(name) {
  return name.split('.').slice(0, -1).join('.')
}

export function replaceAll(str, searchStr, replaceStr) {
  return str.split(searchStr).join(replaceStr);
}


export function removeSpecialCharacters(string) {
  // 전체검색의 needs 가 있으므로 * 은 치환하지 않고, wildcard search 를 지원함.
  // (id 에 * 이 많이들어가있지 않다는 가정)
  // string = replaceAll(string, '*', '\\*')
  string = replaceAll(string, '?', '\\?')
  string = replaceAll(string, '+', '\\+')
  string = replaceAll(string, '|', '\\|')
  string = replaceAll(string, '.', '\\.')
  string = replaceAll(string, '^', '\\^')
  string = replaceAll(string, '$', '\\$')
  string = replaceAll(string, '&', '\\&')
  string = replaceAll(string, '_', '\\_')
  string = replaceAll(string, '-', '\\-')

  return string
}