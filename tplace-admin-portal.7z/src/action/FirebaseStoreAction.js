
import { store } from "../firebase";


export let requestSingleData = async function(name, key) {
    console.log('[requestSingleData]\nname : ' + name + '\nkey : ' + key)

    try {
        let snapshot = await store.collection(name).doc(key).get()
        console.log(snapshot)

        if (snapshot.exists) {
            return {
                'isSuccess' : true,
                'data' : snapshot.data()
            }
        } else {
            return {
                'isSuccess' : true,
                'data' : null
            }
        }
    } catch (error) {
        console.error(error)
        return {
            'isSuccess': false,
            'error': error
        }
    }
}


export let requestLastesData = async function(name){
    let querySnap = await store.collection(name).orderBy('create_time','desc').limit(1).get();
    console.log(querySnap.docs.length);

    if(querySnap.docs.length>0){
        let result = {};
        querySnap.forEach((item)=>{
            result = {
                isSuccess:true,
                data:item.data()
            }
        })
        return result;
    }

    return {
        isSuccess:false,
        error:'not exists'
    };
}


export let requestData = async function(name, field, operation, value, orderBy, orderDirection, limit) {
    console.log('[requestData]\nname : ' + name)
    if (field && field.length > 0 && operation && operation.length > 0 && value) {
        console.log('where: ' + field + operation + value)
    }
    if (orderBy && orderDirection) {
        console.log('orderBy: ' + orderBy + ' / direction: ' + orderDirection)
    }
    if (limit) {
        console.log('limit: ' + limit)
    }

    try {
        let ref = store.collection(name)
        if (field && field.length > 0 && operation && operation.length > 0 && value) {
            ref = ref.where(field, operation, value)
        }
        if (orderBy && orderBy.length > 0 && orderDirection && orderDirection.length > 0) {
            ref = ref.orderBy(orderBy, orderDirection)
        }
        if (limit != null) {
            ref = ref.limit(limit)
        }

        let snapshot = await ref.get()
        console.log(snapshot)

        let child = []
        snapshot.forEach((doc) => {
            console.log(doc)

            if (doc.exists) {
                const data = doc.data()
                data['id'] = doc.id
                console.log(data)
                child.push(data)
            }
        })

        console.log('[requestData] Result : ' + child)
        return {
            'isSuccess' : true,
            'list' : child
        }

    } catch (error) {
        console.error(error)
        return {
            'isSuccess': false,
            'error': error
        }
    }
}