
import { storage } from "../firebase";
import moment from "moment";


export let uploadFile = async function(name, file, metadata) {
    let ref = storage.ref()

    let currentTime = moment().format('YYYYMMDDhhmmss');
    let uploadName = currentTime + '_' + file.name

    let uploadRef = ref.child(name).child(uploadName)

    try {
        let res = await uploadRef.put(file, metadata)
        console.log(res)

        return {
            'isSuccess' : true,
            'data' : res
        }
    } catch (error) {
        console.error(error)
        return {
            'isSuccess' : false,
            'error' : error
        }
    }
}
