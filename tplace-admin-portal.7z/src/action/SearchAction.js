
import { functions } from "../firebase";


export let requestSearch = async function(index, mustConditionList, from, size) {
    let body = {
        "query": {
            "bool": {
                "must": mustConditionList
            }
        },
        "sort": {"create_time": {"order" : "desc"}}
    }
    if (from != null) {
        body["from"] = from
    } else {
        body["from"] = 0
    }
    if (size != null) {
        body["size"] = size
    } else {
        body["size"] = 1000
    }

    return await _requestSearch(index, body)
}


let _requestSearch = async function(index, body) {
    console.log('searchIndex: ', index);
    console.log('searchParam: ', JSON.stringify(body));

    try {
        let searchFunction = functions.httpsCallable('searchForAdmin')
        let response = await searchFunction({
            'index' : index,
            'searchBody' : body
        })

        console.log(response)

        let list = [];

        if (response.data == null) {
            return {
                isSuccess: true,
                list: list,
                totalCount: 0,
            }
        }

        response.data.hits.hits.forEach((doc, index)=>{
            list.push(doc._source);
        });

        return {
            isSuccess: true,
            list: list,
            totalCount: response.data.hits.total,
        }
    } catch (err) {
        console.error(err)
        return {
            isSuccess: false,
            error: err
        }
    }
}