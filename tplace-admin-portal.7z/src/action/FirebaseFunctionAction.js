
import { functions } from "../firebase";
import {FUNCTION_RESULT} from "./ActionConst";


export let requestFunction = async function(name, param) {
    console.log('[requestFunction]\nname : ' + name + '\nparam : ' + JSON.stringify(param))

    try {
        let response = await functions.httpsCallable(name)(param)
        console.log(response)

        if(response.data.result === FUNCTION_RESULT.SUCCESS) {
            return {
                'isSuccess': true,
                'data': response.data
            }
        } else {
            return {
                'isSuccess': false,
                'data': response.data
            }
        }

    } catch (err) {
        console.error(err)
        return {
            'isSuccess': false,
            'error': err
        }
    }
}
