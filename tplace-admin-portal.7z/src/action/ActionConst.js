

export const FUNCTION_RESULT = {
    SUCCESS: 0,
    FAILURE: 1,
}

