
import { functions } from "../firebase";


export let getMaxChunkNumber = async function(index) {
    let body = {
        "aggs": {
            "max_chunk_num": {
                "max": {
                    "field": "chunk_num"
                }
            }
        },
        "size": 0
    }
    return await _requestSearch(index, body)
}


let _requestSearch = async function(index, body) {
    console.log('searchIndex: ', index);
    console.log('searchParam: ', JSON.stringify(body));

    try {
        let searchFunction = functions.httpsCallable('searchForAdmin')
        let response = await searchFunction({
            'index' : index,
            'searchBody' : body
        })

        console.log(response)

        if (response != null && response.data != null && response.data.aggregations != null
        && response.data.aggregations.max_chunk_num != null && response.data.aggregations.max_chunk_num.value != null) {
            return {
                isSuccess: true,
                maxChunkNumber: response.data.aggregations.max_chunk_num.value
            }
        }

        return {
            isSuccess: false,
            maxChunkNumber: 0
        }

    } catch (err) {
        console.error(err)
        return {
            isSuccess: false,
            maxChunkNumber: 0
        }
    }
}