import React from "react";
import 'startbootstrap-sb-admin-2/css/sb-admin-2.css'

import {action} from 'mobx';

import {requestLastesData} from "../../action/FirebaseStoreAction";
import {inject, observer} from "mobx-react";
import Sound from 'react-sound';


@inject("videoStore") @observer
export default class VideoAlarm extends React.Component {

    constructor(props){
        super(props)
        console.log('[VideoTable] constructor');



        this.state = {
            currentNewVideo:0,
            newVideoCount: 1,
            soundStatus:Sound.status.STOPPED
        }
    }

    componentDidMount() {
        this._init();

    }

    componentWillUnmount() {
        this.props.videoStore.detachAddedVideoLinster();
    }

    async _init(){
        this.setState({
            currentNewVideo:0
        })

        this.props.videoStore.detachAddedVideoLinster();
        let latestVideo  = await requestLastesData('videos');
        let lastCreateTime = 0;
        if(latestVideo.isSuccess){
            lastCreateTime = latestVideo.data.create_time;
        }
        console.log(lastCreateTime);
        console.log(this.props.videoStore);
        this.props.videoStore.attachAddedVideoListener( lastCreateTime, this._onNewVideoAdded);

    }

    @action.bound
    _onNewVideoAdded(newVideos){
        console.log('new video');
        console.log(newVideos);
        if(newVideos.length > 0 && newVideos.length >= this.state.newVideoCount){
            console.log('alarm');
            //알림발생
            this.setState({
                soundStatus:Sound.status.PLAYING
            });

            this._init();
        }
        else{
            this.setState({
                currentNewVideo:newVideos.length
            })

        }
    }

    _onValueChanged(e) {
        console.log(e.target.value)

        this.setState({
            newVideoCount: parseInt(e.target.value)
        });

        this._init();

    }

    _soundFinishHanler(e){

        this.setState({
            soundStatus:Sound.status.STOPPED
        })
    }



    render() {

        let list = [1,2,3,4,5,6,7,8,9]
        return (
            <div className={"container-fluid"}>

                <h1 className="h3 mb-2 text-gray-800">
                    VideoAlarm
                </h1>


                <div className="card shadow mb-4">
                    <div className="collapse show" id="collapseCardExample">
                        <div className="card-body" id={'alarmContion'}>
                            <h6>새영상 알람 임계치</h6>
                            <div className="dropdown mb-4">
                                <button className="btn btn-light dropdown-toggle"
                                        type="button"
                                        id="dropdownMenuButton"
                                        data-toggle="dropdown"
                                        aria-haspopup="true"
                                        aria-expanded="false">
                                    {this.state.newVideoCount}
                                </button>
                                <div className="dropdown-menu animated--fade-in" aria-labelledby="dropdownMenuButton">
                                    {
                                        list.map((value)=>{
                                            return (
                                                <button className='dropdown-item' key={value}
                                                        name={'newVideoCount'}
                                                        value={value}
                                                        onClick={(e) => this._onValueChanged(e)}>{value}</button>
                                            );
                                        })
                                    }

                                </div>
                            </div>
                            <button className="btn btn-success btn-icon-split"
                                    onClick={() => {}}>
                                <span className="icon text-white-50">
                                  <i className="fas ">{'  ' + this.state.currentNewVideo}</i>
                                </span>
                                <span className="text">신규 영상 수</span>
                            </button>

                        </div>
                    </div>



                </div>

                <Sound
                    url="../../assets/img/siren.mp3"
                    playStatus={this.state.soundStatus}
                    onFinishedPlaying={()=>this._soundFinishHanler()}
                />

            </div>
        )
    }
}