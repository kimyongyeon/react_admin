

export const VIDEO_UNSAFE_LEVEL = {
    UNKNOWN: 0,
    VERY_UNLIKELY: 1,
    UNLIKELY: 2,
    POSSIBLE: 3,
    LIKELY: 4,
    VERY_LIKELY: 5,
    ALL: 1000,

    PROPS: {
        0: {
            NAME: '0',
            VALUE: 'UNKNOWN',
            STYLE: {
                color: 'red',
                fontWeight: 'bold'
            }
        },
        1: {
            NAME: '1',
            VALUE: 'VERY_UNLIKELY',
            STYLE: { }
        },
        2: {
            NAME: '2',
            VALUE: 'UNLIKELY',
            STYLE: { }
        },
        3: {
            NAME: '3',
            VALUE: 'POSSIBLE',
            STYLE: {
                color: '#eec358',
                fontWeight: 'bold'
            }
        },
        4: {
            NAME: '4',
            VALUE: 'LIKELY',
            STYLE: {
                color: '#d65544',
                fontWeight: 'bold'
            }
        },
        5: {
            NAME: '5',
            VALUE: 'VERY_LIKELY',
            STYLE: {
                color: '#d65544',
                fontWeight: 'bold'
            }
        },
        1000: {
            NAME: '전체',
            VALUE: 'ALL',
            STYLE: null
        }
    }
}


export let valueStringToLevel = function(string) {
    for(let key in VIDEO_UNSAFE_LEVEL.PROPS) {
        const prop = VIDEO_UNSAFE_LEVEL.PROPS[key]
        if (prop.VALUE === string) {
            return key
        }
    }
    return null
}