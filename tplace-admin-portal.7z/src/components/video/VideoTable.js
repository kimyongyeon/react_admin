
import React from "react";
import {inject, observer} from "mobx-react";
import ReactTable from "react-table";
import 'react-table/react-table.css'
import 'startbootstrap-sb-admin-2/css/sb-admin-2.css'

import ContentAdmin from "../channel/ContentAdmin";
import ReactPlayer from "react-player";
import {CONTENTS_CONST} from "../channel/ContentConst";
import {TABLE_CONST} from "../common/Const";
import VideoInfo from "./VideoInfo";
import {VIDEO_UNSAFE_LEVEL} from "./VideoConst";



@inject("videoStore") @observer
export default class VideoTable extends React.Component {

    constructor(props){
        super(props)
        console.log('[VideoTable] constructor')

        this.state = {
            currentPage: 0,
            isNextPageLoading: false,
        }
    }

    async _requestSearch(pageIndex) {
        this.setState({
            isNextPageLoading: true
        })
        let res = await this.props.videoStore.requestSearchVideoWithPage(pageIndex)
        this.setState({
            isNextPageLoading: false
        })

        if (res.isSuccess) {
            this.setState({
                currentPage: pageIndex
            })
        } else {
            alert('조회를 실패하였습니다. \ndata: ' + JSON.stringify(res.data) + '\nerror: ', JSON.stringify(res.error))
        }
    }

    render() {
        console.log('[VideoTable] render')

        const videoStore = this.props.videoStore
        console.log('currentPage: ', this.state.currentPage)

        let data = []
        if (this.state.currentPage < videoStore.searchVideoResult.length) {
            data = videoStore.searchVideoResult[this.state.currentPage]

        } else if (this.state.currentPage > 0) {
            //result 값은 초기화되었고 currentPage 는 아니라면 0 으로 초기화해준다.
            this.setState({
                currentPage: 0
            })
        }

        console.log(data)

        return (
            <ReactTable
                manual
                data={data}
                columns={[
                    {
                        expander: true
                    },
                    {
                        Header: "생성 시간",
                        id: "createTime",
                        accessor: d => d.create_time
                    },
                    {
                        Header: "생성자",
                        id: "userId",
                        accessor: d => (d.creator.nickname != null) ? d.creator.nickname : ""
                    },
                    {
                        Header: "컨텐츠Key",
                        id: "key",
                        accessor: d => d.video_key
                    },
                    {
                        Header: "타이틀",
                        id: "title",
                        Cell : row => (<span title={row.value}>{row.value}</span>),
                        accessor: d => d.title
                    },
                    {
                        Header: "해시태그",
                        id: "hashtag",
                        Cell : row => (<span title={row.value}>{row.value}</span>),
                        accessor: d => d.tags
                    },
                    {
                        Header: "유해성 단계",
                        id: "unsafeLevel",
                        width: 100,
                        Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                        accessor: d => ( (d.unsafe_level != null) ? <p style={VIDEO_UNSAFE_LEVEL.PROPS[d.unsafe_level].STYLE}>{d.unsafe_level}</p> : null )
                    },
                    {
                        Header: "Thumbnail",
                        id: "thumbnail",
                        accessor: (d) => <img src={d.preview_url}
                                              style={{
                                                  width: 200,
                                              }}/>
                    },
                    {
                        Header: "동영상 재생",
                        id: "contents",
                        accessor: (video) =>
                        <ReactPlayer controls
                                     light
                                     url={video.video_url}
                                     width={200}
                                     height={200}
                        />
                    }
                ]}
                className = { "-striped -highlight" }
                defaultSorted={ [
                    { id: "createTime", desc: false }
                ] }
                collapseOnSortingChange={ false }
                SubComponent={row => {
                    const rowData = data[row.index]
                    return (
                        <div>
                            <VideoInfo videoInfo={rowData} />

                            <ContentAdmin  contentType={CONTENTS_CONST.REPORT_TARGET.VIDEO}
                                           contentKey={rowData.video_key} />
                        </div>
                    );
                }}
                showPageSizeOptions = {false}
                showPageJump = { false }
                defaultPageSize={ TABLE_CONST.VIDEO.DEFAULT_SIZE }
                page={ this.state.currentPage }
                pages={ videoStore.searchResultPageSize }
                loading={ this.state.isNextPageLoading }
                onPageChange={(pageIndex) => {
                    console.log('onPageChange: ' + this.state.currentPage + '-> ' + pageIndex)
                    this._requestSearch(pageIndex)
                }}
            />
        )
    }
}
