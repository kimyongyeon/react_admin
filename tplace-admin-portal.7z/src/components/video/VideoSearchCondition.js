import React from "react";
import {inject, observer} from "mobx-react";
import DevTools from 'mobx-react-devtools';

import 'react-datepicker/dist/react-datepicker.min.css'
import 'react-datepicker/dist/react-datepicker-cssmodules.min.css'
import DatePicker from "react-datepicker/es";
import moment from "moment";
import {REPORT_STATUS} from "../report/ReportConst";
import {VIDEO_UNSAFE_LEVEL} from "./VideoConst";
import {getYmd} from "../../assets/js/util";



@inject("videoStore") @observer
export default class VideoSearchCondition extends React.Component {

    timerId = null
    //1분에 한번씩 refresh
    AUTO_REFRESH_EXPIRE_SEC = 60


    constructor(props){
        super(props)

        console.log('[VideoSearchCondition] constructor')

        const yesterday = new Date()
        yesterday.setDate(yesterday.getDate() - 1)

        this.state = {
            startDate: yesterday,
            endDate: new Date(),
            videoKey: '',
            userId: '',
            title: '',
            tag: '',
            unsafeLevel: VIDEO_UNSAFE_LEVEL.ALL,
            isSearching: false,
            isAutoRefresh: false,
            autoRefreshExpireSec: this.AUTO_REFRESH_EXPIRE_SEC
        };

        this.onEnterKeyPressed = this.onEnterKeyPressed.bind(this)
    }

    componentDidMount() {
        document.querySelector('#userInfo').addEventListener('keypress', this.onEnterKeyPressed)

        //최초 진입 시 기본 최신 날짜 검색
        this._onSearchButtonClicked()
    }

    componentWillUnmount() {
        document.querySelector('#userInfo').removeEventListener('keypress', this.onEnterKeyPressed)

        this._stopAutoRefresh()
        this.setState({
            isAutoRefresh: false
        })
    }

    onEnterKeyPressed(e) {
        let key = e.which || e.keyCode;
        if (key === 13) {
            this._onSearchButtonClicked()
        }
    }



    _onStartDateChanged(value) {
        this.setState({
            startDate: value
        })
    }

    _onEndDateChanged(value) {
        this.setState({
            endDate: value
        })
    }

    _onValueChanged(e) {
        console.log(e.target.value)

        this.setState({
            [e.target.name]: e.target.value
        })

        console.log(this.state)
    }

    async _onSearchButtonClicked() {
        if (!this.state.startDate || !this.state.endDate) {
            alert('날짜를 재설정해주세요')
            return
        }

        const start_ymd = getYmd(this.state.startDate)
        const end_ymd = getYmd(this.state.endDate)

        console.log('startDate: ', start_ymd)
        console.log('endDate: ', end_ymd)

        if (moment(end_ymd) - moment(start_ymd) < 0) {
            alert('시작날짜가 종료날짜보다 큽니다. 날짜를 재설정해주세요')
            return
        }


        const isUserIdExist = this.state.userId.length > 0
        const isTitleExist = this.state.title.length > 0
        const isUnsafeLevelExist = this.state.unsafeLevel != VIDEO_UNSAFE_LEVEL.ALL

        const exists = [isUserIdExist, isTitleExist, isUnsafeLevelExist].filter((v) => {
            return v
        })
        if (exists.length > 1 ) {
            alert('userId, 영상 이름, 태그 검색, 유해성 단계 중 하나의 조건만 설정가능합니다.')
            return
        }

        this.setState({
            isSearching: true
        })

        await this.props.videoStore.requestSearchVideo({
            start_ymd : start_ymd,
            end_ymd : end_ymd,
            video_key: this.state.videoKey,
            user_id: this.state.userId,
            title: this.state.title,
            tag: this.state.tag,
            unsafe_level: this.state.unsafeLevel
        })

        this.setState({
            isSearching: false
        })
    }

    _onAutoRefreshButtonClicked() {
        const tobeAutoRefresh = !this.state.isAutoRefresh
        if (tobeAutoRefresh) {
            this._startAutoRefresh()
        } else {
            this._stopAutoRefresh()
        }

        this.setState({
            isAutoRefresh: tobeAutoRefresh
        })
    }

    _startAutoRefresh() {
        console.log('start auto refresh')

        this.timerId = setInterval(() => {

            const remainSec = this.state.autoRefreshExpireSec - 1

            this.setState({
                autoRefreshExpireSec : remainSec
            })

            if (remainSec < 1) {
                this.setState({
                    autoRefreshExpireSec : this.AUTO_REFRESH_EXPIRE_SEC
                })

                const current = new Date()
                if (this.state.endDate.getDate() != current.getDate()) {
                    console.log('date changed!')

                    const yesterday = new Date()
                    yesterday.setDate(yesterday.getDate() - 1)

                    this.setState({
                        startDate: yesterday,
                        endDate: current
                    })
                }
                
                this._onSearchButtonClicked()
            }

        }, 1000)
    }

    _stopAutoRefresh() {
        console.log('stop auto refresh')
        if (this.timerId != null) {
            console.log(this.timerId)
            clearInterval(this.timerId)
        }
        this.setState({
            autoRefreshExpireSec : this.AUTO_REFRESH_EXPIRE_SEC
        })
    }


    render() {
        console.log('[VideoSearchCondition] render')

        return (
            <div>
                <a href="#collapseCardExample"
                   className="d-block card-header py-3"
                   data-toggle="collapse"
                   role="button"
                   aria-expanded="true"
                   aria-controls="collapseCardExample">
                    <h6 className="m-0 font-weight-bold text-primary">Search Condition</h6>
                </a>


                {/*Card Content - Collapse*/}
                <div className="collapse show" id="collapseCardExample">
                    <div className="card-body" id={'userInfo'}>


                    <h6>생성날짜</h6>
                        <DatePicker selected={this.state.startDate}
                                    dateFormat="YYYY-MM-dd"
                                    onChange={(v) => this._onStartDateChanged(v)} />
                        ~
                        <DatePicker selected={this.state.endDate}
                                    dateFormat="YYYY-MM-dd"
                                    onChange={(v) => this._onEndDateChanged(v)} />
                        <br/><br/>

                        <h6>Video Key</h6>
                        <input type="text"
                               className="form-control form-control-user"
                               placeholder="Enter Video Key"
                               name={'videoKey'}
                               onChange={(e) => this._onValueChanged(e)} />
                        <br/>

                        <h6>생성자 UserId</h6>
                        <input type="text"
                               className="form-control form-control-user"
                               placeholder="Enter User Id"
                               name={'userId'}
                               onChange={(e) => this._onValueChanged(e)} />
                        <br/>


                        <h6>영상 이름</h6>
                        <input type="text"
                               className="form-control form-control-user"
                               placeholder="Enter Title"
                               name={'title'}
                               onChange={(e) => this._onValueChanged(e)} />
                        <br/>


                        <h6>태그 검색</h6>
                        <input type="text"
                               className="form-control form-control-user"
                               placeholder="Enter Tag"
                               name={'tag'}
                               onChange={(e) => this._onValueChanged(e)} />
                        <br/>


                        <h6>유해성 단계</h6>
                        <div className="dropdown mb-4">
                            <button className="btn btn-light dropdown-toggle"
                                    type="button"
                                    id="dropdownMenuButton"
                                    data-toggle="dropdown"
                                    aria-haspopup="true"
                                    aria-expanded="false">
                                {VIDEO_UNSAFE_LEVEL.PROPS[this.state.unsafeLevel].NAME}
                            </button>
                            <div className="dropdown-menu animated--fade-in" aria-labelledby="dropdownMenuButton">
                                <button className='dropdown-item'
                                        name={'unsafeLevel'}
                                        value={VIDEO_UNSAFE_LEVEL.ALL}
                                        onClick={(e) => this._onValueChanged(e)}>{VIDEO_UNSAFE_LEVEL.PROPS[VIDEO_UNSAFE_LEVEL.ALL].NAME}</button>
                                <button className='dropdown-item'
                                        name={'unsafeLevel'}
                                        value={VIDEO_UNSAFE_LEVEL.UNKNOWN}
                                        onClick={(e) => this._onValueChanged(e)}>{VIDEO_UNSAFE_LEVEL.PROPS[VIDEO_UNSAFE_LEVEL.UNKNOWN].NAME}</button>
                                <button className='dropdown-item'
                                        name={'unsafeLevel'}
                                        value={VIDEO_UNSAFE_LEVEL.VERY_UNLIKELY}
                                        onClick={(e) => this._onValueChanged(e)}>{VIDEO_UNSAFE_LEVEL.PROPS[VIDEO_UNSAFE_LEVEL.VERY_UNLIKELY].NAME}</button>
                                <button className='dropdown-item'
                                        name={'unsafeLevel'}
                                        value={VIDEO_UNSAFE_LEVEL.UNLIKELY}
                                        onClick={(e) => this._onValueChanged(e)}>{VIDEO_UNSAFE_LEVEL.PROPS[VIDEO_UNSAFE_LEVEL.UNLIKELY].NAME}</button>
                                <button className='dropdown-item'
                                        name={'unsafeLevel'}
                                        value={VIDEO_UNSAFE_LEVEL.POSSIBLE}
                                        onClick={(e) => this._onValueChanged(e)}>{VIDEO_UNSAFE_LEVEL.PROPS[VIDEO_UNSAFE_LEVEL.POSSIBLE].NAME}</button>
                                <button className='dropdown-item'
                                        name={'unsafeLevel'}
                                        value={VIDEO_UNSAFE_LEVEL.LIKELY}
                                        onClick={(e) => this._onValueChanged(e)}>{VIDEO_UNSAFE_LEVEL.PROPS[VIDEO_UNSAFE_LEVEL.LIKELY].NAME}</button>
                                <button className='dropdown-item'
                                        name={'unsafeLevel'}
                                        value={VIDEO_UNSAFE_LEVEL.VERY_LIKELY}
                                        onClick={(e) => this._onValueChanged(e)}>{VIDEO_UNSAFE_LEVEL.PROPS[VIDEO_UNSAFE_LEVEL.VERY_LIKELY].NAME}</button>
                            </div>
                        </div>



                        {/*Search*/}
                        {
                            this.state.isSearching ? (
                                <div className="text-right">
                                    Searching...
                                </div>
                            ) : (
                                <div className="text-right">
                                    <button className={'btn btn-primary btn-icon-split btn'}
                                            onClick={() => this._onSearchButtonClicked()}>
                            <span className="icon text-white-50">
                                <i className="fas fa-arrow-right"></i>
                            </span>
                                        <span className="text">Search</span>
                                    </button>
                                </div>
                            )
                        }


                        {/*자동갱신*/}
                        {
                            this.state.isAutoRefresh ? (
                                <div className="text-right">
                                    <br/>

                                    <button className="btn btn-success btn-icon-split"
                                            onClick={() => this._onAutoRefreshButtonClicked()}>
                    <span className="icon text-white-50">
                      <i className="fas fa-sync-alt">{'  ' + this.state.autoRefreshExpireSec}</i>
                    </span>
                                        <span className="text">AutoRefresh ON</span>
                                    </button>
                                </div>
                            ) : (
                                <div className="text-right">
                                    <br/>
                                    <button className="btn btn-light btn-icon-split"
                                            onClick={() => this._onAutoRefreshButtonClicked()}>
                    <span className="icon text-gray-600">
                      <i className="fas fa-check"></i>
                    </span>
                                        <span className="text">AutoRefresh OFF</span>
                                    </button>
                                </div>
                            )
                        }


                    </div>
                </div>
                {process.env.NODE_ENV === 'development' && <DevTools />}
            </div>
        );
    }
}

