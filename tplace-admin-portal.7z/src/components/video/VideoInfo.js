import React from "react";
import {requestSingleData} from "../../action/FirebaseStoreAction";
import FlexView from "react-flexview/lib/FlexView";
import ReactPlayer from "react-player";
import {VIDEO_UNSAFE_LEVEL, valueStringToLevel} from "./VideoConst";
import ReactTable from "react-table";
import {TABLE_CONST} from "../common/Const";



export default class VideoInfo extends React.Component {

    constructor(props) {
        super(props)

        console.log('[VideoInfo] constructor')

        this.state = {
            isRequesting: false,
            videoInfo: this.props.videoInfo
        }
    }

    showProgress() {
        this.setState({
            isRequesting: true
        })
    }

    hideProgress() {
        this.setState({
            isRequesting: false
        })
    }

    manageRequestFailCase(message) {
        this.hideProgress()
        alert(message)
    }

    async _requestVideoInfo() {
        const videoKey = this.props.videoKey

        let mustConditionList = {"match": {"video_key": videoKey}}
        console.log(mustConditionList)


        this.showProgress()
        let res = await requestSingleData('videos', videoKey)
        if (res.isSuccess && res.data == null) {
            this.manageRequestFailCase('삭제된 영상입니다.')
            return
        }
        if (res.isSuccess == false) {
            this.manageRequestFailCase('영상 조회에 실패하였습니다.' + '\nerror: ', JSON.stringify(res.error))
            return
        }

        this.hideProgress()
        this.setState({
            videoInfo: res.data
        })
    }

    render() {
        console.log('[VideoInfo] render')

        let info = this.state.videoInfo
        console.log('[VideoInfo] render data: ', info)

        let safeSearchInfo = []
        if (info != null && info.safe_search_info != null) {
            const array = info.safe_search_info
            array.forEach((item, i) => {
                item.frame = i
                safeSearchInfo.push(item)
            })
        }
        console.log(safeSearchInfo)


        return (
            <div style={{padding: "20px"}}>
                <h5>영상 정보</h5>

                <div className="card mb-4 py-3 border-left-primary">

                    {
                        (info == null) ? (
                            <div className={'card-body'}>
                                {
                                    this.state.isRequesting ? (
                                        <div>
                                            Requesting...
                                        </div>
                                    ) : (
                                        <button className={"btn btn-primary btn-icon-split btn"}
                                                onClick={() => this._requestVideoInfo()} >
                                            <span className="text">정보 조회하기</span>
                                        </button>
                                    )
                                }
                            </div>
                        ) : (
                            <div className="card-body">

                                <FlexView grow={1}>
                                    <FlexView width={300}>
                                        <ReactPlayer controls
                                                     url={info.video_url}
                                                     poster={info.preview_url}
                                                     width={300}
                                                     height={300} />
                                    </FlexView>


                                    <FlexView column
                                              marginLeft={30}
                                              grow={1}>

                                        <div>
                                            <strong>타이틀</strong> - {info.title}
                                        </div>
                                        <div>
                                            <strong>해시태그</strong> - {info.tags}
                                        </div>
                                        <div>
                                            <strong>생성시간</strong> - {info.create_time}
                                        </div>


                                        <br/>


                                        <div>
                                            <strong>Creator ID</strong> - {info.creator.uid}
                                        </div>
                                        <div>
                                            <strong>Creator Nickname</strong> - {info.creator.nickname}
                                        </div>
                                        <div>
                                            <strong>Creator Image</strong> - {
                                            (
                                                <img className="img-profile rounded-circle"
                                                     src={ info.creator.image_url.length > 0 ? info.creator.image_url : 'assets/img/image_profile_no_profile.png' }
                                                     style={{width:'50px', height:'50px'}}
                                                />
                                            )
                                        }
                                        </div>


                                        <br/>


                                        <div>
                                            <strong>Video Width</strong> - {info.metadata.width}
                                        </div>
                                        <div>
                                            <strong>Video Height</strong> - {info.metadata.height}
                                        </div>
                                        <div>
                                            <strong>Video Rotation</strong> - {info.metadata.rotation}
                                        </div>
                                        <div>
                                            <strong>Video Duration</strong> - {info.metadata.duration}
                                        </div>


                                        <br/>


                                        <div>
                                            <strong>차단 상태</strong> - {
                                            info.censorship ? (
                                                <strong style={{color: '#d65544', fontSize: 23}}>차단됨</strong>
                                            ) : (
                                                <strong style={{color: '#41c989', fontSize: 23}}>차단되지 않음</strong>
                                            )
                                        }
                                        </div>


                                        <div>
                                            <strong>신고 개수</strong> - {info.report_count}
                                        </div>
                                        <br/>



                                        <div>
                                            <strong>유해성 단계</strong>
                                            {(info.unsafe_level != null) ? <p style={VIDEO_UNSAFE_LEVEL.PROPS[info.unsafe_level].STYLE}>{info.unsafe_level}</p> : null}
                                        </div>
                                        <div>
                                            <strong>유해성 판단 사유</strong>
                                            {(info.unsafe_reason != null) ? <p style={VIDEO_UNSAFE_LEVEL.PROPS[info.unsafe_level].STYLE}>{info.unsafe_reason}</p> : null}
                                        </div>
                                        <div>
                                            <strong>유해성 정보</strong><br/>
                                            {(safeSearchInfo != null) ? (
                                                <ReactTable
                                                    data={safeSearchInfo}
                                                    columns={[
                                                        {
                                                            Header: "Frame",
                                                            id: "frame",
                                                            width: 70,
                                                            Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                                                            accessor: d => d.frame
                                                        },
                                                        {
                                                            Header: "Adult(노출)",
                                                            id: "adult",
                                                            Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                                                            accessor: d => <p style={VIDEO_UNSAFE_LEVEL.PROPS[valueStringToLevel(d.adult)].STYLE}>{valueStringToLevel(d.adult)}</p>
                                                        },
                                                        {
                                                            Header: "Medical(수술)",
                                                            id: "medical",
                                                            Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                                                            accessor: d => <p style={VIDEO_UNSAFE_LEVEL.PROPS[valueStringToLevel(d.medical)].STYLE}>{valueStringToLevel(d.medical)}</p>
                                                        },
                                                        {
                                                            Header: "Racy(음란)",
                                                            id: "racy",
                                                            Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                                                            accessor: d => <p style={VIDEO_UNSAFE_LEVEL.PROPS[valueStringToLevel(d.racy)].STYLE}>{valueStringToLevel(d.racy)}</p>
                                                        },
                                                        {
                                                            Header: "Spoof(불쾌)",
                                                            id: "spoof",
                                                            Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                                                            accessor: d => <p style={VIDEO_UNSAFE_LEVEL.PROPS[valueStringToLevel(d.spoof)].STYLE}>{valueStringToLevel(d.spoof)}</p>
                                                        },
                                                        {
                                                            Header: "Violence(폭력)",
                                                            id: "violence",
                                                            Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                                                            accessor: d => <p style={VIDEO_UNSAFE_LEVEL.PROPS[valueStringToLevel(d.violence)].STYLE}>{valueStringToLevel(d.violence)}</p>
                                                        }
                                                    ]}
                                                    className = { "-striped -highlight" }
                                                    defaultSorted={ [
                                                        { id: "frame", desc: true }
                                                    ] }
                                                    collapseOnSortingChange={ false }
                                                    defaultPageSize={ TABLE_CONST.VIDEO.DEFAULT_SIZE }
                                                />
                                            ) : null}
                                        </div>

                                        <br/>


                                        <div>
                                            <strong>좋아요 수</strong> - {info.like_count}
                                        </div>

                                        <div>
                                            <strong>링크 수</strong> - {info.link_count}
                                        </div>

                                        <div>
                                            <strong>댓글 개수</strong> - {info.comment_count}
                                        </div>

                                        <div>
                                            <strong>시청 시간</strong> - {info.play_amount}
                                        </div>

                                        <div>
                                            <strong>태그</strong> - {info.tags}
                                        </div>


                                    </FlexView>
                                </FlexView>

                            </div>

                        )
                    }
                </div>
            </div>

        );

    }
}