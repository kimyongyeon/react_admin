
import React from "react";
import 'startbootstrap-sb-admin-2/css/sb-admin-2.css'
import {inject, observer} from "mobx-react";
import FlexView from "react-flexview/lib/FlexView";
import {getYmd, getTimeFromYmdt, getYmdtFromTime} from "../../assets/js/util"
import {requestData} from "../../action/FirebaseStoreAction";
import MornitoringQuestionGadget from "./MornitoringQuestionGadget";
import MornitoringVideoGadget from "./MornitoringVideoGadget";
import MornitoringChannelGadget from "./MornitoringChannelGadget";
import MornitoringReportGadget from "./MornitoringReportGadget";
import {HashLoader} from "react-spinners";
import {store} from "../../firebase";
import Sound from "react-sound";



@inject("reportStore", "questionStore", "channelStore", "videoStore") @observer
export default class MornitoringDashboard extends React.Component {

    keyToObservers = {}
    //10분에 한번씩 refresh
    AUTO_REFRESH_EXPIRE_SEC = 60 * 10


    constructor(props){
        super(props)

        this.state = {
            isReportRequesting: false,
            isQuestionRequesting: false,
            isChannelRequesting: false,
            isVideoRequesting: false,

            reports: [],
            questions: [],
            channels: [],
            videos: [],

            isReportChanged: false,
            isQuestionChanged: false,
            isChannelChanged: false,
            isVideoChanged: false,

            soundStatus:Sound.status.STOPPED,

            isAutoRefresh: false,
            autoRefreshExpireSec: this.AUTO_REFRESH_EXPIRE_SEC
        }
    }

    componentDidMount() {
        this.searchAll()
    }

    componentWillUnmount() {
        this.unregisterAllObserver()
    }


    //MARK:- Search
    async searchAll() {
        await this.searchReports()
        await this.searchQuestions()
        await this.searchChannels()
        await this.searchVideos()
    }

    async searchReports() {
        this.setState({
            isReportRequesting: true
        })
        let reportResponse = await this.searchContents('reports')
        if (reportResponse && reportResponse.isSuccess) {
            console.log('reports get success! : ' + reportResponse.list.length)
            this.setState({
                reports: reportResponse.list
            })
        }
        this.setState({
            isReportRequesting: false
        })

        let recentReportCreateTime = this.recentCreateTime(this.state.reports)
        let baseReportCheckTime = (recentReportCreateTime == 0) ? this.yesterdayTime() : recentReportCreateTime
        this.registerObserver("reports", baseReportCheckTime, (list) => {
            if (list.length > 0) {
                console.log('[report] observer work!')
                this.raiseAlarm()
                this.setState({
                    isReportChanged: true
                })

                let observer = this.keyToObservers["reports"]
                observer() //unregister
                this.keyToObservers["reports"] = null

                this.searchReports()
            }
        })
    }

    async searchQuestions() {
        this.setState({
            isQuestionRequesting: true
        })
        let questionResponse = await this.searchContents('questions')
        if (questionResponse && questionResponse.isSuccess) {
            console.log('questions get success! : ' + questionResponse.list.length)
            this.setState({
                questions: questionResponse.list
            })
        }
        this.setState({
            isQuestionRequesting: false
        })

        let recentQuestionCreateTime = this.recentCreateTime(this.state.questions)
        let baseQuestionCheckTime = (recentQuestionCreateTime == 0) ? this.yesterdayTime() : recentQuestionCreateTime
        this.registerObserver("questions", baseQuestionCheckTime, (list) => {
            if (list.length > 0) {
                console.log('[question] observer work!')
                this.raiseAlarm()
                this.setState({
                    isQuestionChanged: true
                })

                let observer = this.keyToObservers["questions"]
                observer() //unregister
                this.keyToObservers["questions"] = null

                this.searchQuestions()
            }
        })
    }

    async searchChannels() {
        this.setState({
            isChannelRequesting: true
        })
        let channelResponse = await this.searchContents('channels')
        if (channelResponse && channelResponse.isSuccess) {
            console.log('channel get success! : ' + channelResponse.list.length)

            this.setState({
                channels: channelResponse.list
            })
        }
        this.setState({
            isChannelRequesting: false
        })

        let recentChannelCreateTime = this.recentCreateTime(this.state.channels)
        let baseChannelCheckTime = (recentChannelCreateTime == 0) ? this.yesterdayTime() : recentChannelCreateTime
        this.registerObserver("channels", baseChannelCheckTime, (list) => {
            if (list.length > 0) {
                console.log('[channel] observer work!')
                this.raiseAlarm()
                this.setState({
                    isChannelChanged: true
                })

                let observer = this.keyToObservers["channels"]
                observer() //unregister
                this.keyToObservers["channels"] = null

                this.searchChannels()
            }
        })
    }

    async searchVideos() {
        this.setState({
            isVideoRequesting: true
        })
        let videoResponse = await this.searchContents('videos')
        if (videoResponse && videoResponse.isSuccess) {
            console.log('video get success! : ' + videoResponse.list.length)

            this.setState({
                videos: videoResponse.list
            })
        }
        this.setState({
            isVideoRequesting: false
        })

        let recentVideoCreateTime = this.recentCreateTime(this.state.videos)
        let baseVideoCheckTime = (recentVideoCreateTime == 0) ? this.yesterdayTime() : recentVideoCreateTime
        this.registerObserver("videos", baseVideoCheckTime, (list) => {
            if (list.length > 0) {
                console.log('[video] observer work!')
                this.raiseAlarm()
                this.setState({
                    isVideoChanged: true
                })

                let observer = this.keyToObservers["videos"]
                observer() //unregister
                this.keyToObservers["videos"] = null

                this.searchVideos()
            }
        })
    }

    async searchContents(name) {
        const time = this.yesterdayTime()
        console.log(time)
        return await requestData(name,
            'create_time', '>', time,
            'create_time', 'desc',
            10)
    }

    yesterdayTime() {
        const yesterday = new Date()
        yesterday.setDate(yesterday.getDate() - 1)
        const start_ymd = getYmd(yesterday)
        return getTimeFromYmdt(start_ymd + " 00:00:00")
    }


    //MARK:- Observer
    recentCreateTime(array) {
        let createTime = 0
        array.forEach((item, index, array) => {
            if (createTime < item.create_time) {
                createTime = item.create_time
            }
        })
        return createTime
    }

    registerObserver(name, createTime, callback) {
        let query = store.collection(name)
            .orderBy('create_time','desc')
            .where('create_time', '>', createTime);

        let observer = query.onSnapshot((snapshot) => {
            console.log(name + " / " + snapshot.size)
            let list = [];
            snapshot.forEach((snap)=>{
                list.push(snap.data());
            })
            callback(list)
        }, (err) => {
            console.error(err)
            callback([])
        })
        this.keyToObservers[name] = observer
    }

    unregisterAllObserver() {
        console.log('unregister all observer')
         for (let key in this.keyToObservers) {
             let observer = this.keyToObservers[key]
             observer()
         }
         this.keyToObservers = {}
    }

    //MARK:- Alarm
    raiseAlarm() {
        this.setState({
            soundStatus:Sound.status.PLAYING
        });
    }

    finishAlarm() {
        this.setState({
            soundStatus:Sound.status.STOPPED
        })
    }

    //MARK:- Refresh
    _onAutoRefreshButtonClicked() {
        const tobeAutoRefresh = !this.state.isAutoRefresh
        if (tobeAutoRefresh) {
            this._startAutoRefresh()
        } else {
            this._stopAutoRefresh()
        }

        this.setState({
            isAutoRefresh: tobeAutoRefresh
        })
    }

    _startAutoRefresh() {
        console.log('start auto refresh')

        this.timerId = setInterval(() => {

            const remainSec = this.state.autoRefreshExpireSec - 1

            this.setState({
                autoRefreshExpireSec : remainSec
            })

            if (remainSec < 1) {
                this.setState({
                    autoRefreshExpireSec : this.AUTO_REFRESH_EXPIRE_SEC
                })

                this.unregisterAllObserver()
                this.searchAll()
            }
        }, 1000)
    }

    _stopAutoRefresh() {
        console.log('stop auto refresh')
        if (this.timerId != null) {
            console.log(this.timerId)
            clearInterval(this.timerId)
        }
        this.setState({
            autoRefreshExpireSec : this.AUTO_REFRESH_EXPIRE_SEC
        })
    }

    render() {
        console.log('[MornitoringDashboard] render')

        return (
            <div className="container-fluid">

                {/*Page Heading*/}
                <div className="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 className="h3 mb-0 text-gray-800">Mornitoring Dashboard</h1>

                    {/*자동갱신*/}
                    {
                        this.state.isAutoRefresh ? (
                            <div className="text-right">
                                <button className="btn btn-success btn-icon-split"
                                        onClick={() => this._onAutoRefreshButtonClicked()}>
                    <span className="icon text-white-50">
                      <i className="fas fa-sync-alt">{'  ' + this.state.autoRefreshExpireSec}</i>
                    </span>
                                    <span className="text">AutoRefresh ON</span>
                                </button>
                            </div>
                        ) : (
                            <div className="text-right">
                                <br/>
                                <button className="btn btn-light btn-icon-split"
                                        onClick={() => this._onAutoRefreshButtonClicked()}>
                    <span className="icon text-gray-600">
                      <i className="fas fa-check"></i>
                    </span>
                                    <span className="text">AutoRefresh OFF</span>
                                </button>
                            </div>
                        )
                    }

                </div>
                <hr/>



                <FlexView grow={1}
                          column>

                    <FlexView grow={1}>

                        <FlexView className="card shadow mb-4"
                                  column
                                  grow={1}
                                  style={{
                                      width: '50%',
                                      padding: 10,
                                      marginRight: 20
                                  }}>

                            <FlexView grow={1}>
                                {
                                    this.state.isReportChanged ? (
                                        <FlexView >
                                            <h4 style={{
                                                color: '#d65544',
                                                fontWeight: 'bold'
                                            }}>
                                                Reports
                                            </h4>

                                            <button className={"btn btn-danger btn-icon-split btn-sm"}
                                                    style={{
                                                        height: 30,
                                                        marginLeft: 20
                                                    }}
                                                    onClick={() => {
                                                        this.setState({
                                                            isReportChanged: false
                                                        })
                                                    }} >
                                                <span className="icon text-white-50"><i className="fas fa-check"></i></span>
                                                <span className="text">확인함</span>
                                            </button>

                                        </FlexView>
                                    ) : (
                                        <h4>
                                            Reports
                                        </h4>
                                    )
                                }
                            </FlexView>


                            {
                                this.state.isReportRequesting ? (
                                    <FlexView column
                                              grow={1}
                                              hAlignContent={'center'}
                                              vAlignContent={'center'}
                                              width={'100%'}
                                              height={200} >
                                        <HashLoader sizeUnit={"px"}
                                                    size={50}
                                                    color={'#4362c9'}
                                                    loading={true}
                                        />
                                        <br/>
                                        Loading...
                                    </FlexView>
                                ) : (
                                    <MornitoringReportGadget info={this.state.reports} />
                                )
                            }


                        </FlexView>

                        <FlexView className="card shadow mb-4"
                                  column
                                  grow={1}
                                  style={{
                                      width: '50%',
                                      padding: 10
                                  }}>

                            <FlexView grow={1}>
                                {
                                    this.state.isQuestionChanged ? (
                                        <FlexView >
                                            <h4 style={{
                                                color: '#d65544',
                                                fontWeight: 'bold'
                                            }}>
                                                Questions
                                            </h4>

                                            <button className={"btn btn-danger btn-icon-split btn-sm"}
                                                    style={{
                                                        height: 30,
                                                        marginLeft: 20
                                                    }}
                                                    onClick={() => {
                                                        this.setState({
                                                            isQuestionChanged: false
                                                        })
                                                    }} >
                                                <span className="icon text-white-50"><i className="fas fa-check"></i></span>
                                                <span className="text">확인함</span>
                                            </button>

                                        </FlexView>
                                    ) : (
                                        <h4>
                                            Questions
                                        </h4>
                                    )
                                }
                            </FlexView>


                            {
                                this.state.isQuestionRequesting ? (
                                    <FlexView column
                                              grow={1}
                                              hAlignContent={'center'}
                                              vAlignContent={'center'}
                                              width={'100%'}
                                              height={200} >
                                        <HashLoader sizeUnit={"px"}
                                                    size={50}
                                                    color={'#4362c9'}
                                                    loading={true}
                                        />
                                        <br/>
                                        Loading...
                                    </FlexView>
                                ) : (
                                    <MornitoringQuestionGadget info={this.state.questions} />
                                )
                            }

                        </FlexView>

                    </FlexView>



                    <FlexView column
                              grow={1}>

                        <FlexView className="card shadow mb-4"
                                  column
                                  grow={1}
                                  style={{
                                      width: '100%',
                                      padding: 10,
                                  }}>

                            <FlexView grow={1}>
                                {
                                    this.state.isChannelChanged ? (
                                        <FlexView >
                                            <h4 style={{
                                                color: '#d65544',
                                                fontWeight: 'bold'
                                            }}>
                                                Channels
                                            </h4>

                                            <button className={"btn btn-danger btn-icon-split btn-sm"}
                                                    style={{
                                                        height: 30,
                                                        marginLeft: 20
                                                    }}
                                                    onClick={() => {
                                                        this.setState({
                                                            isChannelChanged: false
                                                        })
                                                    }} >
                                                <span className="icon text-white-50"><i className="fas fa-check"></i></span>
                                                <span className="text">확인함</span>
                                            </button>

                                        </FlexView>
                                    ) : (
                                        <h4>
                                            Channels
                                        </h4>
                                    )
                                }
                            </FlexView>


                            {
                                this.state.isChannelRequesting ? (
                                    <FlexView column
                                              grow={1}
                                              hAlignContent={'center'}
                                              vAlignContent={'center'}
                                              width={'100%'}
                                              height={200} >
                                        <HashLoader sizeUnit={"px"}
                                                    size={50}
                                                    color={'#4362c9'}
                                                    loading={true}
                                        />
                                        <br/>
                                        Loading...
                                    </FlexView>
                                ) : (
                                    <MornitoringChannelGadget info={this.state.channels} />
                                )
                            }


                        </FlexView>

                        <FlexView className="card shadow mb-4"
                                  column
                                  grow={1}
                                  style={{
                                      width: '100%',
                                      padding: 10
                                  }}>


                            <FlexView grow={1}>
                                {
                                    this.state.isVideoChanged ? (
                                        <FlexView >
                                            <h4 style={{
                                                color: '#d65544',
                                                fontWeight: 'bold'
                                            }}>
                                                Videos
                                            </h4>

                                            <button className={"btn btn-danger btn-icon-split btn-sm"}
                                                    style={{
                                                        height: 30,
                                                        marginLeft: 20
                                                    }}
                                                    onClick={() => {
                                                        this.setState({
                                                            isVideoChanged: false
                                                        })
                                                    }} >
                                                <span className="icon text-white-50"><i className="fas fa-check"></i></span>
                                                <span className="text">확인함</span>
                                            </button>

                                        </FlexView>
                                    ) : (
                                        <h4>
                                            Videos
                                        </h4>
                                    )
                                }
                            </FlexView>


                            {
                                this.state.isVideoRequesting ? (
                                    <FlexView column
                                              grow={1}
                                              hAlignContent={'center'}
                                              vAlignContent={'center'}
                                              width={'100%'}
                                              height={200} >
                                        <HashLoader sizeUnit={"px"}
                                                    size={50}
                                                    color={'#4362c9'}
                                                    loading={true}
                                        />
                                        <br/>
                                        Loading...
                                    </FlexView>
                                ) : (
                                    <MornitoringVideoGadget info={this.state.videos} />
                                )
                            }



                        </FlexView>

                    </FlexView>

                </FlexView>


                <Sound
                    url="../../assets/img/siren.mp3"
                    playStatus={this.state.soundStatus}
                    onFinishedPlaying={()=>this.finishAlarm()}
                />

            </div>
        );
    }
}