import React from "react";
import ReactTable from "react-table";
import * as util from "../../assets/js/util";
import {REPORT_STATUS, REPORT_TARGET, statusStringToStatus, targetStringToTarget} from "../report/ReportConst";
import ReportAdmin from "../report/ReportAdmin";
import ChannelInfo from "../channel/ChannelInfo";
import VideoInfo from "../video/VideoInfo";
import UserInfo from "../user/UserInfo";
import CommentInfo from "../comment/CommentInfo";


//Nickname 과 title 을 표시함.
export default class MornitoringReportGadget extends React.Component {

    render() {
        const info = this.props.info

        return (
            <div>
                <ReactTable
                    data={info}
                    columns={[
                        {
                            expander: true
                        },
                        {
                            Header: "생성 시간",
                            id: "createTime",
                            width: 190,
                            accessor: d => util.getYmdtFromTime(d.create_time)
                        },
                        {
                            Header: "신고내용",
                            id: "title",
                            accessor: d => d.description
                        },
                        {
                            Header: "자동차단여부",
                            id: "hitCensorship",
                            width: 130,
                            Cell: row => (<div style={{ textAlign: "center" }}>{row.value}</div>),
                            accessor: d => (
                                (d.hit_censorship != null) ? <p style={{color: '#ffffff', backgroundColor: '#d65544', fontWeight: 'bold'}}>true</p> : 'false'
                            )
                        },
                        {
                            Header: "상태",
                            id: "status",
                            width: 100,
                            Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                            accessor: d => (
                                (d.status != null) ? <p style={REPORT_STATUS.PROPS[statusStringToStatus(d.status)].STYLE}>{REPORT_STATUS.PROPS[statusStringToStatus(d.status)].NAME}</p> : null
                            )
                        },

                    ]}
                    className = { "-striped -highlight" }
                    defaultSorted={ [
                        { id: "createTime", desc: true }
                    ] }
                    collapseOnSortingChange={ false }
                    collapseOnDataChange={ false }
                    SubComponent={row => {
                        const rowData = info[row.index]
                        const type = targetStringToTarget(rowData.target)
                        const isChannel = type == REPORT_TARGET.CHANNEL
                        const isVideo = type == REPORT_TARGET.VIDEO
                        const isUser = type == REPORT_TARGET.USER
                        const isComment = type == REPORT_TARGET.COMMENT

                        return (
                            <div>
                                <ReportAdmin reportData={rowData} />

                                {
                                    isChannel ? (
                                        <ChannelInfo channelKey={rowData.key} />
                                    ) : null
                                }
                                {
                                    isVideo ? (
                                        <VideoInfo videoKey={rowData.key} />
                                    ) : null
                                }
                                {
                                    isUser ? (
                                        <UserInfo userId={rowData.key} />
                                    ) : null
                                }
                                {
                                    isComment ? (
                                        <CommentInfo commentKey={rowData.key} />
                                    ) : null
                                }
                            </div>
                        );
                    }}
                    showPageSizeOptions = { false }
                    showPageJump = { false }
                    defaultPageSize={5}
                />
            </div>
        )
    }
}