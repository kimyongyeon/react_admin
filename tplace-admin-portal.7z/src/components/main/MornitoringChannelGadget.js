import React from "react";
import ChannelInfo from "../channel/ChannelInfo";
import ContentAdmin from "../channel/ContentAdmin";
import {CONTENTS_CONST} from "../channel/ContentConst";
import ReactTable from "react-table";
import * as util from "../../assets/js/util";


//Nickname 과 title 을 표시함.
export default class MornitoringChannelGadget extends React.Component {

    render() {
        const info = this.props.info

        return (
            <div>
                <ReactTable
                    data={info}
                    columns={[
                        {
                            expander: true
                        },
                        {
                            Header: "생성 시간",
                            id: "createTime",
                            width: 190,
                            accessor: d => util.getYmdtFromTime(d.create_time)
                        },
                        {
                            Header: "Creator Nickname",
                            id: "userNickname",
                            width: 160,
                            accessor: d => (d.creator.nickname != null) ? d.creator.nickname : ""
                        },
                        {
                            Header: "타이틀",
                            id: "title",
                            accessor: d => d.title
                        },
                    ]}
                    className = { "-striped -highlight" }
                    defaultSorted={ [
                        { id: "createTime", desc: true }
                    ] }
                    collapseOnSortingChange={ false }
                    collapseOnDataChange={ false }
                    SubComponent={row => {
                        const rowData = info[row.index]
                        return (
                            <div>
                                <ChannelInfo channelKey={rowData.channel_key} />

                                <ContentAdmin contentType={CONTENTS_CONST.REPORT_TARGET.CHANNEL}
                                              contentKey={rowData.channel_key} />
                            </div>
                        );
                    }}
                    defaultPageSize={ 5 }
                />
            </div>
        )
    }
}