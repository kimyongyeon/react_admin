import React from "react";
import ReactTable from "react-table";
import * as util from "../../assets/js/util";
import {QUESTION_STATUS, statusStringToStatus} from "../question/QuestionConst";
import {REPORT_TARGET, targetStringToTarget} from "../report/ReportConst";
import QuestionAdmin from "../question/QuestionAdmin";
import ChannelInfo from "../channel/ChannelInfo";
import VideoInfo from "../video/VideoInfo";
import UserInfo from "../user/UserInfo";
import CommentInfo from "../comment/CommentInfo";


//Nickname 과 title 을 표시함.
export default class MornitoringQuestionGadget extends React.Component {

    render() {
        const info = this.props.info

        return (
            <div>
                <ReactTable
                    data={info}
                    columns={[
                        {
                            expander: true
                        },
                        {
                            Header: "생성 시간",
                            id: "createTime",
                            width: 190,
                            accessor: d => util.getYmdtFromTime(d.create_time)
                        },
                        {
                            Header: "타이틀",
                            id: "title",
                            accessor: d => d.description
                        },
                        {
                            Header: "상태",
                            id: "status",
                            width: 100,
                            Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                            accessor: d => (
                                (d.status != null) ? <p style={QUESTION_STATUS.PROPS[statusStringToStatus(d.status)].STYLE}>{QUESTION_STATUS.PROPS[statusStringToStatus(d.status)].NAME}</p> : null
                            )
                        },

                    ]}
                    className = { "-striped -highlight" }
                    defaultSorted={ [
                        { id: "createTime", desc: true }
                    ] }
                    collapseOnSortingChange={ false }
                    collapseOnDataChange={ false }
                    SubComponent={row => {
                        const rowData = info[row.index]

                        const type = targetStringToTarget(rowData.target)
                        const isChannel = type && type == REPORT_TARGET.CHANNEL
                        const isVideo = type && type == REPORT_TARGET.VIDEO
                        const isUser = type && type == REPORT_TARGET.USER
                        const isComment = type && type == REPORT_TARGET.COMMENT

                        return (
                            <div>
                                <QuestionAdmin questionData={rowData} />

                                {
                                    isChannel ? (
                                        <ChannelInfo channelKey={rowData.key} />
                                    ) : null
                                }
                                {
                                    isVideo ? (
                                        <VideoInfo videoKey={rowData.key} />
                                    ) : null
                                }
                                {
                                    isUser ? (
                                        <UserInfo userId={rowData.key} />
                                    ) : null
                                }
                                {
                                    isComment ? (
                                        <CommentInfo commentKey={rowData.key} />
                                    ) : null
                                }
                            </div>
                        );
                    }}
                    showPageSizeOptions = { false }
                    showPageJump = { false }
                    defaultPageSize={5}
                />
            </div>
        )
    }
}