import React from "react";
import ContentAdmin from "../channel/ContentAdmin";
import {CONTENTS_CONST} from "../channel/ContentConst";
import ReactTable from "react-table";
import 'react-table/react-table.css'
import * as util from "../../assets/js/util";
import {VIDEO_UNSAFE_LEVEL} from "../video/VideoConst";
import ReactPlayer from "react-player";
import VideoInfo from "../video/VideoInfo";



//Nickname 과 Video 을 표시함.
export default class MornitoringVideoGadget extends React.Component {

    render() {
        const info = this.props.info

        return (
            <div>
                <ReactTable
                    data={info}
                    columns={[
                        {
                            expander: true
                        },
                        {
                            Header: "생성 시간",
                            id: "createTime",
                            width: 190,
                            accessor: d => util.getYmdtFromTime(d.create_time)
                        },
                        {
                            Header: "Creator Nickname",
                            id: "userNickname",
                            width: 160,
                            accessor: d => (d.creator.nickname != null) ? d.creator.nickname : ""
                        },
                        {
                            Header: "타이틀",
                            id: "title",
                            Cell : row => (<span title={row.value}>{row.value}</span>),
                            accessor: d => d.title
                        },
                        {
                            Header: "해시태그",
                            id: "hashtag",
                            Cell : row => (<span title={row.value}>{row.value}</span>),
                            accessor: d => d.tags
                        },
                        {
                            Header: "유해성 단계",
                            id: "unsafeLevel",
                            width: 100,
                            Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                            accessor: d => ( (d.unsafe_level != null) ? <p style={VIDEO_UNSAFE_LEVEL.PROPS[d.unsafe_level].STYLE}>{d.unsafe_level}</p> : null )
                        },
                        {
                            Header: "Thumbnail",
                            id: "thumbnail",
                            width: 200,
                            accessor: (d) => <img src={d.preview_url}
                                                  style={{
                                                      width: 200,
                                                  }}/>
                        },
                        {
                            Header: "동영상 재생",
                            id: "contents",
                            width: 300,
                            accessor: (video) =>
                                <ReactPlayer controls
                                             light
                                             url={video.video_url}
                                             width={200}
                                             height={200}
                                />
                        }
                    ]}
                    defaultPageSize={ 5 }
                    className = { "-striped -highlight" }
                    defaultSorted={ [
                        { id: "createTime", desc: true }
                    ] }
                    collapseOnSortingChange={ false }
                    collapseOnDataChange={false}
                    SubComponent={row => {
                        const rowData = info[row.index]
                        return (
                            <div>
                                <VideoInfo videoInfo={rowData} />

                                <ContentAdmin  contentType={CONTENTS_CONST.REPORT_TARGET.VIDEO}
                                               contentKey={rowData.video_key} />
                            </div>
                        );
                    }}
                />
            </div>
        )
    }
}