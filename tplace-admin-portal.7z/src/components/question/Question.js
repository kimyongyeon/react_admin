
import React from "react";
import 'startbootstrap-sb-admin-2/css/sb-admin-2.css'

import QuestionSearchCondition from "./QuestionSearchCondition";
import QuestionTable from './QuestionTable'


export default class Question extends React.Component {

    render() {
        return (
            <div className="container-fluid">

                <h1 className="h3 mb-2 text-gray-800">
                    Questions
                </h1>

                <div className="card shadow mb-4">
                    <QuestionSearchCondition />

                    <div className="card-header py-3">
                        <h6 className="m-0 font-weight-bold text-primary">Results</h6>
                    </div>

                    <QuestionTable/>

                </div>
            </div>
        );
    }
}

