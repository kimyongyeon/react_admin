import React from "react";

import 'react-datepicker/dist/react-datepicker.min.css'
import 'react-datepicker/dist/react-datepicker-cssmodules.min.css'
import DatePicker from "react-datepicker/es";
import DevTools from "mobx-react-devtools";
import {QUESTION_STATUS, QUESTION_CATEGORY} from "./QuestionConst";
import {inject, observer} from "mobx-react";
import moment from "moment";
import {getYmd} from "../../assets/js/util";


@inject("questionStore") @observer
export default class QuestionSearchCondition extends React.Component {

    constructor(props){
        super(props)

        console.log('[QuestionSearchCondition] constructor')

        const aweekago = new Date()
        aweekago.setDate(aweekago.getDate() - 7)

        this.state = {
            isSearching: false,
            startDate: aweekago,
            endDate: new Date(),

            questionStatus: QUESTION_STATUS.ALL,
            questionCategory: QUESTION_CATEGORY.ALL,
            questionUserId: '',
            questionUserEmail: ''
        };

        this.onEnterKeyPressed = this.onEnterKeyPressed.bind(this)
    }

    componentDidMount() {
        document.querySelector('#userInfo').addEventListener('keypress', this.onEnterKeyPressed)

        //최초 진입 시 기본 최신 날짜 검색
        this._onSearchButtonClicked()
    }

    componentWillUnmount() {
        document.querySelector('#userInfo').removeEventListener('keypress', this.onEnterKeyPressed)
    }

    onEnterKeyPressed(e) {
        let key = e.which || e.keyCode;
        if (key === 13) {
            this._onSearchButtonClicked()
        }
    }


    _onStartDateChanged(value) {
        this.setState({
            startDate: value
        })
    }

    _onEndDateChanged(value) {
        this.setState({
            endDate: value
        })
    }

    _onValueChanged(e) {
        console.log(e.target.value)

        this.setState({
            [e.target.name]: e.target.value
        })

        console.log(this.state)
    }

    async _onSearchButtonClicked() {
        if (!this.state.startDate || !this.state.endDate) {
            alert('날짜를 재설정해주세요')
            return
        }

        const start_ymd = getYmd(this.state.startDate)
        const end_ymd = getYmd(this.state.endDate)

        console.log('startDate: ', start_ymd)
        console.log('endDate: ', end_ymd)

        if (moment(end_ymd) - moment(start_ymd) < 0) {
            alert('시작날짜가 종료날짜보다 큽니다. 날짜를 재설정해주세요')
            return
        }


        this.setState({
            isSearching: true
        })
        await this.props.questionStore.requestSearchQuestion({
            start_ymd : start_ymd,
            end_ymd : end_ymd,
            question_status: this.state.questionStatus,
            question_category: this.state.questionCategory,
            question_user_id: this.state.questionUserId,
            question_user_email: this.state.questionUserEmail,
        })
        this.setState({
            isSearching: false
        })
    }


    render() {
        console.log('[QuestionSearchCondition] render')

        return (
            <div>
                <a href="#collapseCardExample"
                   className="d-block card-header py-3"
                   data-toggle="collapse"
                   role="button"
                   aria-expanded="true"
                   aria-controls="collapseCardExample">
                    <h6 className="m-0 font-weight-bold text-primary">Search Condition</h6>
                </a>


                {/*Card Content - Collapse*/}
                <div className="collapse show" id="collapseCardExample">
                    <div className="card-body" id={'userInfo'}>

                        <h6>문의날짜</h6>
                        <DatePicker selected={this.state.startDate}
                                    dateFormat="YYYY-MM-dd"
                                    onChange={(v) => this._onStartDateChanged(v)} />
                        ~
                        <DatePicker selected={this.state.endDate}
                                    dateFormat="YYYY-MM-dd"
                                    onChange={(v) => this._onEndDateChanged(v)} />
                        <br/><br/>

                        <h6>문의 진행상태</h6>
                        <div className="dropdown mb-4">
                            <button className="btn btn-light dropdown-toggle"
                                    type="button"
                                    id="dropdownMenuButton"
                                    data-toggle="dropdown"
                                    aria-haspopup="true"
                                    aria-expanded="false">
                                {QUESTION_STATUS.PROPS[this.state.questionStatus].NAME}
                            </button>
                            <div className="dropdown-menu animated--fade-in" aria-labelledby="dropdownMenuButton">
                                <button className='dropdown-item'
                                        name={'questionStatus'}
                                        value={QUESTION_STATUS.ALL}
                                        onClick={(e) => this._onValueChanged(e)}>{QUESTION_STATUS.PROPS[QUESTION_STATUS.ALL].NAME}</button>
                                <button className='dropdown-item'
                                        name={'questionStatus'}
                                        value={QUESTION_STATUS.READY}
                                        onClick={(e) => this._onValueChanged(e)}>{QUESTION_STATUS.PROPS[QUESTION_STATUS.READY].NAME}</button>
                                <button className='dropdown-item'
                                        name={'questionStatus'}
                                        value={QUESTION_STATUS.PENDING}
                                        onClick={(e) => this._onValueChanged(e)}>{QUESTION_STATUS.PROPS[QUESTION_STATUS.PENDING].NAME}</button>
                                <button className='dropdown-item'
                                        name={'questionStatus'}
                                        value={QUESTION_STATUS.DONE}
                                        onClick={(e) => this._onValueChanged(e)}>{QUESTION_STATUS.PROPS[QUESTION_STATUS.DONE].NAME}</button>
                            </div>
                        </div>


                        <h6>문의 대상</h6>
                        <div className="dropdown mb-4">
                            <button className="btn btn-light dropdown-toggle"
                                    type="button"
                                    id="dropdownMenuButton"
                                    data-toggle="dropdown"
                                    aria-haspopup="true"
                                    aria-expanded="false">
                                {QUESTION_CATEGORY.PROPS[this.state.questionCategory].NAME}
                            </button>
                            <div className="dropdown-menu animated--fade-in" aria-labelledby="dropdownMenuButton">
                                <button className={'dropdown-item'}
                                        name={'questionCategory'}
                                        value={QUESTION_CATEGORY.ALL}
                                        onClick={(e) => this._onValueChanged(e)}>{QUESTION_CATEGORY.PROPS[QUESTION_CATEGORY.ALL].NAME}</button>
                                <button className={'dropdown-item'}
                                        name={'questionCategory'}
                                        value={QUESTION_CATEGORY.GENERAL}
                                        onClick={(e) => this._onValueChanged(e)}>{QUESTION_CATEGORY.PROPS[QUESTION_CATEGORY.GENERAL].NAME}</button>
                                <button className={'dropdown-item'}
                                        name={'questionCategory'}
                                        value={QUESTION_CATEGORY.REPORT}
                                        onClick={(e) => this._onValueChanged(e)}>{QUESTION_CATEGORY.PROPS[QUESTION_CATEGORY.REPORT].NAME}</button>
                            </div>
                        </div>

                        <h6>문의자 UserId</h6>
                        <input type="text"
                               className="form-control form-control-user"
                               placeholder="Enter User Id"
                               name={'questionUserId'}
                               onChange={(e) => this._onValueChanged(e)} />
                        <br/>

                        <h6>문의자 Email</h6>
                        <input type="text"
                               className="form-control form-control-user"
                               placeholder="Enter User Email"
                               name={'questionUserEmail'}
                               onChange={(e) => this._onValueChanged(e)} />
                        <br/>

                        {/*Search*/}
                        {
                            this.state.isSearching ? (
                                <div className="text-right">
                                    Searching...
                                </div>
                            ) : (
                                <div className="text-right">
                                    <button className={'btn btn-primary btn-icon-split btn'}
                                            onClick={() => this._onSearchButtonClicked()}>
                            <span className="icon text-white-50">
                                <i className="fas fa-arrow-right"></i>
                            </span>
                                        <span className="text">Search</span>
                                    </button>
                                </div>
                            )
                        }

                    </div>
                </div>
                {process.env.NODE_ENV === 'development' && <DevTools />}
            </div>
        );
    }

}
