
export const QUESTION_STATUS = {
    ALL: 0,
    READY: 1,
    PENDING: 2,
    DONE: 3,

    PROPS: {
        0: {
            NAME: '전체',
            VALUE: 'all',
            STYLE: { }
        },
        1: {
            NAME: '처리대기',
            VALUE: 'ready',
            STYLE: {
                color: '#d65544',
                fontWeight: 'bold'
            }
        },
        2: {
            NAME: '판단보류',
            VALUE: 'pending',
            STYLE: {
                color: '#eec358',
                fontWeight: 'bold'
            }
        },
        3: {
            NAME: '처리완료',
            VALUE: 'done',
            STYLE: { }
        }
    }
}

export let statusStringToStatus = function(string) {
    for(let key in QUESTION_STATUS.PROPS) {
        const prop = QUESTION_STATUS.PROPS[key]
        if (prop.VALUE === string) {
            return key
        }
    }
    return null
}


export const QUESTION_CATEGORY = {
    ALL: 0,
    GENERAL: 1,
    REPORT: 2,

    PROPS: {
        0: {
            NAME: '전체',
            VALUE: 'all'
        },
        1: {
            NAME: '일반문의',
            VALUE: 'general'
        },
        2: {
            NAME: '신고문의',
            VALUE: 'report'
        },
    }
}

export let categoryStringToCategory = function(string) {
    for(let key in QUESTION_CATEGORY.PROPS) {
        const prop = QUESTION_CATEGORY.PROPS[key]
        if (prop.VALUE === string) {
            return key
        }
    }
    return null
}