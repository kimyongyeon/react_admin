import React from "react";
import {inject, observer} from "mobx-react";
import ReactTable from "react-table";
import {categoryStringToCategory, QUESTION_CATEGORY, QUESTION_STATUS, statusStringToStatus} from "./QuestionConst";
import {TABLE_CONST} from "../common/Const";
import QuestionAdmin from "./QuestionAdmin";
import {REPORT_TARGET, targetStringToTarget} from "../report/ReportConst";
import ChannelInfo from "../channel/ChannelInfo";
import VideoInfo from "../video/VideoInfo";
import UserInfo from "../user/UserInfo";
import CommentInfo from "../comment/CommentInfo";


@inject('questionStore')  @observer
export default class QuestionTable extends React.Component {

    constructor(props){
        super(props)
        console.log('[QuestionTable] constructor')

        this.state = {
            currentPage: 0,
            isNextPageLoading: false,
        }
    }

    async _requestSearch(pageIndex) {
        this.setState({
            isNextPageLoading: true
        })
        let res = await this.props.questionStore.requestSearchQuestionWithPage(pageIndex)
        this.setState({
            isNextPageLoading: false
        })

        if (res.isSuccess) {
            this.setState({
                currentPage: pageIndex
            })
        } else {
            alert('조회를 실패하였습니다. \ndata: ' + JSON.stringify(res.data) + '\nerror: ', JSON.stringify(res.error))
        }
    }

    render() {
        console.log('[QuestionTable] render')

        const questionStore = this.props.questionStore
        console.log('currentPage: ', this.state.currentPage)

        let data = []
        if (this.state.currentPage < questionStore.searchQuestionResults.length) {
            data = questionStore.searchQuestionResults[this.state.currentPage]

        } else if (this.state.currentPage > 0) {
            //result 값은 초기화되었고 currentPage 는 아니라면 0 으로 초기화해준다.
            this.setState({
                currentPage: 0
            })
        }
        console.log(data)


        return (
            <ReactTable
                manual
                data={data}
                columns={[
                    {
                        expander: true
                    },
                    {
                        Header: "시간",
                        id: "createTime",
                        Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                        width: 190,
                        accessor: d => d.create_time
                    },
                    {
                        Header: "문의자 ID",
                        id: "userId",
                        accessor: d => d.uid
                    },
                    {
                        Header: "문의자 Email",
                        id: "userEmail",
                        accessor: d => d.email
                    },
                    {
                        Header: "진행상태",
                        id: "status",
                        Cell: row => (<div style={{ textAlign: "center" }}>{row.value}</div>),
                        width: 80,
                        accessor: d => QUESTION_STATUS.PROPS[statusStringToStatus(d.status)].NAME,
                    },
                    {
                        Header: "문의범주",
                        id: "category",
                        Cell: row => (<div style={{ textAlign: "center" }}>{row.value}</div>),
                        width: 80,
                        accessor: d => QUESTION_CATEGORY.PROPS[categoryStringToCategory(d.category)].NAME
                    },
                    {
                        Header: "문의내용",
                        id: "description",
                        accessor: d => d.description
                    }
                ]}
                className = { "-striped -highlight" }
                defaultSorted={ [
                    { id: "createTime", desc: true }
                ] }
                collapseOnSortingChange={ false }
                SubComponent={row => {
                    const rowData = data[row.index]

                    const type = targetStringToTarget(rowData.target)
                    const isChannel = type && type == REPORT_TARGET.CHANNEL
                    const isVideo = type && type == REPORT_TARGET.VIDEO
                    const isUser = type && type == REPORT_TARGET.USER
                    const isComment = type && type == REPORT_TARGET.COMMENT


                    return (
                        <div>
                            <QuestionAdmin questionData={rowData} />

                            {
                                isChannel ? (
                                    <ChannelInfo channelKey={rowData.key} />
                                ) : null
                            }
                            {
                                isVideo ? (
                                    <VideoInfo videoKey={rowData.key} />
                                ) : null
                            }
                            {
                                isUser ? (
                                    <UserInfo userId={rowData.key} />
                                ) : null
                            }
                            {
                                isComment ? (
                                    <CommentInfo commentKey={rowData.key} />
                                ) : null
                            }
                        </div>
                    );
                }}
                showPageSizeOptions = {false}
                showPageJump = { false }
                defaultPageSize={ TABLE_CONST.QUESTION.DEFAULT_SIZE }
                page={ this.state.currentPage }
                pages={ questionStore.searchResultPageSize }
                loading={ this.state.isNextPageLoading }
                onPageChange={(pageIndex) => {
                    console.log('onPageChange: ' + this.state.currentPage + '-> ' + pageIndex)
                    this._requestSearch(pageIndex)
                }}
            />
        )
    }
}
