import React from "react";
import {QUESTION_STATUS, statusStringToStatus} from "./QuestionConst";
import {requestFunction} from "../../action/FirebaseFunctionAction";
import {REPORT_TARGET, targetStringToTarget} from "../report/ReportConst";
import {requestSingleData} from "../../action/FirebaseStoreAction";


export default class QuestionAdmin extends React.Component {

    componentDidMount() {
        let target = targetStringToTarget(this.props.questionData.target)
        if (target != null) {
            this._onFetchTargetInfo()
        }
    }


    constructor(props){
        super(props)
        console.log('[QuestionAdmin] constructor')

        this.state = {
            questionStatus: statusStringToStatus(this.props.questionData.status),
            isInitCheckboxSelected: false,
            adminComment: '',
            isRequesting: false,
            targetInfo: null
        }
    }

    _onStatusChanged(e) {
        console.log(e.target.name + ' to ' + e.target.value)
        this.setState({
            [e.target.name]: e.target.value,
            isInitCheckboxSelected: false,
        })
        console.log(this.state)
    }

    _onValueChanged(e) {
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    _toggleCheckboxState(e) {
        console.log(e.target.name + ' to ' + e.target.checked)
        this.setState({
            [e.target.name]: e.target.checked
        })
        console.log(this.state)
    }

    async _onFetchTargetInfo() {
        let data = this.props.questionData
        let target = targetStringToTarget(data.target)
        if (target == null) {
            alert('신고 문의가 아닙니다.')
            console.error('발생하면 안됨! 신고문의가 아닌데 조회하기가 눌림')
            return
        }

        let name = REPORT_TARGET.PROPS[target].COLLECTION_NAME
        let targetKey = data.key

        let response = await requestSingleData(name, targetKey)
        if (response.isSuccess && response.data == null) {
            let targetName = REPORT_TARGET.PROPS[target].NAME
            alert('삭제된 ' + targetName + '입니다.')
            return
        }
        if (response.isSuccess == false) {
            let targetName = REPORT_TARGET.PROPS[target].NAME
            alert(targetName + '조회에 실패하였습니다.' + '\nerror: ', JSON.stringify(response.error))
            return
        }

        this.setState({
            targetInfo: response.data
        })
    }

    async _onSummitButtonClicked() {
        console.log('onSummitButtonClicked')

        if (!this._checkRequestAvailableCondition()){
            return
        }

        const data = this.props.questionData
        let param = {
            'question_key' : data.question_key,
            'status' : QUESTION_STATUS.PROPS[this.state.questionStatus].VALUE,
            'admin_comment': this.state.adminComment,
            'init_censorship' : this.state.isInitCheckboxSelected
        }

        this.setState({
            isRequesting: true
        })
        let result = await requestFunction('updateQuestion', param)
        this.setState({
            isRequesting: false
        })

        if (result.isSuccess) {
            alert('문의 관리에 성공하였습니다.')
        } else {
            alert('문의 관리에 실패하였습니다. \ndata: ' + JSON.stringify(result.data) + '\nerror: ', JSON.stringify(result.error))
        }
    }

    _checkRequestAvailableCondition() {
        const data = this.props.questionData
        const dataStatus = statusStringToStatus(data.status)

        //dataStatus check
        if (dataStatus == QUESTION_STATUS.DONE) {
            alert('처리완료된 건의 경우 수정이 불가능합니다.')
            return
        }
        if (dataStatus == this.state.questionStatus) {
            alert('수정하시려면 문의 진행상태를 수정해주세요.')
            return
        }

        //state check
        if (this.state.adminComment.length == 0) {
            alert('운영자 Comment 를 남겨주세요.')
            return false
        }
        if (this.state.questionStatus != QUESTION_STATUS.DONE && this.state.isInitCheckboxSelected) {
            alert('초기화 동작은 처리완료 상태에서만 가능합니다.')
            return
        }

        //select confirm
        if (this.state.isInitCheckboxSelected) {
            return confirm('정말 초기화하시겠습니까?')
        }
        return true
    }

    _onEmailClicked() {
        const data = this.props.questionData
        const email = data.email

        let textField = document.createElement('textarea')
        textField.innerText = email
        document.body.appendChild(textField)
        textField.select()
        document.execCommand('copy')
        textField.remove()

        alert('이메일이 클립보드에 복사되었습니다.')
    }


    render() {
        console.log('[QuestionAdmin] render')

        const data = this.props.questionData


        return (
            <div style={{ padding: "20px" }}>
                <h5>관리하기</h5>

                <div className="card mb-4 py-3 border-left-primary">
                    <div className="card-body">

                        <strong>문의자 Email</strong>
                        <div onClick={() => this._onEmailClicked()}>
                            {data.email}
                        </div>
                        <br/>

                        <strong>문의 내용</strong>
                        <div>
                            {data.description}
                        </div>
                        <br/>

                        {
                            data.target && data.target.length > 0 ? (
                                <div>
                                    <strong>신고 문의 target</strong>
                                    <div>
                                        {REPORT_TARGET.PROPS[targetStringToTarget(data.target)].NAME}
                                    </div>
                                    <br/>

                                    <strong>신고 문의 target key</strong>
                                    <div>
                                        {data.key}
                                    </div>
                                    <br/>
                                </div>
                            ) : null
                        }



                        {
                            data.target && data.target.length > 0 ? (
                                <div>
                                    {
                                        this.state.targetInfo != null ? (
                                            <div>
                                                <strong>{REPORT_TARGET.PROPS[targetStringToTarget(data.target)].NAME} 차단 상태</strong> {
                                                this.state.targetInfo.censorship ? (
                                                    <div>
                                                        <strong style={{color: '#d65544', fontSize: 23}}>차단됨</strong>
                                                        <br/>
                                                    </div>
                                                ) : (
                                                    <div>
                                                        <strong style={{color: '#41c989', fontSize: 23}}>차단되지 않음</strong>
                                                        <br/>
                                                    </div>
                                                )
                                            }
                                            <br/>
                                            </div>
                                        ) : (
                                            <div>
                                                <strong>현재 {REPORT_TARGET.PROPS[targetStringToTarget(data.target)].NAME} 차단 상태 조회하기</strong><br/>
                                                <button className={"btn btn-primary btn-icon-split btn-sm"}
                                                        onClick={() => this._onFetchTargetInfo()} >
                                                    <span className="text">조회하기</span>
                                                </button>
                                                <br/>
                                                <br/>
                                            </div>
                                        )
                                    }
                                </div>
                            ) : null
                        }



                        {
                            statusStringToStatus(data.status) == QUESTION_STATUS.DONE ? null : (
                                <div>
                                    <strong>문의 진행상태 수정</strong>
                                    <div className="dropdown mb-4">
                                        <button className="btn btn-light dropdown-toggle"
                                                id="dropdownMenuButton"
                                                data-toggle="dropdown">
                                            {QUESTION_STATUS.PROPS[this.state.questionStatus].NAME}
                                        </button>
                                        <div className="dropdown-menu animated--fade-in"
                                             aria-labelledby="dropdownMenuButton">

                                            {
                                                statusStringToStatus(data.status) == QUESTION_STATUS.READY ? (
                                                    <button className='dropdown-item'
                                                            name={'questionStatus'}
                                                            value={QUESTION_STATUS.PENDING}
                                                            onClick={(e) => this._onStatusChanged(e)}>{QUESTION_STATUS.PROPS[QUESTION_STATUS.PENDING].NAME}</button>
                                                ) : null
                                            }

                                            <button className='dropdown-item'
                                                    name={'questionStatus'}
                                                    value={QUESTION_STATUS.DONE}
                                                    onClick={(e) => this._onStatusChanged(e)}>{QUESTION_STATUS.PROPS[QUESTION_STATUS.DONE].NAME}</button>
                                        </div>
                                    </div>
                                </div>
                            )
                        }


                        {
                            data.target && data.target.length > 0
                            && this.state.targetInfo && this.state.targetInfo.censorship
                            && statusStringToStatus(this.props.questionData.status) != QUESTION_STATUS.DONE
                            && this.state.questionStatus == QUESTION_STATUS.DONE ? (
                                <div>
                                    <strong>{REPORT_TARGET.PROPS[targetStringToTarget(data.target)].NAME} 차단 초기화하기</strong>
                                    <div>
                                        <input
                                            type="checkbox"
                                            checked={this.state.isInitCheckboxSelected === true}
                                            name={"isInitCheckboxSelected"}
                                            onChange={(e) => this._toggleCheckboxState(e)}
                                        />
                                    </div>
                                    <br/>
                                </div>
                            ) : null
                        }


                        <strong>운영자 Comment</strong>
                        <div>
                            {
                                statusStringToStatus(data.status) == QUESTION_STATUS.DONE ? (
                                    <div>
                                        {data.admin_comment}
                                    </div>
                                ) : (
                                    <input type="text"
                                           className="form-control form-control-user"
                                           style={{width:'100%'}}
                                           name={'adminComment'}
                                           defaultValue={data.admin_comment}
                                           placeholder={'관리자이름과 답장을 보낸 날짜, 시간을 기입해주세요. ex)한승_20190613_오전 10:15'}
                                           onChange={(e) => this._onValueChanged(e)}
                                    />
                                )
                            }
                        </div>
                        <br/>


                        {
                            statusStringToStatus(data.status) == QUESTION_STATUS.DONE ? null : (
                                <div>
                                    <br/>
                                    {
                                        this.state.isRequesting ? (
                                            <div>
                                                Requesting...
                                            </div>
                                        ) : (
                                            <button className={"btn btn-primary btn-icon-split btn"}
                                                    onClick={() => this._onSummitButtonClicked()} >
                                                <span className="text">수정</span>
                                            </button>
                                        )
                                    }
                                </div>
                            )
                        }

                    </div>
                </div>
            </div>
        )
    }
}
