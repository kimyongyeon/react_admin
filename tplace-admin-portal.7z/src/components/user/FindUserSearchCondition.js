import React from "react";
import {inject, observer} from "mobx-react";
import DevTools from 'mobx-react-devtools';



@inject("userStore") @observer
export default class FindUserSearchCondition extends React.Component {

    constructor(props){
        super(props)
        console.log('[FindUserSearchCondition] constructor')

        this.state = {
            userId: '',
            userEmail: '',
            userNickname: '',
            isSearching: false
        };

        this.onEnterKeyPressed = this.onEnterKeyPressed.bind(this)
    }

    componentDidMount() {
        document.querySelector('#userInfo').addEventListener('keypress', this.onEnterKeyPressed)
    }

    componentWillUnmount() {
        document.querySelector('#userInfo').removeEventListener('keypress', this.onEnterKeyPressed)
    }

    onEnterKeyPressed(e) {
        let key = e.which || e.keyCode;
        if (key === 13) {
            this._onSearchButtonClicked()
        }
    }


    _onValueChanged(e) {
        console.log(e.target.value)

        this.setState({
            [e.target.name]: e.target.value
        })

        console.log(this.state)
    }

    async _onSearchButtonClicked() {
        const userId = this.state.userId
        const email = this.state.userEmail
        const nickname = this.state.userNickname

        if (userId.length == 0 && email.length == 0 && nickname.length == 0) {
            alert('검색 조건을 설정해주세요')
            return
        }

        if (![userId.length, email.length, nickname.length].includes(userId.length + email.length + nickname.length) ) {
            alert('하나의 조건만 설정해주세요')
            return
        }

        this.setState({
            isSearching: true
        })

        let res = await this.props.userStore.requestSearchUser({
            user_id: this.state.userId,
            user_email: this.state.userEmail,
            user_nickname: this.state.userNickname
        })

        this.setState({
            isSearching: false
        })

        if (!res.isSuccess) {
            alert('조회를 실패하였습니다. \ndata: ' + JSON.stringify(res.data) + '\nerror: ', JSON.stringify(res.error))
        }
    }


    render() {
        console.log('[FindUserSearchCondition] render')

        return (
            <div>
                <a href="#collapseCardExample"
                   className="d-block card-header py-3"
                   data-toggle="collapse"
                   role="button"
                   aria-expanded="true"
                   aria-controls="collapseCardExample">
                    <h6 className="m-0 font-weight-bold text-primary">Search Condition</h6>
                </a>


                {/*Card Content - Collapse*/}
                <div className="collapse show" id="collapseCardExample">
                    <div className="card-body"
                         id={'userInfo'}>

                        <h6>UserId</h6>
                        <input type="text"
                               className="form-control form-control-user"
                               placeholder="Enter User Id"
                               name={'userId'}
                               onChange={(e) => this._onValueChanged(e)} />
                        <br/>

                        <h6>User Email</h6>
                        <input type="text"
                               className="form-control form-control-user"
                               placeholder="Enter User Email"
                               name={'userEmail'}
                               onChange={(e) => this._onValueChanged(e)} />
                        <br/>

                        <h6>User Nickname</h6>
                        <input type="text"
                               className="form-control form-control-user"
                               placeholder="Enter User Nickname"
                               name={'userNickname'}
                               onChange={(e) => this._onValueChanged(e)} />
                        <br/>

                        {/*Search*/}
                        {
                            this.state.isSearching ? (
                                <div className="text-right">
                                    Searching...
                                </div>
                            ) : (
                                <div className="text-right">
                                    <button className={'btn btn-primary btn-icon-split btn'}
                                            onClick={() => this._onSearchButtonClicked()}>
                            <span className="icon text-white-50">
                                <i className="fas fa-arrow-right"></i>
                            </span>
                                        <span className="text">Search</span>
                                    </button>
                                </div>
                            )
                        }

                    </div>
                </div>
                {process.env.NODE_ENV === 'development' && <DevTools />}
            </div>
        );
    }
}

