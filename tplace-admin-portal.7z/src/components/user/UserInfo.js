
import React from "react";
import {requestSingleData} from "../../action/FirebaseStoreAction";
import * as util from "../../assets/js/util";



export default class UserInfo extends React.Component {

    constructor(props) {
        super(props)
        console.log('[ChannelInfo] constructor')

        this.state = {
            isRequesting: false,
            userInfo: this.props.userInfo
        }
    }

    async _requestUserInfo() {
        const userId = this.props.userId

        let mustConditionList = {"match": {"uid": userId}}
        console.log(mustConditionList)

        this.setState({
            isRequesting: true
        })

        let res = await requestSingleData('users', userId)
        this.setState({
            isRequesting: false
        })

        if (res.isSuccess) {
            if (res.data != null) {
                this.setState({
                    userInfo: res.data
                })
            } else {
                alert('삭제된 유저입니다.')
            }
        } else {
            alert('조회를 실패하였습니다. \ndata: ' + JSON.stringify(res.data) + '\nerror: ', JSON.stringify(res.error))
        }
    }


    render() {
        console.log('[UserInfo] render')

        let info = this.state.userInfo
        console.log('[UserInfo] render data: ', info)


        return (
            <div style={{ padding: "20px" }}>
                <h5>사용자 정보</h5>

                <div className="card mb-4 py-3 border-left-primary">

                    { (info == null) ? (
                        <div className={'card-body'}>
                            {
                                this.state.isRequesting ? (
                                    <div>
                                        Requesting...
                                    </div>
                                ) : (
                                    <button className={"btn btn-primary btn-icon-split btn"}
                                            onClick={() => this._requestUserInfo()} >
                                        <span className="text">정보 조회하기</span>
                                    </button>
                                )
                            }
                        </div>
                    ) : (
                            <div className="card-body">

                                <div>
                                    <strong>ID</strong> - {info.uid}
                                </div>
                                <div>
                                    <strong>Nickname</strong> - {info.nickname}
                                </div>
                                <div>
                                    <strong>Image</strong> - {
                                    (
                                        <img className="img-profile rounded-circle"
                                             src={ info.image_url.length > 0 ? info.image_url : 'assets/img/image_profile_no_profile.png' }
                                             style={{width:'50px', height:'50px'}}
                                        />
                                    )
                                }
                                </div>


                                <br/>



                                <div>
                                    <strong>남김말</strong> - {info.message}
                                </div>


                                <br/>


                                <div>
                                    <strong>채널 개수</strong> - {info.channel_count}
                                </div>

                                <div>
                                    <strong>영상 개수</strong> - {info.video_count}
                                </div>

                                <div>
                                    <strong>링크 개수</strong> - {info.link_count}
                                </div>

                                <div>
                                    <strong>시청 시간</strong> - {info.play_amount}
                                </div>


                                <br/>


                                <div>
                                    <strong>좋아요 개수</strong> - {info.like_count}
                                </div>

                                <div>
                                    <strong>VLA 포인트</strong> - {info.vla_point}
                                </div>


                                <br/>


                                <div>
                                    <strong>가입일</strong> - {util.getYmdtFromTime(info.create_time)}
                                </div>


                            </div>
                        )}
                </div>

            </div>

        );
    }
}