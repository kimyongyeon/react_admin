
import React from "react";
import {inject, observer} from "mobx-react";
import ReactTable from "react-table";
import 'react-table/react-table.css'
import 'startbootstrap-sb-admin-2/css/sb-admin-2.css'

import ContentAdmin from "../channel/ContentAdmin";
import UserInfo from "./UserInfo";
import {CONTENTS_CONST} from "../channel/ContentConst";
import {TABLE_CONST} from "../common/Const";
import UserCommentInfo from "../comment/UserCommentInfo";



@inject("userStore") @observer
export default class FindUserTable extends React.Component {

    constructor(props){
        super(props)
        console.log('[FindUserTable] constructor')

        this.state = {
            currentPage: 0,
            isNextPageLoading: false,
        }
    }

    async _requestSearch(pageIndex) {
        this.setState({
            isNextPageLoading: true
        })
        let res = await this.props.userStore.requestSearchUserWithPage(pageIndex)
        this.setState({
            isNextPageLoading: false
        })

        if (res.isSuccess) {
            this.setState({
                currentPage: pageIndex
            })
        } else {
            alert('조회를 실패하였습니다. \ndata: ' + JSON.stringify(res.data) + '\nerror: ', JSON.stringify(res.error))
        }
    }

    render() {
        console.log('[FindUserTable] render')

        const userStore = this.props.userStore
        console.log('currentPage: ', this.state.currentPage)

        let data = []
        if (this.state.currentPage < userStore.searchUserResult.length) {
            data = userStore.searchUserResult[this.state.currentPage]

        } else if (this.state.currentPage > 0) {
            //result 값은 초기화되었고 currentPage 는 아니라면 0 으로 초기화해준다.
            this.setState({
                currentPage: 0
            })
        }

        console.log(data)

        return (
            <ReactTable
                manual
                data={data}
                columns={[
                    {
                        expander: true
                    },
                    {
                        Header: "프로필 이미지",
                        Cell: row => (<div style={{ textAlign: "center" }}>{row.value}</div>),
                        width: 100,
                        id: "profileImage",
                        accessor: d =>
                            <img className="img-profile rounded-circle"
                                 src={ d.image_url.length > 0 ? d.image_url : 'assets/img/image_profile_no_profile.png' }
                                 style={{width:'70px', height:'70px'}}
                            />
                    },
                    {
                        Header: "Nickname",
                        Cell: row => (<div style={{ textAlign: "center" }}>{row.value}</div>),
                        id: "nickname",
                        accessor: d => d.nickname
                    },
                    {
                        Header: "Email",
                        Cell: row => (<div style={{ textAlign: "center" }}>{row.value}</div>),
                        id: "email",
                        accessor: d => d.email
                    },
                    {
                        Header: "UID",
                        Cell: row => (<div style={{ textAlign: "center" }}>{row.value}</div>),
                        id: "userId",
                        accessor: d => d.uid
                    }
                ]}
                className = { "-striped -highlight" }
                collapseOnSortingChange={ false }
                SubComponent={row => {
                    const rowData = data[row.index]
                    return (
                        <div>
                            <UserInfo userInfo={rowData} />

                            <UserCommentInfo userId={rowData.uid} />

                            <ContentAdmin  contentType={CONTENTS_CONST.REPORT_TARGET.USER}
                                           contentKey={rowData.uid} />
                        </div>
                    );
                }}
                showPageSizeOptions = {false}
                showPageJump = { false }
                defaultPageSize={ TABLE_CONST.USER.DEFAULT_SIZE }
                page={ this.state.currentPage }
                pages={ userStore.searchResultPageSize }
                loading={ this.state.isNextPageLoading }
                onPageChange={(pageIndex) => {
                    console.log('onPageChange: ' + this.state.currentPage + '-> ' + pageIndex)
                    this._requestSearch(pageIndex)
                }}
            />
        )
    }
}
