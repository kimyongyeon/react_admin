import React from "react";
import {inject, observer} from "mobx-react";
import DevTools from "mobx-react-devtools";


@inject("staticChannelStore") @observer
export default class TopContainer extends React.Component {

    constructor(props) {
        super(props)

        this.state = {
            addChannelKey: '',
            isNeedSearchProgress: false,
            isNeedAddProgress: false
        }
    }

    componentDidMount(){
        this._searchStaticChannel()
    }


    _onValueChanged(e) {
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    async _onSearchButtonClicked() {
        this._searchStaticChannel()
    }

    async _searchStaticChannel() {
        this.setState({
            isNeedSearchProgress: true
        })
        await this.props.staticChannelStore.searchStaticChannel()
        this.setState({
            isNeedSearchProgress: false
        })
    }

    async _onAddButtonClicked() {
        if (this.state.addChannelKey.length < 6) {
            alert('추가하고 싶은 Channel Key 를 정확히 입력해주세요.')
            return
        }


        this.setState({
            isNeedAddProgress: true
        })
        let result = await this.props.staticChannelStore.addStaticChannel(this.state.addChannelKey)
        this.setState({
            isNeedAddProgress: false
        })

        if (result.isSuccess) {
            alert('고정 채널 추가를 성공하였습니다.')
            this._searchStaticChannel()
        } else {
            console.error(result)
            alert('고정 채널 추가를 실패하였습니다. \ndata: ' + JSON.stringify(result.data) + '\nerror: ', JSON.stringify(result.error))
        }
    }


    render() {
        return (
            <div style={{padding : '20px'}}>

                {
                    this.state.isNeedSearchProgress ? (
                        <div>
                            Searching...
                        </div>
                    ) : (

                        <button className={'btn btn-primary btn-icon-split btn'}
                                onClick={() => this._onSearchButtonClicked()}>
                            <span className="icon text-white-50">
                                <i className="fas fa-arrow-right"></i>
                            </span>
                            <span className="text">현재 고정채널 조회</span>
                        </button>
                    )
                }

                <br/>
                <br/>

                <div className="card mb-4 py-3 border-left-primary">
                    <div className="card-body">

                        <strong>고정 채널 추가하기</strong>

                        <div>
                            <input type="text"
                                   className="form-control form-control-user"
                                   placeholder="Enter Channel Key"
                                   name={'addChannelKey'}
                                   style={{width:'100%'}}
                                   onChange={(e) => this._onValueChanged(e)} />
                        </div>
                        <br/>


                        {
                            this.state.isNeedAddProgress ? (
                                <div>
                                    Adding...
                                </div>
                            ) : (
                                <button className={'btn btn-primary btn-icon-split btn'}
                                        onClick={() => this._onAddButtonClicked()}>
                            <span className="icon text-white-50">
                                <i className="fas fa-arrow-right"></i>
                            </span>
                                    <span className="text">추가</span>
                                </button>
                            )
                        }

                    </div>
                </div>
                {process.env.NODE_ENV === 'development' && <DevTools />}
            </div>
        )
    }
}