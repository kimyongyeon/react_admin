import React from "react";
import ReactTable from "react-table";
import {inject, observer} from "mobx-react";
import ChannelInfo from "../channel/ChannelInfo";



@inject("staticChannelStore") @observer
export default class StaticChannelTable extends React.Component {

    constructor(props) {
        super(props)
        console.log('[StaticChannelTable] constructor')

        this.state = {
            isRemoving: false
        }
    }

    async _onRemoveButtonClicked(data) {
        console.log(data)

        this.setState({
            isRemoving: true
        })
        let result = await this.props.staticChannelStore.removeStaticChannel(data.channel_key)
        this.setState({
            isRemoving: false
        })

        if (result.isSuccess) {
            alert('고정 채널 제거를 성공하였습니다.')

            this.props.staticChannelStore.searchStaticChannel()
        } else {
            alert('고정 채널 제거를 실패하였습니다. ', result.data, ' / ', result.error)
        }
    }

    render() {
        console.log('[StaticChannelTable] render')

        const store = this.props.staticChannelStore
        const data = store.staticChannelResults

        return (
            <ReactTable
                data={data}
                columns={[
                    {
                        expander: true
                    },
                    {
                        Header: "고정 시간",
                        Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                        width: 190,
                        id: "modifyTime",
                        accessor: d => d.pick_time
                    },
                    {
                        Header: "채널 key",
                        Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                        id: "channelKey",
                        accessor: d => d.channel_key
                    },
                    {
                        Header: "채널 이름",
                        Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                        id: "title",
                        accessor: d => d.title
                    },
                    {
                        Header: "제거하기",
                        Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                        width: 90,
                        id: "remove",
                        accessor: d =>
                            <button className={'btn btn-primary btn-icon-split btn-sm'}
                                    onClick={() => this._onRemoveButtonClicked(d)}>
                                <span className="text">제거하기</span>
                            </button>
                    }
                ]}
                SubComponent={row => {
                    const rowData = data[row.index]
                    return (
                        <ChannelInfo channelKey={rowData.channel_key} />
                    );
                }}
                defaultSorted={ [
                    { id: "modifyTime", desc: true }
                ] }
                defaultPageSize={20}
                loading={this.state.isRemoving}
                className={"-striped -highlight"}
            />
        )
    }
}