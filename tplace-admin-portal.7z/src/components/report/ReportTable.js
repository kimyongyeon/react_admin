
import React from "react";
import {inject, observer} from "mobx-react";
import ReactTable from "react-table";
import 'react-table/react-table.css'

import 'startbootstrap-sb-admin-2/css/sb-admin-2.css'
import ReportAdmin from './ReportAdmin'
import {REPORT_STATUS, REPORT_TARGET, statusStringToStatus, targetStringToTarget} from "./ReportConst";
import {TABLE_CONST} from "../common/Const";
import ChannelInfo from "../channel/ChannelInfo";
import VideoInfo from "../video/VideoInfo";
import UserInfo from "../user/UserInfo";
import CommentInfo from "../comment/CommentInfo";


@inject("reportStore") @observer
export default class ReportTable extends React.Component {

    constructor(props){
        super(props)
        console.log('[ReportTable] constructor')

        this.state = {
            currentPage: 0,
            isNextPageLoading: false,
        }
    }

    async _requestSearch(pageIndex) {
        this.setState({
            isNextPageLoading: true
        })
        let res = await this.props.reportStore.requestSearchReportWithPage(pageIndex)
        this.setState({
            isNextPageLoading: false
        })

        if (res.isSuccess) {
            this.setState({
                currentPage: pageIndex
            })
        } else {
            alert('조회를 실패하였습니다. \ndata: ' + JSON.stringify(res.data) + '\nerror: ', JSON.stringify(res.error))
        }
    }

    render() {
        console.log('[ReportTable] render')

        const reportStore = this.props.reportStore
        console.log('currentPage: ', this.state.currentPage)

        let data = []
        if (this.state.currentPage < reportStore.searchReportResults.length) {
            data = reportStore.searchReportResults[this.state.currentPage]

        } else if (this.state.currentPage > 0) {
            //result 값은 초기화되었고 currentPage 는 아니라면 0 으로 초기화해준다.
            this.setState({
                currentPage: 0
            })
        }

        console.log(data)

        return (
            <ReactTable
                manual
                data={data}
                columns={[
                    {
                        expander: true
                    },
                    {
                        Header: "시간",
                        id: "createTime",
                        width: 150,
                        accessor: d => d.create_time
                    },
                    {
                        Header: "신고자 ID",
                        id: "userId",
                        width: 150,
                        accessor: d => d.uid
                    },
                    {
                        Header: "진행상태",
                        id: "status",
                        Cell: row => (<div style={{ textAlign: "center" }}>{row.value}</div>),
                        width: 80,
                        accessor: d => REPORT_STATUS.PROPS[statusStringToStatus(d.status)].NAME
                    },
                    {
                        Header: "신고대상",
                        id: "target",
                        Cell: row => (<div style={{ textAlign: "center" }}>{row.value}</div>),
                        width: 80,
                        accessor: d => REPORT_TARGET.PROPS[targetStringToTarget(d.target)].NAME
                    },
                    {
                        Header: "컨텐츠Key",
                        id: "key",
                        width: 180,
                        accessor: d => d.key
                    },
                    {
                        Header: "자동차단여부",
                        id: "hitCensorship",
                        width: 130,
                        Cell: row => (<div style={{ textAlign: "center" }}>{row.value}</div>),
                        accessor: d => (
                            (d.hit_censorship != null) ? <p style={{color: '#ffffff', backgroundColor: '#d65544', fontWeight: 'bold'}}>true</p> : 'false'
                        )
                    },
                    {
                        Header: "신고내용",
                        id: "description",
                        accessor: d => d.description
                    }
                ]}
                className = { "-striped -highlight" }
                defaultSorted={ [
                    { id: "createTime", desc: true }
                ] }
                collapseOnSortingChange={ false }
                SubComponent={row => {
                    const rowData = data[row.index]
                    const type = targetStringToTarget(rowData.target)
                    const isChannel = type == REPORT_TARGET.CHANNEL
                    const isVideo = type == REPORT_TARGET.VIDEO
                    const isUser = type == REPORT_TARGET.USER
                    const isComment = type == REPORT_TARGET.COMMENT

                    return (
                        <div>
                            <ReportAdmin reportData={rowData} />

                            {
                                isChannel ? (
                                    <ChannelInfo channelKey={rowData.key} />
                                ) : null
                            }
                            {
                                isVideo ? (
                                    <VideoInfo videoKey={rowData.key} />
                                ) : null
                            }
                            {
                                isUser ? (
                                    <UserInfo userId={rowData.key} />
                                ) : null
                            }
                            {
                                isComment ? (
                                    <CommentInfo commentKey={rowData.key} />
                                ) : null
                            }
                        </div>
                    );
                }}
                showPageSizeOptions = {false}
                showPageJump = { false }
                defaultPageSize={ TABLE_CONST.REPORT.DEFAULT_SIZE }
                page={ this.state.currentPage }
                pages={ reportStore.searchResultPageSize }
                loading={ this.state.isNextPageLoading }
                onPageChange={(pageIndex) => {
                    console.log('onPageChange: ' + this.state.currentPage + '-> ' + pageIndex)
                    this._requestSearch(pageIndex)
                }}
            />
        )
    }
}

