
import React from "react";
import 'startbootstrap-sb-admin-2/css/sb-admin-2.css'
import ReportSearchCondition from "./ReportSearchCondition";
import ReportTable from './ReportTable'


export default class Report extends React.Component {

    render() {
        return (
            <div className="container-fluid">

                <h1 className="h3 mb-2 text-gray-800">
                    Reports
                </h1>

                <div className="card shadow mb-4">
                    <ReportSearchCondition/>

                    <div className="card-header py-3">
                        <h6 className="m-0 font-weight-bold text-primary">Results</h6>
                    </div>

                    <ReportTable/>

                </div>
            </div>
        );
    }
}

