import React from "react";

import 'startbootstrap-sb-admin-2/css/sb-admin-2.css'
import 'startbootstrap-sb-admin-2/js/sb-admin-2.min'

import {REPORT_STATUS, REPORT_TARGET, statusStringToStatus, targetStringToTarget} from "./ReportConst";
import {requestFunction} from "../../action/FirebaseFunctionAction";
import {requestSingleData} from "../../action/FirebaseStoreAction";


export default class ReportAdmin extends React.Component {

    componentDidMount() {
        this._onFetchTargetInfo()
    }

    constructor(props){
        super(props)
        console.log('[ReportAdmin] constructor')

        this.state = {
            reportStatus: statusStringToStatus(this.props.reportData.status),
            isInitCheckboxSelected: false,
            isBlockCheckboxSelected: false,
            adminComment: '',
            isRequesting: false,
            targetInfo: null
        }
    }

    _onStatusChanged(e) {
        console.log(e.target.name + ' to ' + e.target.value)
        this.setState({
            [e.target.name]: e.target.value,
            isInitCheckboxSelected: false,
            isBlockCheckboxSelected: false,
        })
        console.log(this.state)
    }

    _onValueChanged(e) {
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    _toggleCheckboxState(e) {
        console.log(e.target.name + ' to ' + e.target.checked)
        this.setState({
            [e.target.name]: e.target.checked
        })
        console.log(this.state)
    }

    async _onFetchTargetInfo() {
        let data = this.props.reportData
        let target = targetStringToTarget(data.target)
        if (target == null) {
            alert('발생하면 안되는 케이스입니다.. 뭐지?')
            console.error('발생하면 안됨! 신고문의가 아닌데 조회하기가 눌림')
            return
        }

        let name = REPORT_TARGET.PROPS[target].COLLECTION_NAME
        let targetKey = data.key

        let response = await requestSingleData(name, targetKey)
        if (response.isSuccess && response.data == null) {
            let targetName = REPORT_TARGET.PROPS[target].NAME
            alert('삭제된 ' + targetName + '입니다.')
            return
        }
        if (response.isSuccess == false) {
            let targetName = REPORT_TARGET.PROPS[target].NAME
            alert(targetName + '조회에 실패하였습니다.' + '\nerror: ', JSON.stringify(response.error))
            return
        }

        this.setState({
            targetInfo: response.data
        })
    }

    async _onSummitButtonClicked() {
        console.log('onSummitButtonClicked')

        if (!this._checkRequestAvailableCondition()) {
            return
        }

        const data = this.props.reportData
        let param = {
            'report_key' : data.report_key,
            'status' : REPORT_STATUS.PROPS[this.state.reportStatus].VALUE,
            'admin_comment' : this.state.adminComment,
            'force_censorship' : this.state.isBlockCheckboxSelected,
            'init_report' : this.state.isInitCheckboxSelected
        }

        this.setState({
            isRequesting: true
        })
        let result = await requestFunction('updateReport', param)
        this.setState({
            isRequesting: false
        })

        if (result.isSuccess) {
            alert('신고 관리에 성공하였습니다.')
        } else {
            alert('신고 관리에 실패하였습니다. \ndata: ' + JSON.stringify(result.data) + '\nerror: ', JSON.stringify(result.error))
        }
    }

    _checkRequestAvailableCondition() {
        const data = this.props.reportData
        const dataStatus = statusStringToStatus(data.status)
        //dataStatus check
        if (dataStatus == REPORT_STATUS.DONE) {
            alert('처리완료된 건의 경우 수정이 불가능합니다.')
            return
        }
        if (dataStatus == this.state.reportStatus) {
            alert('수정하시려면 신고 진행상태를 수정해주세요.')
            return
        }

        //state check
        if (this.state.adminComment.length == 0) {
            alert('운영자 Comment 를 남겨주세요.')
            return false
        }
        if (this.state.reportStatus != REPORT_STATUS.DONE && (this.state.isInitCheckboxSelected || this.state.isBlockCheckboxSelected)) {
            alert('초기화 동작 또는 차단 동작은 처리완료 상태에서만 가능합니다.')
            return
        }
        if (this.state.isInitCheckboxSelected && this.state.isBlockCheckboxSelected) {
            alert('초기화 버튼과 차단버튼이 모두 선택되어있습니다. 하나만 선택해주세요')
            return false
        }

        //select confirm
        if (this.state.isInitCheckboxSelected) {
            return confirm('정말 차단을 해제하고 신고 개수를 초기화 하시겠습니까?')
        }
        if (this.state.isBlockCheckboxSelected) {
            return confirm('정말 차단하시겠습니까?')
        }

        return true
    }


    render() {
        console.log('[ReportAdmin] render')

        const data = this.props.reportData

        return (
            <div style={{ padding: "20px" }}>
                <h5>관리하기</h5>

                <div className="card mb-4 py-3 border-left-primary">
                    <div className="card-body">

                        <strong>신고 내용</strong>
                        <div>
                            {data.description}
                        </div>
                        <br/>


                        <div>
                            {
                                this.state.targetInfo != null ? (
                                    <div>
                                        <strong>차단 상태</strong> - {
                                        this.state.targetInfo.censorship ? (
                                            <div>
                                                <strong style={{color: '#d65544', fontSize: 23}}>차단됨</strong>
                                                <br/>
                                                <br/>
                                            </div>
                                        ) : (
                                            <div>
                                                <strong style={{color: '#41c989', fontSize: 23}}>차단되지 않음</strong>
                                                <br/>
                                                <br/>
                                            </div>
                                        )
                                    }
                                    </div>
                                ) : (
                                    <div>
                                        <strong>현재 {REPORT_TARGET.PROPS[targetStringToTarget(data.target)].NAME} 차단 상태 조회하기</strong><br/>
                                        <button className={"btn btn-primary btn-icon-split btn-sm"}
                                                onClick={() => this._onFetchTargetInfo()} >
                                            <span className="text">조회하기</span>
                                        </button>
                                        <br/><br/>
                                    </div>
                                )
                            }
                        </div>



                        {
                            statusStringToStatus(data.status) == REPORT_STATUS.DONE ? null : (
                                <div>
                                    <strong>신고 진행상태 수정</strong>
                                    <div className="dropdown mb-4">
                                        <button className="btn btn-light dropdown-toggle"
                                                id="dropdownMenuButton"
                                                data-toggle="dropdown">
                                            {REPORT_STATUS.PROPS[this.state.reportStatus].NAME}
                                        </button>
                                        <div className="dropdown-menu animated--fade-in" aria-labelledby="dropdownMenuButton">

                                            {
                                                statusStringToStatus(data.status) == REPORT_STATUS.READY ? (
                                                    <button className='dropdown-item'
                                                            name={'reportStatus'}
                                                            value={REPORT_STATUS.PENDING}
                                                            onClick={(e) => this._onStatusChanged(e)}>{REPORT_STATUS.PROPS[REPORT_STATUS.PENDING].NAME}</button>
                                                ) : null
                                            }

                                            <button className='dropdown-item'
                                                    name={'reportStatus'}
                                                    value={REPORT_STATUS.DONE}
                                                    onClick={(e) => this._onStatusChanged(e)}>{REPORT_STATUS.PROPS[REPORT_STATUS.DONE].NAME}</button>
                                        </div>
                                    </div>
                                </div>
                            )
                        }



                        {
                            this.state.targetInfo && this.state.targetInfo.censorship
                            && statusStringToStatus(this.props.reportData.status) != REPORT_STATUS.DONE
                            && this.state.reportStatus == REPORT_STATUS.DONE ? (
                                <div>
                                    <strong>{REPORT_TARGET.PROPS[targetStringToTarget(data.target)].NAME} 차단 해제 & 신고 개수 초기화하기</strong>
                                    <div>
                                        <input
                                            type="checkbox"
                                            checked={this.state.isInitCheckboxSelected === true}
                                            name={"isInitCheckboxSelected"}
                                            onChange={(e) => this._toggleCheckboxState(e)}
                                        />
                                    </div>
                                    <br/>
                                </div>
                            ) : null
                        }


                        {
                            this.state.targetInfo && this.state.targetInfo.censorship == false
                            && statusStringToStatus(this.props.reportData.status) != REPORT_STATUS.DONE
                            && this.state.reportStatus == REPORT_STATUS.DONE ? (
                                <div>
                                    <strong>{REPORT_TARGET.PROPS[targetStringToTarget(data.target)].NAME} 차단하기</strong>
                                    <div>
                                        <input
                                            type="checkbox"
                                            checked={this.state.isBlockCheckboxSelected === true}
                                            name={"isBlockCheckboxSelected"}
                                            onChange={(e) => this._toggleCheckboxState(e)}
                                        />
                                    </div>
                                    <br/>
                                </div>
                            ) : null
                        }




                        <strong>운영자 Comment</strong>
                        <div>
                            {
                                statusStringToStatus(data.status) == REPORT_STATUS.DONE ? (
                                    <div>
                                        {data.admin_comment}
                                    </div>
                                ) : (
                                    <input type="text"
                                           className="form-control form-control-user"
                                           style={{width:'100%'}}
                                           name={'adminComment'}
                                           defaultValue={data.admin_comment}
                                           placeholder={'관리자이름과 사유를 기입해주세요. ex) 규민_폭력적인 컨텐츠'}
                                           onChange={(e) => this._onValueChanged(e)}
                                    />
                                )
                            }
                        </div>
                        <br/>

                        {
                            statusStringToStatus(data.status) == REPORT_STATUS.DONE ? null : (
                                <div>
                                {
                                    this.state.isRequesting ? (
                                        <div>
                                            Requesting...
                                        </div>
                                    ) : (
                                        <button className={"btn btn-primary btn-icon-split btn"}
                                                onClick={() => this._onSummitButtonClicked()} >
                                            <span className="text">수정</span>
                                        </button>
                                    )
                                }
                                </div>
                            )
                        }

                    </div>
                </div>
            </div>
        )
    }
}