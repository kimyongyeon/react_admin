
export const REPORT_STATUS = {
    ALL: 0,
    READY: 1,
    PENDING: 2,
    DONE: 3,

    PROPS: {
        0: {
            NAME: '전체',
            VALUE: 'all',
            STYLE: { }
        },
        1: {
            NAME: '처리대기',
            VALUE: 'ready',
            STYLE: {
                color: '#d65544',
                fontWeight: 'bold'
            }
        },
        2: {
            NAME: '판단보류',
            VALUE: 'pending',
            STYLE: {
                color: '#eec358',
                fontWeight: 'bold'
            }
        },
        3: {
            NAME: '처리완료',
            VALUE: 'done',
            STYLE: { }
        }
    }
}

export let statusStringToStatus = function(string) {
    for(let key in REPORT_STATUS.PROPS) {
        const prop = REPORT_STATUS.PROPS[key]
        if (prop.VALUE === string) {
            return key
        }
    }
    return null
}

export const REPORT_TARGET = {
    ALL: 0,
    CHANNEL: 1,
    VIDEO: 2,
    USER: 3,
    COMMENT: 4,

    PROPS: {
        0: {
            NAME: '전체',
            VALUE: 'all',
            COLLECTION_NAME: "all"
        },
        1: {
            NAME: '채널',
            VALUE: 'channel',
            COLLECTION_NAME: "channels"
        },
        2: {
            NAME: '영상',
            VALUE: 'video',
            COLLECTION_NAME: "videos"
        },
        3: {
            NAME: '사용자',
            VALUE: 'user',
            COLLECTION_NAME: "users"
        },
        4: {
            NAME: '댓글',
            VALUE: 'comment',
            COLLECTION_NAME: "comments"
        }
    }
}

export let targetStringToTarget = function(string) {
    for(let key in REPORT_TARGET.PROPS) {
        const prop = REPORT_TARGET.PROPS[key]
        if (prop.VALUE === string) {
            return key
        }
    }
    return null
}
