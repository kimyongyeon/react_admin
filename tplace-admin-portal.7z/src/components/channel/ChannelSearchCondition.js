import React from "react";
import {inject, observer} from "mobx-react";
import DevTools from 'mobx-react-devtools';

import 'react-datepicker/dist/react-datepicker.min.css'
import 'react-datepicker/dist/react-datepicker-cssmodules.min.css'
import DatePicker from "react-datepicker/es";
import moment from "moment";
import {getYmd} from "../../assets/js/util";



@inject("channelStore") @observer
export default class ChannelSearchCondition extends React.Component {

    timerId = null
    //1분에 한번씩 refresh
    AUTO_REFRESH_EXPIRE_SEC = 60

    constructor(props){
        super(props)

        console.log('[ChannelSearchCondition] constructor')

        const yesterday = new Date()
        yesterday.setDate(yesterday.getDate() - 1)

        this.state = {
            startDate: yesterday,
            endDate: new Date(),
            channelKey: '',
            userId: '',
            title: '',
            isSearching: false,
            isAutoRefresh: false,
            autoRefreshExpireSec: this.AUTO_REFRESH_EXPIRE_SEC
        };

        this.onEnterKeyPressed = this.onEnterKeyPressed.bind(this)
    }

    componentDidMount() {
        document.querySelector('#userInfo').addEventListener('keypress', this.onEnterKeyPressed)

        //최초 진입 시 기본 최신 날짜 검색
        this._onSearchButtonClicked()
    }

    componentWillUnmount() {
        document.querySelector('#userInfo').removeEventListener('keypress', this.onEnterKeyPressed)

        this._stopAutoRefresh()
        this.setState({
            isAutoRefresh: false
        })
    }

    onEnterKeyPressed(e) {
        let key = e.which || e.keyCode;
        if (key === 13) {
            this._onSearchButtonClicked()
        }
    }



    _onStartDateChanged(value) {
        this.setState({
            startDate: value
        })
    }

    _onEndDateChanged(value) {
        this.setState({
            endDate: value
        })
    }

    _onValueChanged(e) {
        console.log(e.target.value)

        this.setState({
            [e.target.name]: e.target.value
        })

        console.log(this.state)
    }

    async _onSearchButtonClicked() {
        if (!this.state.startDate || !this.state.endDate) {
            alert('날짜를 재설정해주세요')
            return
        }

        const start_ymd = getYmd(this.state.startDate)
        const end_ymd = getYmd(this.state.endDate)

        console.log('startDate: ', start_ymd)
        console.log('endDate: ', end_ymd)

        if (moment(end_ymd) - moment(start_ymd) < 0) {
            alert('시작날짜가 종료날짜보다 큽니다. 날짜를 재설정해주세요')
            return
        }


        if (this.state.userId.length > 0 && this.state.title.length > 0) {
            alert('UserId 또는 Title 하나만 입력해주세요.')
            return
        }

        this.setState({
            isSearching: true
        })

        await this.props.channelStore.requestSearchChannel({
            start_ymd : start_ymd,
            end_ymd : end_ymd,
            channel_key: this.state.channelKey,
            user_id: this.state.userId,
            title: this.state.title
        })

        this.setState({
            isSearching: false
        })
    }

    _onAutoRefreshButtonClicked() {
        const tobeAutoRefresh = !this.state.isAutoRefresh
        if (tobeAutoRefresh) {
            this._startAutoRefresh()
        } else {
            this._stopAutoRefresh()
        }

        this.setState({
            isAutoRefresh: tobeAutoRefresh
        })
    }

    _startAutoRefresh() {
        console.log('start auto refresh')

        this.timerId = setInterval(() => {

            const remainSec = this.state.autoRefreshExpireSec - 1

            this.setState({
                autoRefreshExpireSec : remainSec
            })

            if (remainSec < 1) {
                this.setState({
                    autoRefreshExpireSec : this.AUTO_REFRESH_EXPIRE_SEC
                })

                const current = new Date()
                if (this.state.endDate.getDate() != current.getDate()) {
                    console.log('date changed!')

                    const yesterday = new Date()
                    yesterday.setDate(yesterday.getDate() - 1)

                    this.setState({
                        startDate: yesterday,
                        endDate: current
                    })
                }

                this._onSearchButtonClicked()
            }

        }, 1000)
    }

    _stopAutoRefresh() {
        console.log('stop auto refresh')
        if (this.timerId != null) {
            console.log(this.timerId)
            clearInterval(this.timerId)
        }
        this.setState({
            autoRefreshExpireSec : this.AUTO_REFRESH_EXPIRE_SEC
        })
    }


    render() {
        console.log('[ChannelSearchCondition] render')

        return (
            <div>
                <a href="#collapseCardExample"
                   className="d-block card-header py-3"
                   data-toggle="collapse"
                   role="button"
                   aria-expanded="true"
                   aria-controls="collapseCardExample">
                    <h6 className="m-0 font-weight-bold text-primary">Search Condition</h6>
                </a>


                {/*Card Content - Collapse*/}
                <div className="collapse show" id="collapseCardExample">
                    <div className="card-body" id={'userInfo'}>

                        <h6>생성날짜</h6>
                        <DatePicker selected={this.state.startDate}
                                    dateFormat="YYYY-MM-dd"
                                    onChange={(v) => this._onStartDateChanged(v)} />
                        ~
                        <DatePicker selected={this.state.endDate}
                                    dateFormat="YYYY-MM-dd"
                                    onChange={(v) => this._onEndDateChanged(v)} />
                        <br/><br/>


                        <h6>Channel Key</h6>
                        <input type="text"
                               className="form-control form-control-user"
                               placeholder="Enter Channel Key"
                               name={'channelKey'}
                               onChange={(e) => this._onValueChanged(e)} />
                        <br/>

                        <h6>생성자 UserId</h6>
                        <input type="text"
                               className="form-control form-control-user"
                               placeholder="Enter User Id"
                               name={'userId'}
                               onChange={(e) => this._onValueChanged(e)} />
                        <br/>


                        <h6>채널 이름</h6>
                        <input type="text"
                               className="form-control form-control-user"
                               placeholder="Enter Title"
                               name={'title'}
                               onChange={(e) => this._onValueChanged(e)} />
                        <br/>

                        {/*Search*/}
                        {
                            this.state.isSearching ? (
                                <div className="text-right">
                                    Searching...
                                </div>
                            ) : (
                                <div className="text-right">
                                    <button className={'btn btn-primary btn-icon-split btn'}
                                            onClick={() => this._onSearchButtonClicked()}>
                            <span className="icon text-white-50">
                                <i className="fas fa-arrow-right"></i>
                            </span>
                                        <span className="text">Search</span>
                                    </button>
                                </div>
                            )
                        }


                        {/*자동갱신*/}
                        {
                            this.state.isAutoRefresh ? (
                                <div className="text-right">
                                    <br/>

                                    <button className="btn btn-success btn-icon-split"
                                            onClick={() => this._onAutoRefreshButtonClicked()}>
                    <span className="icon text-white-50">
                      <i className="fas fa-sync-alt">{'  ' + this.state.autoRefreshExpireSec}</i>
                    </span>
                                        <span className="text">AutoRefresh ON</span>
                                    </button>
                                </div>
                            ) : (
                                <div className="text-right">
                                    <br/>
                                    <button className="btn btn-light btn-icon-split"
                                            onClick={() => this._onAutoRefreshButtonClicked()}>
                    <span className="icon text-gray-600">
                      <i className="fas fa-check"></i>
                    </span>
                                        <span className="text">AutoRefresh OFF</span>
                                    </button>
                                </div>
                            )
                        }



                    </div>
                </div>
                {process.env.NODE_ENV === 'development' && <DevTools />}
            </div>
        );
    }
}

