
export const CONTENTS_CONST = {
    REPORT_CATEGORY: {
        HARMFUL: 'harmful',
        COPYRIGHT: 'copyright',
        PROFILE: 'profile',
        ETC: 'etc'
    },
    REPORT_TARGET: {
        CHANNEL: 'channel',
        VIDEO: 'video',
        USER: 'user'
    }
}