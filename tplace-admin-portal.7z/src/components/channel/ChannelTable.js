
import React from "react";
import {inject, observer} from "mobx-react";
import ReactTable from "react-table";
import 'react-table/react-table.css'
import 'startbootstrap-sb-admin-2/css/sb-admin-2.css'
import ContentAdmin from "./ContentAdmin";
import {CONTENTS_CONST} from "./ContentConst";
import {TABLE_CONST} from "../common/Const";
import ChannelInfo from "./ChannelInfo";



@inject("channelStore") @observer
export default class ChannelTable extends React.Component {

    constructor(props){
        super(props)
        console.log('[ChannelTable] constructor')

        this.state = {
            currentPage: 0,
            isNextPageLoading: false,
        }
    }


    async _requestSearch(pageIndex) {
        this.setState({
            isNextPageLoading: true
        })
        let res = await this.props.channelStore.requestSearchChannelWithPage(pageIndex)
        this.setState({
            isNextPageLoading: false
        })

        if (res.isSuccess) {
            this.setState({
                currentPage: pageIndex
            })
        } else {
            alert('조회를 실패하였습니다. \ndata: ' + JSON.stringify(res.data) + '\nerror: ', JSON.stringify(res.error))
        }
    }


    render() {
        console.log('[ChannelTable] render')

        const channelStore = this.props.channelStore
        console.log('currentPage: ', this.state.currentPage)

        let data = []
        if (this.state.currentPage < channelStore.searchChannelResults.length) {
            data = channelStore.searchChannelResults[this.state.currentPage]

        } else if (this.state.currentPage > 0) {
            //result 값은 초기화되었고 currentPage 는 아니라면 0 으로 초기화해준다.
            this.setState({
                currentPage: 0
            })
        }

        console.log(data)

        return (
            <ReactTable
                manual
                data={data}
                columns={[
                    {
                        expander: true
                    },
                    {
                        Header: "생성 시간",
                        id: "createTime",
                        accessor: d => d.create_time
                    },
                    {
                        Header: "생성자",
                        id: "userId",
                        accessor: d => (d.creator.nickname != null) ? d.creator.nickname : ""
                    },
                    {
                        Header: "채널 Key",
                        id: "key",
                        accessor: d => d.channel_key
                    },
                    {
                        Header: "타이틀",
                        id: "title",
                        accessor: d => d.title
                    }
                ]}
                className = { "-striped -highlight" }
                defaultSorted={ [
                    { id: "createTime", desc: false }
                ] }
                collapseOnSortingChange={ false }
                SubComponent={row => {
                    const rowData = data[row.index]
                    return (
                        <div>
                            <ChannelInfo channelKey={rowData.channel_key} />

                            <ContentAdmin contentType={CONTENTS_CONST.REPORT_TARGET.CHANNEL}
                                          contentKey={rowData.channel_key} />
                        </div>
                    );
                }}
                showPageSizeOptions = {false}
                showPageJump = { false }
                defaultPageSize={ TABLE_CONST.CHANNEL.DEFAULT_SIZE }
                page={ this.state.currentPage }
                pages={ channelStore.searchResultPageSize }
                loading={ this.state.isNextPageLoading }
                onPageChange={(pageIndex) => {
                    console.log('onPageChange: ' + this.state.currentPage + '-> ' + pageIndex)
                    this._requestSearch(pageIndex)
                }}
            />
        )
    }
}
