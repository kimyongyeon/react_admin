import React from "react";
import {requestData, requestSingleData} from "../../action/FirebaseStoreAction";
import FlexView from "react-flexview/lib/FlexView";
import ChannelPlayer from "./ChannelPlayer";


export default class ChannelInfo extends React.Component {

    constructor(props) {
        super(props)
        console.log('[ChannelInfo] constructor')

        this.state = {
            isRequesting: false,
            channelInfo: this.props.channelInfo,
            channelVideos: []
        }
    }

    showProgress() {
        this.setState({
            isRequesting: true
        })
    }

    hideProgress() {
        this.setState({
            isRequesting: false
        })
    }

    manageRequestFailCase(message) {
        this.hideProgress()
        alert(message)
    }

    async _requestChannelInfo() {
        const channelKey = this.props.channelKey

        let mustConditionList = {"match": {"channel_key": channelKey}}
        console.log(mustConditionList)


        this.showProgress()

        let channelResponse = await requestSingleData('channels', channelKey)
        if (channelResponse.isSuccess && channelResponse.data == null) {
            this.manageRequestFailCase('삭제된 채널입니다.')
            return
        }
        if (channelResponse.isSuccess == false) {
            this.manageRequestFailCase('채널 조회에 실패하였습니다.' + '\nerror: ', JSON.stringify(channelResponse.error))
            return
        }

        let channelInfo = channelResponse.data
        let videoResponse = await requestData('channel_videos', 'channel_key', '==', channelInfo.channel_key, 'link_time', 'desc')
        if (videoResponse.isSuccess == false) {
            this.manageRequestFailCase('채널 내 영상 조회에 실패하였습니다.' + '\nerror: ', JSON.stringify(channelResponse.error))
            return
        }

        console.log('requestChannelInfo result : \nchannelInfo : ' + channelInfo + '\nvideos : ' + videoResponse.list)
        this.hideProgress()
        this.setState({
            channelInfo: channelInfo,
            channelVideos: videoResponse.list
        })
    }


    render() {
        console.log('[ChannelInfo] render')

        let info = this.state.channelInfo
        let videos = this.state.channelVideos
        console.log('[ChannelInfo] render data: ', info)

        return (
            <div style={{padding: "20px"}}>
                <h5>채널 정보</h5>

                <div className="card mb-4 py-3 border-left-primary">
                        { (info == null) ? (
                            <div className={'card-body'}>
                                {
                                    this.state.isRequesting ? (
                                        <div>
                                            Requesting...
                                        </div>
                                    ) : (
                                        <button className={"btn btn-primary btn-icon-split btn"}
                                                onClick={() => this._requestChannelInfo()} >
                                            <span className="text">정보 조회하기</span>
                                        </button>
                                    )
                                }
                            </div>
                        ) : (
                            <div className={'card-body'}>

                                <FlexView grow={1}>

                                    <FlexView width={300}>
                                        <ChannelPlayer channelInfo={info}
                                                       videos={videos} />
                                    </FlexView>


                                    <FlexView column
                                              marginLeft={30}
                                              grow={1}>

                                        <div>
                                            <strong>타이틀</strong> - {info.title}
                                        </div>
                                        <div>
                                            <strong>생성시간</strong> - {info.create_time}
                                        </div>


                                        <br/>


                                        <div>
                                            <strong>Creator ID</strong> - {info.creator.uid}
                                        </div>
                                        <div>
                                            <strong>Creator Nickname</strong> - {info.creator.nickname}
                                        </div>
                                        <div>
                                            <strong>Creator Image</strong> - {
                                            (
                                                <img className="img-profile rounded-circle"
                                                     src={ info.creator.image_url.length > 0 ? info.creator.image_url : 'assets/img/image_profile_no_profile.png' }
                                                     style={{width:'50px', height:'50px'}}
                                                />
                                            )
                                        }
                                        </div>


                                        <br/>


                                        <div>
                                            <strong>고정 채널 여부</strong> - {info.admin_pick ? 'true' : 'false'}
                                        </div>


                                        <br/>


                                        <br/>

                                        <div>
                                            <strong>차단 상태</strong> - {
                                            info.censorship ? (
                                                <strong style={{color: '#d65544', fontSize: 23}}>차단됨</strong>
                                            ) : (
                                                <strong style={{color: '#41c989', fontSize: 23}}>차단되지 않음</strong>
                                            )
                                        }
                                        </div>

                                        <div>
                                            <strong>신고 개수</strong> - {info.report_count}
                                        </div>
                                        <br/>



                                        <div>
                                            <strong>참여자 수</strong> - {info.member_count}
                                        </div>

                                        <div>
                                            <strong>좋아요 수</strong> - {info.like_count}
                                        </div>

                                        <div>
                                            <strong>댓글 개수</strong> - {info.comment_count}
                                        </div>

                                        <div>
                                            <strong>영상 개수</strong> - {info.video_count}
                                        </div>
                                        <div>
                                            <strong>시청 시간</strong> - {info.play_amount}
                                        </div>
                                        <div>
                                            <strong>태그</strong> - {info.tags}
                                        </div>
                                    </FlexView>


                                </FlexView>
                            </div>
                        )}
                </div>

            </div>

        );

    }
}