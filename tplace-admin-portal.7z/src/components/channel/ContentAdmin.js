import React from "react";
import 'startbootstrap-sb-admin-2/css/sb-admin-2.css'
import 'startbootstrap-sb-admin-2/js/sb-admin-2.min'
import {CONTENTS_CONST} from "./ContentConst";
import {requestFunction} from "../../action/FirebaseFunctionAction";


export default class ContentAdmin extends React.Component {

    constructor(props){
        super(props)
        console.log('[ContentAdmin] constructor')

        this.state = {
            isNeedProgress: false,
            reportCategory: CONTENTS_CONST.REPORT_CATEGORY.ETC,
            reportComment: '',
        }
    }

    _onStateChanged(e) {
        this.setState({
            [e.target.name]: e.target.innerHTML
        })
    }

    _reportCommentChanged(event) {
        this.setState({
            reportComment: event.target.value
        })
    }

    _showProgress() {
        this.setState({
            isNeedProgress: true
        })
    }

    _hideProgress() {
        this.setState({
            isNeedProgress: false
        })
    }

    _clearState() {
        this.setState({
            reportCategory: CONTENTS_CONST.REPORT_CATEGORY.ETC,
            reportComment: '',
        })
    }

    async _onSummitButtonClicked() {
        if (this.state.reportComment.length == 0) {
            alert('신고 comment 를 입력해주세요.')
            return
        }

        const key = this.props.contentKey
        const type = this.props.contentType

        const param = {
            'category': this.state.reportCategory,
            'description': this.state.reportComment,
            'target' : type,
            'key' : key
        }

        console.log(param)

        this._showProgress()
        let result = await requestFunction('report', param)
        this._hideProgress()

        if (result.isSuccess) {
            alert('신고에 성공하였습니다.')
            this._clearState()
        } else {
            alert('신고에 실패하였습니다. \ndata: ' + JSON.stringify(result.data) + '\nerror: ', JSON.stringify(result.error))
        }
    }


    render() {
        console.log('[ContentAdmin] render')

        return (
            <div style={{ padding: "20px" }}>
                <h5>신고하기</h5>

                <div className="card mb-4 py-3 border-left-primary">
                    <div className="card-body">

                        <strong>신고 카테고리</strong>
                        <div className="dropdown mb-4">
                            <button className="btn btn-light dropdown-toggle"
                                    id="dropdownMenuButton"
                                    data-toggle="dropdown">
                                {this.state.reportCategory}
                            </button>
                            <div className="dropdown-menu animated--fade-in" aria-labelledby="dropdownMenuButton">
                                <button className='dropdown-item'
                                        name={'reportCategory'}
                                        onClick={(e) => this._onStateChanged(e)}>{CONTENTS_CONST.REPORT_CATEGORY.HARMFUL}</button>
                                <button className='dropdown-item'
                                        name={'reportCategory'}
                                        onClick={(e) => this._onStateChanged(e)}>{CONTENTS_CONST.REPORT_CATEGORY.COPYRIGHT}</button>
                                <button className='dropdown-item'
                                        name={'reportCategory'}
                                        onClick={(e) => this._onStateChanged(e)}>{CONTENTS_CONST.REPORT_CATEGORY.PROFILE}</button>
                                <button className='dropdown-item'
                                        name={'reportCategory'}
                                        onClick={(e) => this._onStateChanged(e)}>{CONTENTS_CONST.REPORT_CATEGORY.ETC}</button>
                            </div>
                        </div>


                        <strong>신고 Comment</strong>
                        <div>
                            <input type="text"
                                   className="form-control form-control-user"
                                   style={{width:'100%'}}
                                   placeholder={'관리자이름과 사유를 기입해주세요. ex) 규민_폭력적인 컨텐츠'}
                                   onChange={(e) => this._reportCommentChanged(e)}
                            />
                        </div>

                        <br/>

                        {
                            this.state.isNeedProgress ? (
                                <div>
                                    Reporting...
                                </div>
                            ) : (

                                <button className={"btn btn-primary btn-icon-split btn"}
                                        onClick={() => this._onSummitButtonClicked()} >
                                    <span className="text">신고하기</span>
                                </button>
                            )
                        }

                    </div>
                </div>

            </div>
        )
    }
}