import React from "react";
import FlexView from "react-flexview/lib/FlexView";
import ReactPlayer from 'react-player';
import { ViewPager, Frame, Track, View } from 'react-view-pager';


export default class ChannelPlayer extends React.Component {

    constructor(props) {
        super(props)

        this.state = {
            current: 0
        };
    }


    render() {
        const channelInfo = this.props.channelInfo
        const videos = this.props.videos

        return (
            <FlexView grow={1}>
                {channelInfo && videos.length > 0 ? (
                    <FlexView vAlignContent={'center'}>

                        <FlexView vAlignContent={'center'}
                                  style={{
                                      width:300,
                                      position:'absolute',
                                      zIndex:1,
                                      pointerEvents:'none'
                                  }}>

                            <FlexView onClick={() => this.track.prev()}
                                      style={{
                                          pointerEvents:'auto'
                                      }} >
                                {
                                    this.state.current === 0 ? (
                                        <img src={'/assets/img/arrow-l-disable.svg'}
                                             style={{width:39, height:64}} />
                                    ) : (
                                        <img src={'/assets/img/arrow-l-normal.svg'}
                                             style={{width:39, height:64}} />
                                    )
                                }
                            </FlexView>

                            <FlexView grow={1} />

                            <FlexView onClick={() => this.track.next()}
                                      style={{
                                          pointerEvents:'auto'
                                      }} >
                                {
                                    this.state.current === (videos.length - 1) ? (
                                        <img src={'/assets/img/arrow-r-disable.svg'}
                                             style={{width:39, height:64}} />
                                    ) : (
                                        <img src={'/assets/img/arrow-r-normal.svg'}
                                             style={{width:39, height:64}} />
                                    )
                                }
                            </FlexView>
                        </FlexView>



                        <FlexView column>
                            <ViewPager tag="main" >
                                <Frame className="frame" autoSize>
                                    <Track ref={(c) => {
                                               this.track = c;
                                           }}
                                           viewsToShow={1}
                                           className="track"
                                           onViewChange={(change) => {
                                               console.log('view changed');

                                               this.setState({
                                                   current:change[0]
                                               });
                                           }
                                           } >

                                        {videos.map((video,index) => {
                                            return (
                                                <View key={index}
                                                      style={{width:300, height:300}}
                                                      onClick={(e) => {
                                                          //채널을 swipe 할 때 클릭 이벤트가 발생해 영상이 재생되는 것을 막기 위함
                                                          e.preventDefault()
                                                      }} >
                                                    <ReactPlayer controls
                                                                 url={video.video_url}
                                                                 poster={video.preview_url}
                                                                 width={300}
                                                                 height={300} />
                                                </View>
                                            );
                                        })}
                                    </Track>
                                </Frame>
                            </ViewPager>


                            <FlexView column>
                                <div>
                                    <strong>createTime</strong> - {videos[this.state.current].create_time}
                                </div>
                                <div>
                                    <strong>title</strong> - {videos[this.state.current].title}
                                </div>
                                <div>
                                    <strong>linkKey</strong> - {videos[this.state.current].link_key}
                                </div>
                                <div>
                                    <strong>videoKey</strong> - {videos[this.state.current].video_key}
                                </div>
                                <div>
                                    <strong>Video Width</strong> - {videos[this.state.current].metadata.width}
                                </div>
                                <div>
                                    <strong>Video Height</strong> - {videos[this.state.current].metadata.height}
                                </div>
                                <div>
                                    <strong>Video Rotation</strong> - {videos[this.state.current].metadata.rotation}
                                </div>
                            </FlexView>


                        </FlexView>
                    </FlexView>

                ) : (
                    <FlexView column
                              vAlignContent={'center'}
                              hAlignContent={'center'}
                              grow={1}>
                        영상이 없습니다.
                    </FlexView>
                )}
            </FlexView>
        )
    }
}