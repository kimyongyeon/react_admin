
import React from "react";
import RegisterBanner from "./RegisterBanner";
import BannerLists from "./BannerLists";


export default class Banner extends React.Component {

    render() {
        return (
            <div className="container-fluid">

                <h1 className="h3 mb-2 text-gray-800">
                    Banners
                </h1>


                <div className="card shadow mb-4">
                    <RegisterBanner />

                    <div className="card-header py-3">
                        <h6 className="m-0 font-weight-bold text-primary">Lists</h6>
                    </div>

                    <BannerLists />

                </div>

            </div>
        );
    }
}

