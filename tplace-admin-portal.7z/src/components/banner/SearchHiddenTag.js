import React from "react";
import {requestFunction} from "../../action/FirebaseFunctionAction";
import {HashLoader} from "react-spinners";
import * as util from "../../assets/js/util";
import {requestSearch} from "../../action/SearchAction";
import {VIDEO_UNSAFE_LEVEL} from "../video/VideoConst";
import ReactPlayer from "react-player";
import VideoInfo from "../video/VideoInfo";
import ContentAdmin from "../channel/ContentAdmin";
import {CONTENTS_CONST} from "../channel/ContentConst";
import {TABLE_CONST} from "../common/Const";
import ReactTable from "react-table";


export default class SearchHiddenTag extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            hiddenTag: '',
            searchVideos: [],
            isRequesting: false
        }
    }

    _initState() {
        this.setState({
            hiddenTag: '',
            searchVideos: [],
            isRequesting: false
        })
    }

    _onValueChanged(e) {
        console.log(e.target.value)

        this.setState({
            [e.target.name]: e.target.value
        })

        console.log(this.state)
    }

    async _onSearchButtonClicked() {
        console.log('_onSearchButtonClicked')

        let hiddenTag = this.state.hiddenTag

        hiddenTag = util.replaceAll(hiddenTag, ' ', '')
        hiddenTag = util.removeSpecialCharacters(hiddenTag)

        let mustCondition = []
        let array = hiddenTag.split(',')
        array.forEach((string, index) => {
            let wildcard = {
                "wildcard" : {
                    'hidden_tags.keyword': '*' + string + '*'
                }
            }
            mustCondition.push(wildcard)
        })

        let res = await requestSearch('videos', mustCondition, 0, 1000)
        this._setSearchResult(res)
    }

    _setSearchResult(res) {
        console.log('_setSearchResult')
        res.list.forEach((item) => {
            item.create_time = util.getYmdtFromTime(item.create_time)
            console.log(item)
        })

        console.log('response: ', res.list)

        this.setState({
            searchVideos: res.list
        })
    }

    render() {
        console.log('[SearchHiddenTag] render')

        const data = this.state.searchVideos


        return (
            <div>
                <a href="#searchHiddenTag"
                   className="d-block card-header py-3"
                   data-toggle="collapse"
                   role="button"
                   aria-expanded="true"
                   aria-controls="collapseCardExample">
                    <h6 className="m-0 font-weight-bold text-primary">Search</h6>
                </a>


                {/*Card Content - Collapse*/}
                <div className="collapse show" id="searchHiddenTag">
                    <div className="card-body">

                        <strong>Hidden Hashtag</strong>
                        <div>
                            <input type="text"
                                   ref={"hiddenTagInput"}
                                   className="form-control form-control-user"
                                   placeholder="고양이, 애용이, 야옹, ..."
                                   name={'hiddenTag'}
                                   style={{width: '100%'}}
                                   onChange={(e) => this._onValueChanged(e)}/>
                        </div>
                        <br/>

                        {
                            this.state.isRequesting ? (
                                <div>
                                    <br/>
                                    <HashLoader sizeUnit={"px"}
                                                size={50}
                                                color={'#4362c9'}
                                                loading={true}
                                    />
                                    <br/>
                                    Requesting...
                                </div>
                            ) : (
                                <div className="text-right">
                                    <button className={'btn btn-primary btn-icon-split btn'}
                                            onClick={() => this._onSearchButtonClicked()}>
                            <span className="icon text-white-50">
                                <i className="fas fa-arrow-right"></i>
                            </span>
                                        <span className="text">Search</span>
                                    </button>
                                </div>
                            )
                        }

                        <hr/>


                        <ReactTable
                            data={data}
                            columns={[
                                {
                                    expander: true
                                },
                                {
                                    Header: "생성 시간",
                                    id: "createTime",
                                    accessor: d => d.create_time
                                },
                                {
                                    Header: "생성자",
                                    id: "userId",
                                    accessor: d => (d.creator.nickname != null) ? d.creator.nickname : ""
                                },
                                {
                                    Header: "컨텐츠Key",
                                    id: "key",
                                    accessor: d => d.video_key
                                },
                                {
                                    Header: "타이틀",
                                    id: "title",
                                    Cell : row => (<span title={row.value}>{row.value}</span>),
                                    accessor: d => d.title
                                },
                                {
                                    Header: "해시태그",
                                    id: "hashtag",
                                    Cell : row => (<span title={row.value}>{row.value}</span>),
                                    accessor: d => d.tags
                                },
                                {
                                    Header: "Hidden 해시태그",
                                    id: "hiddenHashtag",
                                    Cell : row => (<span title={row.value}>{row.value}</span>),
                                    accessor: d => d.hidden_tags
                                },
                                {
                                    Header: "Thumbnail",
                                    id: "thumbnail",
                                    accessor: (d) => <img src={d.preview_url}
                                                          style={{
                                                              width: 200,
                                                          }}/>
                                },
                                {
                                    Header: "동영상 재생",
                                    id: "contents",
                                    accessor: (video) =>
                                        <ReactPlayer controls
                                                     light
                                                     url={video.video_url}
                                                     width={200}
                                                     height={200}
                                        />
                                }
                            ]}
                            className = { "-striped -highlight" }
                            defaultSorted={ [
                                { id: "createTime", desc: false }
                            ] }
                            collapseOnSortingChange={ false }
                            SubComponent={row => {
                                const rowData = data[row.index]
                                return (
                                    <div>
                                        <VideoInfo videoInfo={rowData} />

                                        <ContentAdmin  contentType={CONTENTS_CONST.REPORT_TARGET.VIDEO}
                                                       contentKey={rowData.video_key} />
                                    </div>
                                );
                            }}
                            />

                    </div>
                </div>

            </div>

        )
    }
}