
import React from "react";
import 'startbootstrap-sb-admin-2/css/sb-admin-2.css'
import {getExtension} from "../../assets/js/util";
import '../../assets/css/filebox.css'
import {uploadFile} from "../../action/FirebaseStorageAction";
import {requestFunction} from "../../action/FirebaseFunctionAction";
import {HashLoader} from "react-spinners";



export default class RegisterBanner extends React.Component {


    constructor(props) {
        super(props)
        this.state = {
            targetHashtag: '',
            targetHiddenHashtag: '',
            bannerFile: null,
            isRequesting: false
        }
    }

    _initState() {
        this.setState({
            targetHashtag: '',
            targetHiddenHashtag: '',
            bannerFile: null,
            isRequesting: false
        })

        if (this.refs.targetHashtag != null) {
            this.refs.targetHashtag.value = ''
        }
        if (this.refs.targetHiddenHashtag != null) {
            this.refs.targetHiddenHashtag.value = ''
        }
    }


    _onValueChanged(e) {
        console.log(e.target.value)

        this.setState({
            [e.target.name]: e.target.value
        })

        console.log(this.state)
    }


    _checkUserEnvironment() {
        if (window.File && window.FileReader && window.FileList && window.Blob) {
            console.log('available env!')
        } else {
            alert('The File APIs are not fully supported in this browser.');
        }
    }

    _onBannerFileChanged(e) {
        console.log(e)
        const files = e.target.files
        if (files.length == 0 || files.length > 1) {
            this._manageUnavailableBannerFileCase('하나의 png 또는 jpg 파일을 선택해주세요')
            return
        }

        const file = files[0]
        console.log(file)

        const extension = getExtension(file.name)
        console.log(extension)
        if (extension != 'png' && extension != 'jpg' && extension != 'jpeg') {
            this._manageUnavailableBannerFileCase('png 또는 jpg 파일을 선택해주세요')
            return
        }
        if (!file.type.includes('image')) {
            this._manageUnavailableBannerFileCase('image type 의 파일을 선택해주세요.')
            return
        }

        console.log('right file!')

        this._checkBannerImageResolution(file)
    }

    _checkBannerImageResolution(file) {
        let reader = new FileReader()
        reader.onload = () => {

            let image = new Image()
            image.onload = () => {

                console.log('image width/height : ' + image.width + ' / ' + image.height)

                if (image.width == 984 && image.height == 234) {
                    this.setState({
                        bannerFile: file
                    })
                } else {
                    this._manageUnavailableBannerFileCase('image size 는 984 x 234 로 맞춰주세요')
                }

            }
            image.src = reader.result
        }

        reader.readAsDataURL(file)
    }


    _manageUnavailableBannerFileCase(message) {
        this.setState({
            bannerFile: null
        })
        alert(message)
    }

    async _onSendButtonClicked() {
        console.log('onSendButtonClicked')

        if (!this._checkRequestAvailableCondition()) {
            return
        }

        this.setState({
            isRequesting: true
        })

        let bannerURL = ''
        if (this.state.bannerFile != null) {

            let result = await uploadFile('admin', this.state.bannerFile, { contentType: 'image/png' })
            if (result.isSuccess == false) {
                this._manageUnavailableBannerFileCase('배너 파일 업로드에 실패하였습니다. 파일을 재첨부해주세요.')
                return
            }

            let data = result.data
            try {
                let url = await data.ref.getDownloadURL()
                console.log(url)

                if (url && url.length > 0) {
                    bannerURL = url
                } else {
                    this._manageUnavailableBannerFileCase('배너 파일 업로드는 성공했으나 download url 이 없습니다.. 파일을 재첨부해주세요.')
                    return
                }
            } catch (error) {
                this._manageUnavailableBannerFileCase('getDownloadURL 을 만드는데 실패하였습니다. ')
                return
            }
        }

        let response = await this._requestAddBanner(bannerURL)
        this.setState({
            isRequesting: false
        })

        if (response.isSuccess) {
            alert('저장에 성공하였습니다.')
            this._initState()
        } else {
            alert('저장에 실패하였습니다. \nerror: ', JSON.stringify(response.error))
        }
    }


    _checkRequestAvailableCondition() {
        const hashtag = this.state.targetHashtag
        const hiddenHashtag = this.state.targetHiddenHashtag

        if (hashtag.length == 0 && hiddenHashtag.length == 0) {
            alert('hashtag 또는 hiddenHashtag 를 입력해주세요.')
            return
        }

        const bannerFile = this.state.bannerFile
        if (bannerFile == null) {
            alert('banner file 을 첨부해주세요.')
            return
        }

        let alertMessage = '배너를 등록하시겠습니까?\n\n'
        alertMessage += 'target hashtag : ' + hashtag + '\n'
        alertMessage += 'target hidden hashtag : ' + hiddenHashtag + '\n'

        return confirm(alertMessage)
    }


    async _requestAddBanner(bannerURL) {
        let param = {
            'tags' : this.state.targetHashtag,
            'hidden_tags' : this.state.targetHiddenHashtag,
            'image_url' : bannerURL
        }
        console.log(param)

        return await requestFunction('addBanner', param)
    }


    render() {
        console.log('[RegisterBanner] render')


        return (
            <div>
                <a href="#collapseCardExample"
                   className="d-block card-header py-3"
                   data-toggle="collapse"
                   role="button"
                   aria-expanded="true"
                   aria-controls="collapseCardExample">
                    <h6 className="m-0 font-weight-bold text-primary">Register</h6>
                </a>


                {/*Card Content - Collapse*/}
                <div className="collapse show" id="collapseCardExample">
                    <div className="card-body">
                        <strong>Target Hashtag</strong>
                        <div>
                            <input type="text"
                                   ref={'targetHashtag'}
                                   className="form-control form-control-user"
                                   placeholder="고양이, 애용이, 야옹, ..."
                                   name={'targetHashtag'}
                                   style={{width:'100%'}}
                                   defaultValue={this.state.targetHashtag}
                                   onChange={(e) => this._onValueChanged(e)} />
                        </div>
                        <br/>

                        <strong>Target Hidden Hashtag</strong>
                        <div>
                            <input type="text"
                                   ref={'targetHiddenHashtag'}
                                   className="form-control form-control-user"
                                   placeholder="고양이, 애용이, 야옹, ..."
                                   name={'targetHiddenHashtag'}
                                   style={{width:'100%'}}
                                   defaultValue={this.state.targetHiddenHashtag}
                                   onChange={(e) => this._onValueChanged(e)} />
                        </div>
                        <br/>


                        <strong>Banner Image (984 X 234 Image)</strong>
                        <div>
                            <div className="filebox bs3-primary">
                                <input className="upload-name"
                                       value={this.state.bannerFile == null ? "파일선택" : this.state.bannerFile.name}
                                       disabled="disabled"/>
                                <label htmlFor="bannerFileName">업로드</label>

                                <input type="file"
                                       id="bannerFileName"
                                       className="upload-hidden"
                                       onClick={() => this._checkUserEnvironment()}
                                       onChange={(e) => this._onBannerFileChanged(e)} />
                            </div>
                        </div>

                        {
                            this.state.bannerFile != null ? (
                                <img src={URL.createObjectURL(this.state.bannerFile)}
                                     width={656}
                                     height={156} />
                            ) : null
                        }

                        <br/>

                        {
                            this.state.isRequesting ? (
                                <div>
                                    <br/>
                                    <HashLoader sizeUnit={"px"}
                                                size={50}
                                                color={'#4362c9'}
                                                loading={true}
                                    />
                                    <br/>
                                    Requesting...
                                </div>
                            ) : (
                                <div>
                                    <br/>
                                    <button className={'btn btn-primary btn-icon-split btn'}
                                            onClick={() => this._onSendButtonClicked()}>
                            <span className="icon text-white-50">
                                <i className="fas fa-save"></i>
                            </span>
                                        <span className="text">저장하기</span>
                                    </button>
                                </div>
                            )
                        }

                        <br />

                    </div>
                </div>

            </div>

        );
    }
}

