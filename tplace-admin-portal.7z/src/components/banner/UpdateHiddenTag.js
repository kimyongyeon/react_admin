import React from "react";
import {requestFunction} from "../../action/FirebaseFunctionAction";
import {HashLoader} from "react-spinners";


export default class UpdateHiddenTag extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            videoKey: '',
            targetHiddenHashtag: '',
            isRequesting: false
        }
    }

    _initState() {
        this.setState({
            videoKey: '',
            targetHiddenHashtag: '',
            isRequesting: false
        })

        if (this.refs.videoKeyInput != null) {
            this.refs.videoKeyInput.value = ''
        }
        if (this.refs.hiddenTagInput != null) {
            this.refs.hiddenTagInput.value = ''
        }
    }

    _onValueChanged(e) {
        console.log(e.target.value)

        this.setState({
            [e.target.name]: e.target.value
        })

        console.log(this.state)
    }

    async _onUpdateButtonClicked() {
        console.log('_onUpdateButtonClicked')

        if (!this._checkRequestAvailableCondition()) {
            return
        }

        let param = {
            'video_key' : this.state.videoKey,
            'hidden_tags' : this.state.targetHiddenHashtag,
        }
        console.log(param)

        this.setState({
            isRequesting: true
        })

        let response =  await requestFunction('updateVideoHiddenTags', param)

        this.setState({
            isRequesting: false
        })


        if (response.isSuccess) {
            alert('저장에 성공하였습니다.')
            this._initState()
        } else {
            alert('저장에 실패하였습니다. \nerror: ', JSON.stringify(response.error))
        }
    }

    _checkRequestAvailableCondition() {
        const videoKey = this.state.videoKey
        if (videoKey.length == 0) {
            alert('videoKey 를 입력해주세요.')
            return
        }

        let alertMessage = '업데이트 하시겠습니까?\n\n'
        alertMessage += 'videoKey : ' + videoKey + '\n'
        alertMessage += 'hidden hashtag : ' + this.state.targetHiddenHashtag + '\n'

        return confirm(alertMessage)
    }


    render() {
        console.log('[UpdateHiddenTag] render')

        return (
            <div>
                <a href="#collapseCardExample"
                   className="d-block card-header py-3"
                   data-toggle="collapse"
                   role="button"
                   aria-expanded="true"
                   aria-controls="collapseCardExample">
                    <h6 className="m-0 font-weight-bold text-primary">Update</h6>
                </a>


                {/*Card Content - Collapse*/}
                <div className="collapse show" id="collapseCardExample">
                    <div className="card-body">
                        <strong>VideoKey</strong>
                        <div>
                            <input type="text"
                                   ref={"videoKeyInput"}
                                   className="form-control form-control-user"
                                   placeholder="Enter VideoKey"
                                   name={'videoKey'}
                                   style={{width: '100%'}}
                                   onChange={(e) => this._onValueChanged(e)}/>
                        </div>
                        <br/>

                        <strong>Target Hidden Hashtag</strong>
                        <div>
                            <input type="text"
                                   ref={"hiddenTagInput"}
                                   className="form-control form-control-user"
                                   placeholder="고양이, 애용이, 야옹, ..."
                                   name={'targetHiddenHashtag'}
                                   style={{width: '100%'}}
                                   onChange={(e) => this._onValueChanged(e)}/>
                        </div>
                        <br/>


                        {
                            this.state.isRequesting ? (
                                <div>
                                    <br/>
                                    <HashLoader sizeUnit={"px"}
                                                size={50}
                                                color={'#4362c9'}
                                                loading={true}
                                    />
                                    <br/>
                                    Requesting...
                                </div>
                            ) : (
                                <button className={'btn btn-primary btn-icon-split btn'}
                                        onClick={() => this._onUpdateButtonClicked()}>
                            <span className="icon text-white-50">
                                <i className="fas fa-pen-square"></i>
                            </span>
                                    <span className="text">업데이트하기</span>
                                </button>
                            )
                        }

                        <br/>
                        <br/>

                    </div>
                </div>

            </div>

        )
    }
}