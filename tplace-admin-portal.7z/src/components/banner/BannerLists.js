import React from "react";
import {store} from "../../firebase";
import {HashLoader} from "react-spinners";
import {requestData} from "../../action/FirebaseStoreAction";
import * as util from "../../assets/js/util";
import ReactTable from "react-table";
import {requestFunction} from "../../action/FirebaseFunctionAction";



export default class BannerLists extends React.Component {

    bannerObserver = null

    constructor(props) {
        super(props)

        this.state = {
            isNeedSearchProgress: false,
            banners: [],
            isRemoving: false
        }
    }

    componentDidMount(){
        console.log('componentDidMount')
        this._searchBanner()
    }

    componentWillUnmount() {
        console.log('componentWillUnmount')
        this._unregisterObserver()
    }

    async _onRemoveButtonClicked(data) {
        console.log(data)

        let param = {
            'banner_key' : data.id
        }
        console.log(param)

        this.setState({
            isRemoving: true
        })
        let result = await requestFunction('removeBanner', param)
        this.setState({
            isRemoving: false
        })

        if (result.isSuccess) {
            alert('배너 제거를 성공하였습니다.')

            let banners = this.state.banners
            banners.splice(banners.findIndex(v => v.id === data.id), 1)
            console.log(banners)

            this.setState({
                banners: banners
            })
        } else {
            alert('배너 제거를 실패하였습니다. ', result.data, ' / ', result.error)
        }
    }


    async _searchBanner() {
        this.setState({
            isNeedSearchProgress: true
        })

        let reportResponse = await await requestData('banners',
            null, null, null,
            'create_time', 'desc',
            null)
        if (reportResponse && reportResponse.isSuccess) {
            console.log('banners get success! : ' + reportResponse.list.length)
            this.setState({
                banners: reportResponse.list
            })
        }
        this.setState({
            isNeedSearchProgress: false
        })

        let recentCreateTime = this._recentBannerCreateTime()
        this._registerObserver(recentCreateTime,(list) => {
            if (list.length > 0) {
                console.log('observer work!')
                this._unregisterObserver()
                this._searchBanner()
            }
        })
    }

    _recentBannerCreateTime() {
        let createTime = 0
        this.state.banners.forEach((item, index, array) => {
            if (createTime < item.create_time) {
                createTime = item.create_time
            }
        })
        return createTime
    }

    _registerObserver(createTime, callback) {
        let query = store.collection('banners')
            .orderBy('create_time','desc')
            .where('create_time', '>', createTime)

        let observer = query.onSnapshot((snapshot) => {
            console.log(name + " / " + snapshot.size)
            let list = [];
            snapshot.forEach((snap)=>{
                list.push(snap.data());
            })
            callback(list)
        }, (err) => {
            console.error(err)
            callback([])
        })

        this.bannerObserver = observer
    }

    _unregisterObserver() {
        console.log('unregister observer')
        if (this.bannerObserver != null) {
            let observer = this.bannerObserver
            observer()
        }

        this.bannerObserver = null
    }


    render() {
        return (
            <div style={{padding : '20px'}}>

                {
                    this.state.isNeedSearchProgress ? (
                        <div>
                            <br/>
                            <HashLoader sizeUnit={"px"}
                                        size={50}
                                        color={'#4362c9'}
                                        loading={true}
                            />
                            <br/>
                            Requesting...
                        </div>
                    ) : (
                        <div>

                            <ReactTable
                                data={this.state.banners}
                                columns={[
                                    {
                                        expander: true
                                    },
                                    {
                                        Header: "생성 시간",
                                        id: "createTime",
                                        width: 190,
                                        accessor: d => util.getYmdtFromTime(d.create_time)
                                    },
                                    {
                                        Header: "Tags",
                                        id: "tags",
                                        width: 160,
                                        accessor: d => d.tags
                                    },
                                    {
                                        Header: "HiddenTags",
                                        id: "hiddenTags",
                                        width: 160,
                                        accessor: d => (d.hidden_tags != null) ? d.hidden_tags : ""
                                    },
                                    {
                                        Header: "배너 이미지",
                                        Cell: row => (<div style={{ textAlign: "center" }}>{row.value}</div>),
                                        id: "bannerImage",
                                        accessor: d =>
                                            <img src={ d.image_url.length > 0 ? d.image_url : null }
                                                 style={{width:'246px', height:'59px'}} />
                                    },
                                    {
                                        Header: "제거하기",
                                        Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                                        width: 90,
                                        id: "remove",
                                        accessor: d =>
                                            <button className={'btn btn-primary btn-icon-split btn-sm'}
                                                    onClick={() => this._onRemoveButtonClicked(d)}>
                                                <span className="text">제거하기</span>
                                            </button>
                                    }
                                ]}
                                className = { "-striped -highlight" }
                                defaultSorted={ [
                                    { id: "createTime", desc: true }
                                ] }
                                collapseOnSortingChange={ false }
                                collapseOnDataChange={ false }
                                SubComponent={row => {
                                    const rowData = this.state.banners[row.index]
                                    return (
                                        <div>
                                            <div style={{padding: "20px"}}>
                                                <h5>배너 정보</h5>

                                                <div className="card mb-4 py-3 border-left-primary">
                                                    <div className="card-body">

                                                        <div>
                                                            <strong>Tags</strong> - {rowData.tags}
                                                        </div>

                                                        <div>
                                                            <strong>HiddenTags</strong> - {rowData.hidden_tags}
                                                        </div>

                                                        <div>
                                                            <strong>Image</strong>
                                                            <br/>
                                                            {
                                                                (
                                                                    <img src={ rowData.image_url.length > 0 ? rowData.image_url : null }
                                                                         style={{width:'656px', height:'156px'}}
                                                                    />
                                                                )
                                                            }
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    );
                                }}
                                loading={this.state.isRemoving}
                                defaultPageSize={ 5 }
                            />
                        </div>
                    )
                }

                <br/>
                <br/>



            </div>
        )
    }
}