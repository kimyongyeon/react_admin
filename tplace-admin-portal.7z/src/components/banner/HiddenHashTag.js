
import React from "react";
import UpdateHiddenTag from "./UpdateHiddenTag";
import SearchHiddenTag from "./SearchHiddenTag";

export default class HiddenHashTag extends React.Component {

    render() {
        return (
            <div className="container-fluid">

                <h1 className="h3 mb-2 text-gray-800">
                    Hidden HashTags
                </h1>

                <div className="card shadow mb-4">
                    <UpdateHiddenTag />

                    <SearchHiddenTag />
                </div>
            </div>
        );
    }
}

