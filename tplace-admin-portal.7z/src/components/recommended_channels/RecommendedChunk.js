import React from "react";
import {inject} from "mobx-react";
import RecommendedChannelTable from "./RecommendedChannelTable";
import RecommendedChannelInsertContainer from "./RecommendedChannelInsertContainer";
import {HashLoader} from "react-spinners";


@inject("recommendedChannelStore")
export default class RecommendedChunk extends React.Component {

    constructor(props) {
        super(props)
        console.log('[RecommendedChunk] constructor')

        this.state = {
            isNeedSearchProgress: false
        }
    }

    async _onRefreshChunkButtonClicked(chunkNumber) {
        this.setState({
            isNeedSearchProgress: true
        })
        await this.props.recommendedChannelStore.requestSearchChunk(chunkNumber)
        this.setState({
            isNeedSearchProgress: false
        })
    }

    render() {
        console.log('[RecommendedChunk] render')

        let chunkNumber = this.props.chunkNumber
        let data = this.props.channels


        return (
            <div style={{
                padding: 20
            }}>
                {
                    this.state.isNeedSearchProgress ? (
                        <HashLoader sizeUnit={"px"}
                                    size={50}
                                    color={'#4362c9'}
                                    loading={true}
                        />
                    ) : (
                        <button className="btn btn-light btn-icon-split"
                                onClick={() => this._onRefreshChunkButtonClicked(chunkNumber)}>
                            <span className="icon text-gray-600">
                              <i className="fas fa-sync-alt" />
                            </span>
                            <span className="text">Chunk Refresh</span>
                        </button>
                    )
                }

                <br/>
                <br/>

                {
                    chunkNumber == this.props.recommendedChannelStore.TRASH_CHUNK_NUMBER ? (
                        <h4 style={{
                            fontWeight: 'bold'
                        }}>
                            Chunk 쓰레기통
                        </h4>
                    ) : (
                        <h4 style={{
                            fontWeight: 'bold'
                        }}>
                            Chunk #{chunkNumber}
                        </h4>
                    )
                }

                <RecommendedChannelTable chunkNumber={chunkNumber}
                                         channels={data}/>

                <br/>

                <RecommendedChannelInsertContainer chunkNumber={chunkNumber} />

            </div>
        )
    }

}