import React from "react";
import {requestFunction} from "../../action/FirebaseFunctionAction";
import {inject} from "mobx-react";
import {HashLoader} from "react-spinners";


@inject("recommendedChannelStore")
export default class RecommendedChannelInsertContainer extends React.Component {

    constructor(props) {
        super(props)

        this.state = {
            addChannelKey: '',
            isNeedAddProgress: false
        }
    }


    _onValueChanged(e) {
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    async _onAddButtonClicked() {
        if (this.state.addChannelKey.length < 6) {
            alert('추가하고 싶은 Channel Key 를 정확히 입력해주세요.')
            return
        }


        let param = {
            'channel_key' : this.state.addChannelKey,
            'chunk_num' : this.props.chunkNumber
        }

        this.setState({
            isNeedAddProgress: true
        })
        let result = await requestFunction('addChunkChannel', param)
        this.setState({
            isNeedAddProgress: false
        })

        if (result.isSuccess) {
            alert('채널 추가를 성공하였습니다.')
            await this.props.recommendedChannelStore.requestSearchChunk(this.props.chunkNumber)
        } else {
            console.error(result)
            alert('채널 추가를 실패하였습니다. \ndata: ' + JSON.stringify(result.data) + '\nerror: ', JSON.stringify(result.error))
        }
    }

    render() {
        console.log('[RecommendedChannelInsertContainer] render')

        let chunkNumber = this.props.chunkNumber


        return (
            <div className="card mb-4 py-3 border-left-primary">
                <div className="card-body">

                    {
                        chunkNumber == this.props.recommendedChannelStore.TRASH_CHUNK_NUMBER ? (
                            <strong>Chunk 쓰레기통에 채널 추가하기</strong>
                        ) : (
                            <strong>Chunk #{chunkNumber} 에 채널 추가하기</strong>
                        )
                    }

                    <div>
                        <input type="text"
                               className="form-control form-control-user"
                               placeholder="Enter Channel Key"
                               name={'addChannelKey'}
                               style={{width:'100%'}}
                               onChange={(e) => this._onValueChanged(e)} />
                    </div>
                    <br/>


                    {
                        this.state.isNeedAddProgress ? (
                            <div>
                                <HashLoader sizeUnit={"px"}
                                            size={50}
                                            color={'#4362c9'}
                                            loading={true}
                                />
                                Adding...
                            </div>
                        ) : (
                            <button className={'btn btn-primary btn-icon-split btn'}
                                    onClick={() => this._onAddButtonClicked()}>
                            <span className="icon text-white-50">
                                <i className="fas fa-arrow-right"></i>
                            </span>
                                <span className="text">추가</span>
                            </button>
                        )
                    }

                </div>
            </div>
        )
    }
}