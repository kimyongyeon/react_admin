import React from "react";
import {inject, observer} from "mobx-react";
import RecommendedChunk from "./RecommendedChunk";


@inject("recommendedChannelStore") @observer
export default class TrashChunkChannelList extends React.Component {

    constructor(props) {
        super(props)
        console.log('[TrashChunkChannelList] constructor')
    }


    render() {
        console.log('[TrashChunkChannelList] render')

        let data = this.props.recommendedChannelStore.trashChunkResults

        return (
            <RecommendedChunk chunkNumber={this.props.recommendedChannelStore.TRASH_CHUNK_NUMBER}
                              channels={data} />
        )
    }

}