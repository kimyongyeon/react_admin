import {inject, observer} from "mobx-react";
import React from "react";
import FlexView from "react-flexview/lib/FlexView";


@inject("recommendedChannelStore") @observer
export default class BottomContainer extends React.Component {

    constructor(props) {
        super(props)

        this.state = {
            isNeedSearchProgress: false,
        }
    }

    async _onSearchMoreButtonClicked() {
        this._searchMoreRecommendedChannel()
    }

    async _searchMoreRecommendedChannel() {
        this.setState({
            isNeedSearchProgress: true
        })
        await this.props.recommendedChannelStore.requestSearchMoreRecommendedChannel()
        this.setState({
            isNeedSearchProgress: false
        })
    }


    render() {
        return (
            <div style={{padding : '20px'}}>

                {
                    this.state.isNeedSearchProgress ? (
                        <div>
                            Searching...
                        </div>
                    ) : (

                        <FlexView grow={1}
                        vAlignContent={'center'}
                        hAlignContent={'center'}>

                            <button className={'btn btn-light btn-icon-split'}
                                    onClick={() => this._onSearchMoreButtonClicked()}>
                            <span className="icon text-gray-600">
                                <i className="fas fa-arrow-down"></i>
                            </span>
                                <span className="text">다음 chunk 검색하기</span>
                            </button>
                        </FlexView>
                    )
                }

                <br/>

            </div>
        )
    }

}