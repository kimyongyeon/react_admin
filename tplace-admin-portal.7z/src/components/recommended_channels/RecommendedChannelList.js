import React from "react";
import {inject, observer} from "mobx-react";
import RecommendedChunk from "./RecommendedChunk";


@inject("recommendedChannelStore") @observer
export default class RecommendedChannelList extends React.Component {

    constructor(props) {
        super(props)
        console.log('[RecommendedChannelList] constructor')
    }


    render() {
        console.log('[RecommendedChannelList] render')

        let numbers = this.props.recommendedChannelStore.searchChunkNumbers
        let data = this.props.recommendedChannelStore.searchChunkResults

        return (
            <div>
                {
                    numbers.map((chunkNumber, i) => {
                        console.log(chunkNumber)

                        return (
                            <RecommendedChunk key={chunkNumber}
                                              chunkNumber={chunkNumber}
                                              channels={data[chunkNumber]} />
                        )
                    })
                }
            </div>
        )
    }

}