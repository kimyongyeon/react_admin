import React from "react";
import ChannelInfo from "../channel/ChannelInfo";
import ReactTable from "react-table";
import {requestFunction} from "../../action/FirebaseFunctionAction";
import {inject} from "mobx-react";



@inject("recommendedChannelStore")
export default class RecommendedChannelTable extends React.Component {

    constructor(props) {
        super(props)
        console.log('[RecommendedChannelTable] constructor')

        this.state = {
            isRemoving: false
        }
    }

    async _onRemoveButtonClicked(data) {
        console.log(data)

        let param = {
            'channel_key' : data.channel_key,
            'chunk_num' : this.props.chunkNumber
        }
        console.log(param)

        this.setState({
            isRemoving: true
        })
        let result = await requestFunction('removeChunkChannel', param)
        this.setState({
            isRemoving: false
        })

        if (result.isSuccess) {
            alert('고정 채널 제거를 성공하였습니다.')
            await this.props.recommendedChannelStore.requestSearchChunk(this.props.chunkNumber)
        } else {
            alert('고정 채널 제거를 실패하였습니다. ', result.data, ' / ', result.error)
        }
    }

    render() {
        console.log('[RecommendedChannelTable] render')

        let data = this.props.channels
        console.log(data)

        return (
            <div>
                <ReactTable
                    data={data}
                    columns={[
                        {
                            expander: true
                        },
                        {
                            Header: "생성자",
                            id: "userNickname",
                            width: 160,
                            accessor: d => (d.creator.nickname != null) ? d.creator.nickname : ""
                        },
                        {
                            Header: "채널 Key",
                            id: "key",
                            width: 190,
                            accessor: d => d.channel_key
                        },
                        {
                            Header: "채널 이름",
                            id: "title",
                            accessor: d => d.title
                        },
                        {
                            Header: "제거하기",
                            Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                            width: 90,
                            id: "remove",
                            accessor: d =>
                                <button className={'btn btn-primary btn-icon-split btn-sm'}
                                        onClick={() => this._onRemoveButtonClicked(d)}>
                                    <span className="text">제거하기</span>
                                </button>
                        }

                    ]}
                    className = { "-striped -highlight" }
                    defaultPageSize={5}
                    collapseOnSortingChange={ false }
                    loading={this.state.isRemoving}
                    SubComponent={row => {
                        const rowData = data[row.index]
                        return (
                            <ChannelInfo channelKey={rowData.channel_key} />
                        );
                    }}
                />
            </div>
        )
    }
}