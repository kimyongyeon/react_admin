import {inject, observer} from "mobx-react";
import React from "react";


@inject("recommendedChannelStore") @observer
export default class TopContainer extends React.Component {

    constructor(props) {
        super(props)

        this.state = {
            isNeedSearchProgress: false,
        }
    }

    componentDidMount(){
        this._searchRecommendedChannel()
    }

    async _onSearchButtonClicked() {
        this._searchRecommendedChannel()
    }

    async _searchRecommendedChannel() {
        this.setState({
            isNeedSearchProgress: true
        })
        await this.props.recommendedChannelStore.requestSearchRecommendedChannel()
        this.setState({
            isNeedSearchProgress: false
        })
    }


    render() {
        return (
            <div style={{padding : '20px'}}>

                {
                    this.state.isNeedSearchProgress ? (
                        <div>
                            Searching...
                        </div>
                    ) : (

                        <button className={'btn btn-primary btn-icon-split btn'}
                                onClick={() => this._onSearchButtonClicked()}>
                            <span className="icon text-white-50">
                                <i className="fas fa-arrow-right"></i>
                            </span>
                            <span className="text">현재 추천채널 조회</span>
                        </button>
                    )
                }

                <br/>

            </div>
        )
    }

}