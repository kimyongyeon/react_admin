

export const TABLE_CONST = {
    CHANNEL : {
        DEFAULT_SIZE: 10
    },
    VIDEO: {
        DEFAULT_SIZE: 10
    },
    USER: {
        DEFAULT_SIZE: 20
    },
    USER_COMMENT: {
        DEFAULT_SIZE: 10
    },
    REPORT: {
        DEFAULT_SIZE: 20
    },
    QUESTION: {
        DEFAULT_SIZE: 20
    },
    CHUNK_CHANNEL_COUNT: {
        DEFAULT_SIZE: 20
    },
    STATIC_CHANNEL: {
        DEFAULT_SIZE: 500
    }
}