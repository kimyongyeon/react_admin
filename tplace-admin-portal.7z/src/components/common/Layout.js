import React from 'react'

import FlexView from 'react-flexview';
import {inject, observer} from 'mobx-react';
import {Route, withRouter, Switch} from "react-router-dom";

import SignIn from '../auth/SignIn';
import Sidebar from "./Sidebar";
import Top from "./Top";

import {AUTH_CONST} from "../auth/AuthConst";
import {HashLoader} from "react-spinners";




@inject("appStore")
@observer
class Layout extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            selected: -1
        };
    }

    componentWillMount() {
        this.props.appStore.app.init()
        // this.props.reportStore.init()
        // this.props.questionStore.init()
        // this.props.channelStore.init()
        // this.props.videoStore.init()
        // this.props.userStore.init()
        // this.props.staticChannelStore.init()
        // this.props.recommendedChannelStore.init()
    }

    render() {
        console.log('layout render')

        const appStore = this.props.appStore.app

        const landingUrl = appStore.landingUrl ? appStore.landingUrl : 'http://localhost:3000/';

        if (appStore.authState == AUTH_CONST.STATE.NOT_DEFINED) {
            return (
                <FlexView column
                          grow={1}
                          hAlignContent={'center'}
                          vAlignContent={'center'}
                          width={window.innerWidth}
                          height={window.innerHeight} >
                    <HashLoader sizeUnit={"px"}
                                size={130}
                                color={'#4362c9'}
                                loading={true}
                    />
                    <br/>
                    Loading...
                </FlexView>
            )

        } else if (appStore.authState == AUTH_CONST.STATE.NOT_LOGIN) {
            return (
                <FlexView  grow={1}>
                    <SignIn />
                </FlexView>
            )

        } else {

            return (
                <FlexView column>
                    <Top/>
                    <FlexView grow={1}>

                        <Sidebar />

                        <FlexView column grow={1} >
                            <FlexView grow>
                                <iframe id="myIframe" src={landingUrl}  width="100%"   height="100%" frameBorder="0"  />
                            </FlexView>


                        </FlexView>
                    </FlexView>
                </FlexView>

            );
        }
    }
}

export default withRouter(Layout)