
import React from "react";

import 'startbootstrap-sb-admin-2/css/sb-admin-2.css'

import 'startbootstrap-sb-admin-2/vendor/jquery/jquery.min'
import 'startbootstrap-sb-admin-2/vendor/bootstrap/js/bootstrap.bundle.min'
import 'startbootstrap-sb-admin-2/vendor/jquery-easing/jquery.easing.min'
import 'startbootstrap-sb-admin-2/js/sb-admin-2.min'
import {inject, observer} from "mobx-react";
import FlexView from "react-flexview/lib/FlexView";
import {toJS} from "mobx";



export const PAGE_CONST = {
    HOME: 'main',
    REPORT: 'report',
    QUESTION: 'question',
    CHANNEL_LIST: 'channel_list',
    VIDEO_LIST: 'video_list',
    VIDEO_ALARM: 'video_alarm',
    FIND_USER: 'find_user',
    RECOMMENDED_CHANNELS: 'recommended_channels',
    SET_STATIC_CHANNEL: 'set_static_channel',
    REGISTER_PUSH: 'register_push',
    SEND_PUSH: 'send_push',
    BANNER: 'banner',
    HIDDEN_HASHTAG: 'hidden_hashtag'
}


@inject('appStore') @observer
export default class Sidebar extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            selected: -1
        };
    }

    _pushPage(menu) {
        console.log(menu);
        this.props.appStore.app.setAdminPage(menu.LANDING_URL);
    }

    render() {
        const menuList = toJS(this.props.appStore.app.menuList);
        console.log(menuList);
        return (
            <ul className="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

                {/*Sidebar - Brand*/}
                {
                    menuList.map((menu,index)=>{
                        let view = null;
                        console.log(menu);
                        if(!menu.CHILD_LIST){
                            view = (
                                <li className="nav-item" key={index}>
                                    <FlexView className="nav-link" vAlignContent={'center'}
                                              onClick={() => this._pushPage(menu)}
                                              style={{ cursor: "pointer" }}>
                                        <i className="fas fa-tag"></i>
                                        <span style={{marginLeft:5}}>{ menu.NAME} </span>
                                    </FlexView>
                                </li>
                            )
                        }
                        else{
                            let subMenuId = 'collapsePages'+menu.MENU_ID;
                            menu.CHILD_LIST.sort((a,b)=>{
                               return a.ORDER-b.ORDER;
                            });
                            console.log(menu.CHILD_LIST);
                            view = (
                                <li className="nav-item" key={index}>
                                    <a className="nav-link collapsed" href="#" data-toggle="collapse" data-target={'#'+subMenuId} aria-expanded="true" aria-controls={subMenuId}>
                                        <i className="fas fa-tag"></i>
                                        <span style={{marginLeft:5}}>{menu.NAME}</span>
                                    </a>
                                    <div id={subMenuId} className="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                                        <div className="bg-white py-2 collapse-inner rounded">
                                            {menu.CHILD_LIST.map((sub,index2)=>{
                                                return (
                                                    <FlexView className={"collapse-item"} key={index2}
                                                              onClick={() => this._pushPage(sub)}
                                                              style={{ cursor: "pointer" }}>
                                                        <span>{sub.NAME}</span>
                                                    </FlexView>
                                                );
                                            })}
                                        </div>
                                    </div>
                                </li>
                            )
                        }

                        return view;
                    })
                }


                {/*Divider*/}
                <hr className="sidebar-divider d-none d-md-block" />

            </ul>
        );
    }
}