

export const PUSH_TARGET = {
    ALL: 0,
    FILE: 1,
    VIRGIN_CHANNEL: 2,
    VIRGIN_VIDEO: 3,
    VIRGIN_LINK: 4,
    VIRGIN_COMMENT: 5,
    LONG_TIME_NO_SEE: 6,

    PROPS: {
        0: {
            NAME: '전체 사용자',
            VALUE: 'all'
        },
        1: {
            NAME: '파일 내 UID',
            VALUE: 'file'
        },
        2: {
            NAME: '채널 생성 무경험자',
            VALUE: 'virgin_channel'
        },
        3: {
            NAME: '영상 업로드 무경험자',
            VALUE: 'virgin_video'
        },
        4: {
            NAME: '링크 무경험자',
            VALUE: 'virgin_link'
        },
        5: {
            NAME: '댓글 생성 무경험자',
            VALUE: 'virgin_comment'
        },
        6: {
            NAME: '일정 기간 미접속자',
            VALUE: 'long_time_no_see'
        }

    }
}

export let targetStringToTarget = function(string) {
    for(let key in PUSH_TARGET.PROPS) {
        const prop = PUSH_TARGET.PROPS[key]
        if (prop.VALUE === string) {
            return key
        }
    }
    return null
}


export const PUSH_STATUS = {
    INIT: 0,
    TARGETING: 1,
    READY: 2,
    REQUEST: 3,
    SENDING: 4,
    DONE: 5,

    PROPS: {
        0: {
            NAME: '등록 후 대기',
            VALUE: 'init'
        },
        1: {
            NAME: '타켓 추출중',
            VALUE: 'targeting'
        },
        2: {
            NAME: '준비완료',
            VALUE: 'ready'
        },
        3: {
            NAME: '발송요청',
            VALUE: 'request'
        },
        4: {
            NAME: '발송 중',
            VALUE: 'sending'
        },
        5: {
            NAME: '완료',
            VALUE: 'done'
        },
    }
}

export let statusStringToStatus = function(string) {
    for(let key in PUSH_STATUS.PROPS) {
        const prop = PUSH_STATUS.PROPS[key]
        if (prop.VALUE === string) {
            return key
        }
    }
    return null
}



export const PUSH_TYPE = {
    HOME: 0,
    FEED: 1,
    ALARM: 2,
    MY: 3,
    USER: 4,
    CHANNEL_HOME: 5,
    CHANNEL_FIRST: 6,
    CHANNEL_VIDEO: 7,
    VIDEO: 8,
    CHANNEL_COMMENT: 9,
    CHANNEL_VIDEO_COMMENT: 10,
    VIDEO_COMMENT: 11,
    WEB_PAGE: 12,

    PROPS: {
        0: {
            NAME: '홈',
            VALUE: 'home',
            NEEDS: []
        },
        1: {
            NAME: '피드',
            VALUE: 'feed',
            NEEDS: []
        },
        2: {
            NAME: '알림',
            VALUE: 'alarm',
            NEEDS: []
        },
        3: {
            NAME: '마이페이지',
            VALUE: 'my',
            NEEDS: []
        },
        4: {
            NAME: '유저페이지',
            VALUE: 'user',
            NEEDS: ['user_key']
        },
        5: {
            NAME: '채널 홈',
            VALUE: 'channel_home',
            NEEDS: ['channel_key']
        },
        6: {
            NAME: '채널의 첫 영상',
            VALUE: 'channel_first',
            NEEDS: ['channel_key']
        },
        7: {
            NAME: '채널의 특정 영상',
            VALUE: 'channel_video',
            NEEDS: ['channel_key', 'video_key']
        },
        8: {
            NAME: '영상',
            VALUE: 'video',
            NEEDS: ['video_key']
        },
        9: {
            NAME: '채널 내 댓글',
            VALUE: 'channel_comment',
            NEEDS: ['channel_key', 'parent_comment_key', 'comment_key']
        },
        10: {
            NAME: '채널 내 영상 내 댓글',
            VALUE: 'channel_video_comment',
            NEEDS: ['channel_key', 'video_key', 'parent_comment_key', 'comment_key']
        },
        11: {
            NAME: '영상 내 댓글',
            VALUE: 'video_comment',
            NEEDS: ['video_key', 'parent_comment_key', 'comment_key']
        },
        12: {
            NAME: '웹페이지',
            VALUE: 'web_page',
            NEEDS: ['web_url']
        },
    }
}

