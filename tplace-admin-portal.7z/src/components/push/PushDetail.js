import React from "react";
import 'startbootstrap-sb-admin-2/css/sb-admin-2.css'
import {PUSH_STATUS, PUSH_TARGET, statusStringToStatus, targetStringToTarget} from "./PushConst";
import {requestFunction} from "../../action/FirebaseFunctionAction";
import {isDevelopment} from "../../assets/js/util";


export default class PushDetail extends React.Component {

    constructor(props) {
        super(props)
        console.log('[PushDetail] constructor')

        this.state = {
            isRequesting: false
        }
    }


    async _onSendButtonClicked() {
        console.log('onSendButtonClicked')

        const data = this.props.data
        console.log(data)

        if (statusStringToStatus(data.status) != PUSH_STATUS.READY) {
            alert('준비완료 상태의 push 만 보내기가 가능합니다.')
            return
        }

        let isConfirmed = confirm('정말 보내시겠습니까? 확인을 누르시면 이젠 되돌릴 수 없습니다.')
        if (!isConfirmed) {
            return
        }

        let param = {
            'push_key' : data.id
        }
        this.setState({
            isRequesting: true
        })
        let result = await requestFunction('requestSendPush', param)
        this.setState({
            isRequesting: false
        })

        if (result.isSuccess) {
            alert('Push 발송 요청을 성공하였습니다.')

        } else {
            alert('Push 발송 요청에 실패하였습니다. ', result.data, ' / ', result.error)
        }
    }


    async _onInitButtonClicked() {
        console.log('onInitButtonClicked')
        if (!isDevelopment()) {
            return
        }

        const data = this.props.data
        console.log(data)

        if (statusStringToStatus(data.status) != PUSH_STATUS.DONE) {
            alert('완료상태의 push 만 초기화가 가능합니다.')
            return
        }

        let isConfirmed = confirm('정말 초기화하시겠습니까?')
        if (!isConfirmed) {
            return
        }



        let param = {
            'push_key' : data.id
        }
        this.setState({
            isRequesting: true
        })
        let result = await requestFunction('resetPush', param)
        this.setState({
            isRequesting: false
        })

        if (result.isSuccess) {
            alert('Push 초기화 요청을 성공하였습니다.')

        } else {
            alert('Push 초기화 요청에 실패하였습니다. ', result.data, ' / ', result.error)
        }
    }


    render() {
        console.log('[PushDetail] render')

        const data = this.props.data

        return (
            <div style={{ padding: "20px" }}>
                <h5>Push 정보</h5>

                <div className="card mb-4 py-3 border-left-primary">

                    <div className="card-body">

                        <div>
                            <strong>[ Target ]</strong>
                            <br/>
                            {PUSH_TARGET.PROPS[targetStringToTarget(data.type)].NAME}
                        </div>
                        <br/>


                        <div>
                            <strong>[ Title ]</strong>
                            <br/>
                            {data.title}
                        </div>
                        <br/>


                        <div>
                            <strong>[ Message ]</strong>
                            <br/>
                            {data.message}
                        </div>
                        <br/>


                        <div>
                            <strong>[ Landing ]</strong>
                            <br/>
                            {JSON.stringify(data.landing)}
                        }
                        </div>


                        <br/>
                        <br/>

                        {
                            statusStringToStatus(data.status) == PUSH_STATUS.DONE ? (
                                <div>
                                    {
                                        isDevelopment() ? (
                                            <div>
                                                <button className={'btn btn-primary btn-icon-split btn-lg'}
                                                        onClick={() => this._onInitButtonClicked()}>
                            <span className="icon text-white-50">
                                <i className="fas fa-backward"></i>
                            </span>
                                                    <span className="text">초기화하기</span>
                                                </button>
                                            </div>
                                        ): null
                                    }
                                </div>
                            ) : (
                                <div>
                                    {
                                        this.state.isRequesting ? (
                                            <div>
                                                Requesting...
                                            </div>
                                        ) : (
                                            <div>

                                                <button className={'btn btn-primary btn-icon-split btn-lg'}
                                                        onClick={() => this._onSendButtonClicked()}>
                            <span className="icon text-white-50">
                                <i className="fab fa-telegram-plane"></i>
                            </span>
                                                    <span className="text">보내기</span>
                                                </button>

                                            </div>
                                        )
                                    }
                                    <br/>
                                </div>
                            )
                        }


                    </div>
                </div>

            </div>
        )
    }
}