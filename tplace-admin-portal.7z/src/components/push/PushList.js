
import React from "react";
import ReactTable from "react-table";
import 'react-table/react-table.css'
import 'startbootstrap-sb-admin-2/css/sb-admin-2.css'
import {PUSH_STATUS, PUSH_TARGET, statusStringToStatus, targetStringToTarget} from "./PushConst";
import PushDetail from "./PushDetail";
import * as util from "../../assets/js/util";



export default class PushList extends React.Component {

    constructor(props) {
        super(props)
        console.log('[PushList] constructor')

        this.state = {
            isRemoving: false
        }
    }

    async _onRemoveButtonClicked(data) {
        console.log('onRemoveButtonClicked')
        console.log(data)

        let status = statusStringToStatus(data.status)
        if (status > PUSH_STATUS.READY) {
            alert('준비완료 이전단계의 등록된 정보만 삭제가 가능합니다.')
            return
        }

        alert('준비중입니다.')
    }


    render() {
        const data = this.props.list
        return (
            <ReactTable
                data={data}
                columns={[
                    {
                        expander: true
                    },
                    {
                        Header: "생성 시간",
                        Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                        id: "createTime",
                        width: 200,
                        accessor: d => util.getYmdtFromTime(d.create_time)
                    },
                    {
                        Header: "PushKey",
                        Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                        id: "pushKey",
                        width: 200,
                        accessor: d => d.id
                    },
                    {
                        Header: "등록자 UID",
                        Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                        id: "uid",
                        width: 200,
                        accessor: d => d.uid
                    },
                    {
                        Header: "발신상태",
                        Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                        id: "status",
                        width: 90,
                        accessor: d => PUSH_STATUS.PROPS[statusStringToStatus(d.status)].NAME
                    },
                    {
                        Header: "Target",
                        Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                        id: "target",
                        width: 180,
                        accessor: d => (PUSH_TARGET.PROPS[targetStringToTarget(d.type)] != null) ?
                            PUSH_TARGET.PROPS[targetStringToTarget(d.type)].NAME : d.type
                    },
                    {
                        Header: "Title",
                        id: "title",
                        accessor: d => d.title
                    },
                    {
                        Header: "Message",
                        id: "message",
                        accessor: d => d.message
                    },
                    {
                        Header: "Param",
                        id: "param",
                        accessor: d => JSON.stringify(d.landing)
                    },
                ]}
                SubComponent={row => {
                    const rowData = data[row.index]
                    return (
                        <PushDetail data={rowData} />
                    );
                }}
                defaultSorted={ [
                    { id: "createTime", desc: true }
                ] }
                defaultPageSize={20}
                loading={this.state.isRemoving}
                className={"-striped -highlight"}
            />
        )
    }

}