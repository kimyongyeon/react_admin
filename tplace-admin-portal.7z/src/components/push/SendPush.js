
import React from "react";
import 'startbootstrap-sb-admin-2/css/sb-admin-2.css'
import PushList from "./PushList";
import {requestData} from "../../action/FirebaseStoreAction";
import FlexView from "react-flexview/lib/FlexView";
import {HashLoader} from "react-spinners";


export default class SendPush extends React.Component {

    constructor(props){
        super(props)
        console.log('[PushList] constructor')

        this.state = {
            isRequesting: false,
            pushes: []
        }
    }

    componentDidMount() {
        this._requestSearch()
    }


    async _requestSearch() {
        this.setState({
            isRequesting: true
        })
        let res = await requestData('pushes')
        this.setState({
            isRequesting: false
        })

        if (res.isSuccess) {
            this.setState({
                pushes: res.list
            })
        } else {
            alert('조회를 실패하였습니다. \ndata: ' + JSON.stringify(res.data) + '\nerror: ', JSON.stringify(res.error))
        }
    }

    render() {
        return (
            <div className={"container-fluid"}>

                <h1 className="h3 mb-2 text-gray-800">
                    Send Push
                </h1>
                {
                    this.state.isRequesting ? (
                        <FlexView column
                                  grow={1}
                                  hAlignContent={'center'}
                                  vAlignContent={'center'}
                                  width={'100%'}
                                  height={400} >
                            <HashLoader sizeUnit={"px"}
                                        size={50}
                                        color={'#4362c9'}
                                        loading={true}
                            />
                            <br/>
                            Loading...
                        </FlexView>
                    ) : (
                        <div className="card shadow mb-4">

                            <div style={{padding : '20px'}}>
                                <button className={'btn btn-primary btn-icon-split btn'}
                                        onClick={() => this._requestSearch()}>
                            <span className="icon text-white-50">
                                <i className="fas fa-arrow-right"></i>
                            </span>
                                    <span className="text">현재 Push 정보 조회</span>
                                </button>

                            </div>


                            <div className="card-header py-3">
                                <h6 className="m-0 font-weight-bold text-primary">Results</h6>
                            </div>

                            <PushList list={this.state.pushes}/>

                        </div>
                    )
                }
            </div>
        );
    }
}

