
import React from "react";
import 'startbootstrap-sb-admin-2/css/sb-admin-2.css'
import DevTools from "mobx-react-devtools";
import ReactTable from "react-table";
import {PUSH_TYPE, PUSH_EXAMPLE_DATA, PUSH_TARGET} from "./PushConst";
import {getExtension, removeExtension} from "../../assets/js/util";
import '../../assets/css/filebox.css'
import {uploadFile} from "../../action/FirebaseStorageAction";
import {requestFunction} from "../../action/FirebaseFunctionAction";
import Resizer from 'react-image-file-resizer';



export default class RegisterPush extends React.Component {


    constructor(props) {
        super(props)
        this.state = {
            target: PUSH_TARGET.ALL,
            userTargetFile: null,
            thumbnailFile: null,
            title: '',
            message: '',
            landingType: PUSH_TYPE.HOME,
            channelKey: '',
            videoKey: '',
            userKey: '',
            parentCommentKey: '',
            commentKey: '',
            webURL: '',
            isRequesting: false
        }
    }

    _initState() {
        this.setState({
            target: PUSH_TARGET.ALL,
            userTargetFile: null,
            title: '',
            message: '',
            landingType: PUSH_TYPE.HOME,
            channelKey: '',
            videoKey: '',
            userKey: '',
            parentCommentKey: '',
            commentKey: '',
            webURL: '',
            isRequesting: false
        })
    }


    _onValueChanged(e) {
        console.log(e.target.value)

        this.setState({
            [e.target.name]: e.target.value
        })

        console.log(this.state)
    }

    _onLandingTypeChanged(e) {
        console.log(e.target.value)

        this.setState({
            landingType: e.target.value,
            channelKey: '',
            videoKey: '',
            userKey: '',
            parentCommentKey: '',
            commentKey: '',
            webURL: '',
        })

        console.log(this.state)
    }

    _checkUserEnvironment() {
        if (window.File && window.FileReader && window.FileList && window.Blob) {
            console.log('available env!')
        } else {
            alert('The File APIs are not fully supported in this browser.');
        }
    }

    _onUserFileChanged(e) {
        console.log(e)
        const files = e.target.files
        if (files.length == 0 || files.length > 1) {
            this._manageUnavailableFileCase('하나의 csv 파일을 선택해주세요')
            return
        }

        const file = files[0]
        console.log(file)

        const extension = getExtension(file.name)
        console.log(extension)
        if (extension != 'csv') {
            this._manageUnavailableFileCase('csv 파일을 선택해주세요')
            return
        }

        console.log('right file!')
        this.setState({
            userTargetFile: file
        })
    }

    _manageUnavailableFileCase(message) {
        this.setState({
            userTargetFile: null
        })
        alert(message)
    }

    _onThumnailFileChanged(e) {
        console.log(e)
        const files = e.target.files
        if (files.length == 0 || files.length > 1) {
            this._manageUnavailableThumbnailFileCase('하나의 png 또는 jpg 파일을 선택해주세요')
            return
        }

        const file = files[0]
        console.log(file)

        const extension = getExtension(file.name)
        console.log(extension)
        if (extension != 'png' && extension != 'jpg' && extension != 'jpeg') {
            this._manageUnavailableThumbnailFileCase('png 또는 jpg 파일을 선택해주세요')
            return
        }
        if (!file.type.includes('image')) {
            this._manageUnavailableThumbnailFileCase('image type 의 파일을 선택해주세요.')
            return
        }

        console.log('right file!')

        this._checkThumbnailImageResolution(file)

    }

    _checkThumbnailImageResolution(file) {
        let reader = new FileReader()
        reader.onload = () => {

            let image = new Image()
            image.onload = () => {

                console.log('image width/height : ' + image.width + ' / ' + image.height)

                if (image.width < 144 || image.height < 144) {
                    this._manageUnavailableThumbnailFileCase('144 x 144 크기 이상의 파일을 선택해주세요.')
                    return
                }

                this._resizeThumnailImage(file)
            }
            image.src = reader.result
        }

        reader.readAsDataURL(file)
    }

    _resizeThumnailImage(file) {
        Resizer.imageFileResizer(
            file,
            144,
            144,
            'PNG',
            100,
            0,
            blob => {
                if (blob == null) {
                    this._manageUnavailableThumbnailFileCase('image resize 에 실패하였습니다.')
                    return
                }

                console.log(blob)

                let name = removeExtension(file.name) + '.png'
                console.log(name)

                let resized = new File([blob], name)
                if (resized == null) {
                    this._manageUnavailableThumbnailFileCase('image resize 에 실패하였습니다.')
                    return
                }

                console.log(resized)

                this.setState({
                    thumbnailFile: resized
                })
            },
            'blob'
        );
    }

    _manageUnavailableThumbnailFileCase(message) {
        this.setState({
            thumbnailFile: null
        })
        alert(message)
    }

    async _onSendButtonClicked() {
        console.log('onSendButtonClicked')

        if (!this._checkRequestAvailableCondition()) {
            return
        }

        this.setState({
            isRequesting: true
        })

        let userFilePath = ''
        if (this.state.userTargetFile != null) {
            let result = await uploadFile('admin', this.state.userTargetFile, { contentType: 'text/csv' })
            if (result.isSuccess == false) {
                this._manageUnavailableFileCase('파일 업로드에 실패하였습니다. 파일을 재첨부해주세요.')
                return
            }

            let data = result.data
            let fullPath = data.metadata.fullPath
            if (fullPath.length == 0) {
                this._manageUnavailableFileCase('파일 업로드는 성공했으나 fullPath 가 없습니다.. 파일을 재첨부해주세요.')
                return
            }
            userFilePath = fullPath
        }

        let thumbnailURL = ''
        if (this.state.thumbnailFile != null) {

            let result = await uploadFile('admin', this.state.thumbnailFile, { contentType: 'image/png' })
            if (result.isSuccess == false) {
                this._manageUnavailableThumbnailFileCase('썸네일 파일 업로드에 실패하였습니다. 파일을 재첨부해주세요.')
                return
            }

            let data = result.data
            try {
                let url = await data.ref.getDownloadURL()
                console.log(url)

                if (url && url.length > 0) {
                    thumbnailURL = url
                } else {
                    this._manageUnavailableThumbnailFileCase('썸네일 파일 업로드는 성공했으나 download url 이 없습니다.. 파일을 재첨부해주세요.')
                    return
                }
            } catch (error) {
                this._manageUnavailableThumbnailFileCase('getDownloadURL 을 만드는데 실패하였습니다. ')
                return
            }
        }

        let response = await this._requestAddPush(userFilePath, thumbnailURL)
        this.setState({
            isRequesting: false
        })

        if (response.isSuccess) {
            alert('저장에 성공하였습니다.')
            this._initState()
        } else {
            alert('저장에 실패하였습니다. \nerror: ', JSON.stringify(response.error))
        }
    }

    async _requestAddPush(filePath, thumbnailURL) {
        let param = {
            'type' : PUSH_TARGET.PROPS[this.state.target].VALUE,
            'user_file_path' : filePath,
            'thumbnail_url' : thumbnailURL,
            'message' : this.state.message,
        }
        if (this.state.title.length > 0) {
            param['title'] = this.state.title
        }

        let landing = {
            'type' : PUSH_TYPE.PROPS[this.state.landingType].VALUE
        }
        if (this.state.channelKey.length > 0) {
            landing['channel_key'] = this.state.channelKey
        }
        if (this.state.videoKey.length > 0) {
            landing['video_key'] = this.state.videoKey
        }
        if (this.state.userKey.length > 0) {
            landing['user_key'] = this.state.userKey
        }
        if (this.state.parentCommentKey.length > 0) {
            landing['parent_comment_key'] = this.state.parentCommentKey
        }
        if (this.state.commentKey.length > 0) {
            landing['comment_key'] = this.state.commentKey
        }
        if (this.state.webURL.length > 0) {
            landing['web_url'] = this.state.webURL
        }

        param['landing'] = landing
        console.log(param)

        return await requestFunction('addPush', param)
    }


    _checkRequestAvailableCondition() {
        const target = this.state.target
        if (target == PUSH_TARGET.FILE && this.state.userTargetFile == null) {
            alert('Push 대상이 파일이지만, 파일첨부가 되어있지 않습니다. 파일을 첨부해주세요.')
            return
        }

        const message = this.state.message
        if (message.length == 0) {
            alert('message 를 입력해주세요.')
            return
        }

        const needs = PUSH_TYPE.PROPS[this.state.landingType].NEEDS
        const isNeedUserKeyInput = needs.includes('user_key')
        const isNeedChannelKeyInput = needs.includes('channel_key')
        const isNeedVideoKeyInput = needs.includes('video_key')
        const isNeedCommentKeyInput = needs.includes('comment_key')
        const isNeedWebURLInput = needs.includes('web_url')

        if (isNeedUserKeyInput && this.state.userKey.length == 0) {
            alert('userKey 를 입력해주세요.')
            return
        }
        if (isNeedChannelKeyInput && this.state.channelKey.length == 0) {
            alert('channelKey 를 입력해주세요.')
            return
        }
        if (isNeedVideoKeyInput && this.state.videoKey.length == 0) {
            alert('videoKey 를 입력해주세요.')
            return
        }
        if (isNeedCommentKeyInput && this.state.commentKey.length == 0) {
            alert('commentKey 를 입력해주세요.')
            return
        }
        if (isNeedWebURLInput) {
            if (this.state.webURL.length == 0) {
                alert('webURL 를 입력해주세요.')
                return
            }
            if (!(this.state.webURL.startsWith("http://") || this.state.webURL.startsWith("https://"))) {
                alert('webURL 은 http:// 또는 https:// 로 시작해야합니다.')
                return
            }
        }

        let alertMessage = '아래 정보를 정말 저장하시겠습니까?\n\n'

        alertMessage += 'target : ' + PUSH_TARGET.PROPS[this.state.target].NAME + '\n'

        if (this.state.title.length > 0) {
            alertMessage += ('title : ' + this.state.title + '\n')
        }

        alertMessage += ('message : ' + message + '\n')
        alertMessage += ('landingType : ' + PUSH_TYPE.PROPS[this.state.landingType].VALUE + '\n')

        if (this.state.channelKey.length > 0) {
            alertMessage += ('channelKey : ' + this.state.channelKey + '\n')
        }
        if (this.state.videoKey.length > 0) {
            alertMessage += ('videoKey : ' + this.state.videoKey + '\n')
        }
        if (this.state.userKey.length > 0) {
            alertMessage += ('userKey : ' + this.state.userKey + '\n')
        }
        if (this.state.parentCommentKey.length > 0) {
            alertMessage += ('parentCommentKey : ' + this.state.parentCommentKey + '\n')
        }
        if (this.state.commentKey.length > 0) {
            alertMessage += ('commentKey : ' + this.state.commentKey + '\n')
        }
        if (this.state.webURL.length > 0) {
            alertMessage += ('webURL : ' + this.state.webURL + '\n')
        }
        return confirm(alertMessage)
    }


    render() {
        console.log('[RegisterPush] render')

        let exampleData = []
        for (let key in PUSH_TYPE.PROPS) {
            let data = PUSH_TYPE.PROPS[key]
            exampleData.push(data)
        }

        const needs = PUSH_TYPE.PROPS[this.state.landingType].NEEDS
        const isNeedUserKeyInput = needs.includes('user_key')
        const isNeedChannelKeyInput = needs.includes('channel_key')
        const isNeedVideoKeyInput = needs.includes('video_key')
        const isNeedParentCommentKeyInput = needs.includes('parent_comment_key')
        const isNeedCommentKeyInput = needs.includes('comment_key')
        const isNeedWebURLInput = needs.includes('web_url')



        return (
            <div className="container-fluid">

                <h1 className="h3 mb-2 text-gray-800">
                    Push
                </h1>

                <div className="card shadow mb-4">

                    <div style={{padding : '20px'}}>
                        <div className="card mb-4 py-3 border-left-primary">
                            <div className="card-body">
                                <strong>Landing Type, Param 예시</strong>
                                <br/>

                                <ReactTable
                                    data={exampleData}
                                    columns={[
                                        {
                                            Header: '화면',
                                            Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                                            id: "title",
                                            width: 150,
                                            accessor: d => d.NAME
                                        },
                                        {
                                            Header: 'Type',
                                            Cell: row => (<div style={{textAlign: "center"}}>{row.value}</div>),
                                            id: "type",
                                            width: 200,
                                            accessor: d => d.VALUE
                                        },
                                        {
                                            Header: "Required or Optional Param",
                                            id: "param",
                                            accessor: d => JSON.stringify(d.NEEDS)
                                        },
                                    ]}
                                    defaultPageSize={exampleData.length}
                                    className={"-striped -highlight"}
                                    showPagination={false} />

                            </div>
                        </div>

                        <br/>
                        <br/>

                        <h4>Push 정보 입력</h4>
                        <br/>

                        <div className="card mb-4 py-3 border-left-primary">
                            <div className="card-body">


                                <strong>대상</strong>
                                <br/>
                                <div className="dropdown mb-4">
                                    <button className="btn btn-light dropdown-toggle"
                                            type="button"
                                            id="dropdownMenuButton"
                                            data-toggle="dropdown"
                                            aria-haspopup="true"
                                            aria-expanded="false">
                                        {PUSH_TARGET.PROPS[this.state.target].NAME}
                                    </button>
                                    <div className="dropdown-menu animated--fade-in" aria-labelledby="dropdownMenuButton">
                                        <button className='dropdown-item'
                                                name={'target'}
                                                value={PUSH_TARGET.ALL}
                                                onClick={(e) => this._onValueChanged(e)}>{PUSH_TARGET.PROPS[PUSH_TARGET.ALL].NAME}</button>
                                        <button className='dropdown-item'
                                                name={'target'}
                                                value={PUSH_TARGET.FILE}
                                                onClick={(e) => this._onValueChanged(e)}>{PUSH_TARGET.PROPS[PUSH_TARGET.FILE].NAME}</button>
                                        <button className='dropdown-item'
                                                name={'target'}
                                                value={PUSH_TARGET.VIRGIN_CHANNEL}
                                                onClick={(e) => this._onValueChanged(e)}>{PUSH_TARGET.PROPS[PUSH_TARGET.VIRGIN_CHANNEL].NAME}</button>
                                        <button className='dropdown-item'
                                                name={'target'}
                                                value={PUSH_TARGET.VIRGIN_VIDEO}
                                                onClick={(e) => this._onValueChanged(e)}>{PUSH_TARGET.PROPS[PUSH_TARGET.VIRGIN_VIDEO].NAME}</button>
                                        <button className='dropdown-item'
                                                name={'target'}
                                                value={PUSH_TARGET.VIRGIN_LINK}
                                                onClick={(e) => this._onValueChanged(e)}>{PUSH_TARGET.PROPS[PUSH_TARGET.VIRGIN_LINK].NAME}</button>
                                        <button className='dropdown-item'
                                                name={'target'}
                                                value={PUSH_TARGET.VIRGIN_COMMENT}
                                                onClick={(e) => this._onValueChanged(e)}>{PUSH_TARGET.PROPS[PUSH_TARGET.VIRGIN_COMMENT].NAME}</button>
                                        <button className='dropdown-item'
                                                name={'target'}
                                                value={PUSH_TARGET.LONG_TIME_NO_SEE}
                                                onClick={(e) => this._onValueChanged(e)}>{PUSH_TARGET.PROPS[PUSH_TARGET.LONG_TIME_NO_SEE].NAME}</button>
                                    </div>
                                </div>


                                {
                                    this.state.target == PUSH_TARGET.FILE ? (
                                        <div>
                                            <strong>UID List 파일 첨부 (csv 파일 형식)</strong>
                                            <br/>
                                            <div>

                                                <div className="filebox bs3-primary">
                                                    <input className="upload-name"
                                                           value={this.state.userTargetFile == null ? "파일선택" : this.state.userTargetFile.name}
                                                           disabled="disabled"/>
                                                    <label htmlFor="filename">업로드</label>

                                                    <input type="file"
                                                           id="filename"
                                                           className="upload-hidden"
                                                           onClick={() => this._checkUserEnvironment()}
                                                           onChange={(e) => this._onUserFileChanged(e)} />
                                                </div>
                                            </div>
                                            <br/>
                                        </div>
                                    ) : null
                                }


                                <strong>Title</strong>
                                <div>
                                    <input type="text"
                                           className="form-control form-control-user"
                                           placeholder="Enter Title"
                                           name={'title'}
                                           style={{width:'100%'}}
                                           onChange={(e) => this._onValueChanged(e)} />
                                </div>
                                <br/>

                                <strong>Message</strong>
                                <div>
                                    <input type="text"
                                           className="form-control form-control-user"
                                           placeholder="Enter Message"
                                           name={'message'}
                                           style={{width:'100%'}}
                                           onChange={(e) => this._onValueChanged(e)} />
                                </div>
                                <br/>


                                <strong>Thumbnail (144px x 144px 이상) </strong>
                                <div>
                                    <div className="filebox bs3-primary">
                                        <input className="upload-name"
                                               value={this.state.thumbnailFile == null ? "파일선택" : this.state.thumbnailFile.name}
                                               disabled="disabled"/>
                                        <label htmlFor="thumbnailFileName">업로드</label>

                                        <input type="file"
                                               id="thumbnailFileName"
                                               className="upload-hidden"
                                               onClick={() => this._checkUserEnvironment()}
                                               onChange={(e) => this._onThumnailFileChanged(e)} />
                                    </div>
                                </div>

                                {
                                    this.state.thumbnailFile != null ? (
                                        <img className="img-profile rounded-circle"
                                             src={URL.createObjectURL(this.state.thumbnailFile)}
                                             width={144}
                                             height={144} />
                                    ) : null
                                }

                                <br/>
                                <br/>



                                <div className="card mb-4 py-3 border-left-primary">
                                    <div className="card-body">

                                        <h4>Landing Condition</h4>
                                        <br/>
                                        <br/>

                                        <h5>Landing Type</h5>
                                        <div className="dropdown mb-4">
                                            <button className="btn-lg btn-light dropdown-toggle"
                                                    type="button"
                                                    id="dropdownMenuButton"
                                                    data-toggle="dropdown"
                                                    aria-haspopup="true"
                                                    aria-expanded="false">
                                                {PUSH_TYPE.PROPS[this.state.landingType].VALUE}
                                            </button>
                                            <div className="dropdown-menu animated--fade-in" aria-labelledby="dropdownMenuButton">

                                                <button className='dropdown-item'
                                                        name={'landingType'}
                                                        value={PUSH_TYPE.HOME}
                                                        onClick={(e) => this._onLandingTypeChanged(e)}>{PUSH_TYPE.PROPS[PUSH_TYPE.HOME].VALUE}</button>
                                                <button className='dropdown-item'
                                                        name={'landingType'}
                                                        value={PUSH_TYPE.FEED}
                                                        onClick={(e) => this._onLandingTypeChanged(e)}>{PUSH_TYPE.PROPS[PUSH_TYPE.FEED].VALUE}</button>
                                                <button className='dropdown-item'
                                                        name={'landingType'}
                                                        value={PUSH_TYPE.ALARM}
                                                        onClick={(e) => this._onLandingTypeChanged(e)}>{PUSH_TYPE.PROPS[PUSH_TYPE.ALARM].VALUE}</button>
                                                <button className='dropdown-item'
                                                        name={'landingType'}
                                                        value={PUSH_TYPE.MY}
                                                        onClick={(e) => this._onLandingTypeChanged(e)}>{PUSH_TYPE.PROPS[PUSH_TYPE.MY].VALUE}</button>
                                                <button className='dropdown-item'
                                                        name={'landingType'}
                                                        value={PUSH_TYPE.USER}
                                                        onClick={(e) => this._onLandingTypeChanged(e)}>{PUSH_TYPE.PROPS[PUSH_TYPE.USER].VALUE}</button>
                                                <button className='dropdown-item'
                                                        name={'landingType'}
                                                        value={PUSH_TYPE.CHANNEL_HOME}
                                                        onClick={(e) => this._onLandingTypeChanged(e)}>{PUSH_TYPE.PROPS[PUSH_TYPE.CHANNEL_HOME].VALUE}</button>

                                                <button className='dropdown-item'
                                                        name={'landingType'}
                                                        value={PUSH_TYPE.CHANNEL_FIRST}
                                                        onClick={(e) => this._onLandingTypeChanged(e)}>{PUSH_TYPE.PROPS[PUSH_TYPE.CHANNEL_FIRST].VALUE}</button>
                                                <button className='dropdown-item'
                                                        name={'landingType'}
                                                        value={PUSH_TYPE.CHANNEL_VIDEO}
                                                        onClick={(e) => this._onLandingTypeChanged(e)}>{PUSH_TYPE.PROPS[PUSH_TYPE.CHANNEL_VIDEO].VALUE}</button>
                                                <button className='dropdown-item'
                                                        name={'landingType'}
                                                        value={PUSH_TYPE.VIDEO}
                                                        onClick={(e) => this._onLandingTypeChanged(e)}>{PUSH_TYPE.PROPS[PUSH_TYPE.VIDEO].VALUE}</button>
                                                <button className='dropdown-item'
                                                        name={'landingType'}
                                                        value={PUSH_TYPE.CHANNEL_COMMENT}
                                                        onClick={(e) => this._onLandingTypeChanged(e)}>{PUSH_TYPE.PROPS[PUSH_TYPE.CHANNEL_COMMENT].VALUE}</button>
                                                <button className='dropdown-item'
                                                        name={'landingType'}
                                                        value={PUSH_TYPE.CHANNEL_VIDEO_COMMENT}
                                                        onClick={(e) => this._onLandingTypeChanged(e)}>{PUSH_TYPE.PROPS[PUSH_TYPE.CHANNEL_VIDEO_COMMENT].VALUE}</button>
                                                <button className='dropdown-item'
                                                        name={'landingType'}
                                                        value={PUSH_TYPE.VIDEO_COMMENT}
                                                        onClick={(e) => this._onLandingTypeChanged(e)}>{PUSH_TYPE.PROPS[PUSH_TYPE.VIDEO_COMMENT].VALUE}</button>
                                                <button className='dropdown-item'
                                                        name={'landingType'}
                                                        value={PUSH_TYPE.WEB_PAGE}
                                                        onClick={(e) => this._onLandingTypeChanged(e)}>{PUSH_TYPE.PROPS[PUSH_TYPE.WEB_PAGE].VALUE}</button>
                                            </div>
                                        </div>

                                        <br/>


                                        <h5>Landing Parameters</h5>

                                        <br/>

                                        {
                                            needs.length == 0 ? (
                                                <h6>
                                                    No parameters are required.
                                                </h6>
                                            ) : null
                                        }

                                        {
                                            isNeedUserKeyInput ? (
                                                <div>
                                                    <strong>User Key</strong>
                                                    <div>
                                                        <input type="text"
                                                               className="form-control form-control-user"
                                                               placeholder="Enter User Key"
                                                               name={'userKey'}
                                                               style={{width:'100%'}}
                                                               onChange={(e) => this._onValueChanged(e)} />
                                                    </div>
                                                    <br/>
                                                </div>
                                            ) : null
                                        }

                                        {
                                            isNeedChannelKeyInput ? (
                                                <div>
                                                    <strong>Channel Key</strong>
                                                    <div>
                                                        <input type="text"
                                                               className="form-control form-control-user"
                                                               placeholder="Enter Channel Key"
                                                               name={'channelKey'}
                                                               style={{width:'100%'}}
                                                               onChange={(e) => this._onValueChanged(e)} />
                                                    </div>
                                                    <br/>
                                                </div>
                                            ) : null
                                        }

                                        {
                                            isNeedVideoKeyInput ? (
                                                <div>

                                                    <strong>Video Key</strong>
                                                    <div>
                                                        <input type="text"
                                                               className="form-control form-control-user"
                                                               placeholder="Enter Video Key"
                                                               name={'videoKey'}
                                                               style={{width:'100%'}}
                                                               onChange={(e) => this._onValueChanged(e)} />
                                                    </div>
                                                    <br/>
                                                </div>
                                            ) : null
                                        }

                                        {
                                            isNeedParentCommentKeyInput ? (
                                                <div>
                                                    <strong>Parent Comment Key (Optional)</strong>
                                                    <div>
                                                        <input type="text"
                                                               className="form-control form-control-user"
                                                               placeholder="Enter Parent Comment Key"
                                                               name={'parentCommentKey'}
                                                               style={{width:'100%'}}
                                                               onChange={(e) => this._onValueChanged(e)} />
                                                    </div>
                                                    <br/>
                                                </div>
                                            ) : null
                                        }

                                        {
                                            isNeedCommentKeyInput ? (
                                                <div>
                                                    <strong>Comment Key</strong>
                                                    <div>
                                                        <input type="text"
                                                               className="form-control form-control-user"
                                                               placeholder="Enter Comment Key"
                                                               name={'commentKey'}
                                                               style={{width:'100%'}}
                                                               onChange={(e) => this._onValueChanged(e)} />
                                                    </div>
                                                    <br/>
                                                </div>
                                            ) : null
                                        }

                                        {
                                            isNeedWebURLInput ? (
                                                <div>
                                                    <strong>Web URL</strong>
                                                    <div>
                                                        <input type="text"
                                                               className="form-control form-control-user"
                                                               placeholder="Enter Web URL"
                                                               name={'webURL'}
                                                               style={{width:'100%'}}
                                                               onChange={(e) => this._onValueChanged(e)} />
                                                    </div>
                                                </div>
                                            ) : null
                                        }

                                    </div>
                                </div>

                                <br/>

                                {
                                    this.state.isRequesting ? (
                                        <div>Requesting...</div>
                                    ) : (
                                        <button className={'btn btn-primary btn-icon-split btn-lg'}
                                                onClick={() => this._onSendButtonClicked()}>
                            <span className="icon text-white-50">
                                <i className="fas fa-save"></i>
                            </span>
                                            <span className="text">저장하기</span>
                                        </button>
                                    )
                                }

                                <br />
                            </div>
                        </div>
                    </div>
                </div>

                {process.env.NODE_ENV === 'development' && <DevTools />}
            </div>
        );
    }
}

