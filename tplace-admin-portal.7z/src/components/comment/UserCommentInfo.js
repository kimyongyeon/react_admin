
import React from "react";
import {requestData} from "../../action/FirebaseStoreAction";
import * as util from "../../assets/js/util";
import {TABLE_CONST} from "../common/Const";
import ReactTable from "react-table";



export default class UserCommentInfo extends React.Component {

    constructor(props) {
        super(props)
        console.log('[UserCommentInfo] constructor')

        this.state = {
            isRequesting: false,
            userComments: null
        }
    }

    async _requestUserCommentInfo() {

        this.setState({
            isRequesting: true
        })

        const userId = this.props.userId
        let commentResponse = await requestData('comments', 'uid', '==', userId, 'create_time', 'desc')
        if (commentResponse.isSuccess == false) {
            this.manageRequestFailCase('사용자 댓글 조회에 실패하였습니다.' + '\nerror: ', JSON.stringify(commentResponse.error))
            return
        }

        this.setState({
            isRequesting: false,
            userComments: commentResponse.list
        })
    }


    render() {
        console.log('[UserCommentInfo] render')

        let data = this.state.userComments
        console.log('[UserCommentInfo] render data: ', data)


        return (
            <div style={{ padding: "20px" }}>
                <h5>댓글 정보</h5>

                <div className="card mb-4 py-3 border-left-primary">

                    { (data == null) ? (
                        <div className={'card-body'}>
                            {
                                this.state.isRequesting ? (
                                    <div>
                                        Requesting...
                                    </div>
                                ) : (
                                    <button className={"btn btn-primary btn-icon-split btn"}
                                            onClick={() => this._requestUserCommentInfo()} >
                                        <span className="text">댓글 조회하기</span>
                                    </button>
                                )
                            }
                        </div>
                    ) : (
                        <div className="card-body">

                            <ReactTable
                                data={data}
                                columns={[
                                    {
                                        expander: true
                                    },
                                    {
                                        Header: "생성 시간",
                                        id: "createTime",
                                        width: 190,
                                        accessor: d => util.getYmdtFromTime(d.create_time)
                                    },
                                    {
                                        Header: "target",
                                        id: "target",
                                        width: 100,
                                        accessor: d => d.target
                                    },
                                    {
                                        Header: "target key",
                                        id: "targetKey",
                                        width: 190,
                                        accessor: d => d.target_key
                                    },
                                    {
                                        Header: "message",
                                        id: "message",
                                        accessor: d => d.message
                                    }
                                ]}
                                className = { "-striped -highlight" }
                                defaultSorted={ [
                                    { id: "createTime", desc: false }
                                ] }
                                collapseOnSortingChange={ false }
                                SubComponent={row => {
                                    const rowData = data[row.index]
                                    return (
                                        <div style={{ padding: "20px" }}>
                                            <strong>Target</strong>
                                            <div>
                                                {rowData.target}
                                            </div>
                                            <br/>

                                            <strong>Target Key</strong>
                                            <div>
                                                {rowData.target_key}
                                            </div>
                                            <br/>

                                            <strong>Message</strong>
                                            <div>
                                                {rowData.message}
                                            </div>
                                            <br/>
                                        </div>
                                    );
                                }}
                                defaultPageSize={ TABLE_CONST.USER_COMMENT.DEFAULT_SIZE }
                            />

                        </div>
                    )}
                </div>

            </div>

        );
    }
}