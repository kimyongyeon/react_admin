import React from "react";
import {REPORT_TARGET, targetStringToTarget} from "../report/ReportConst";
import {requestSingleData} from "../../action/FirebaseStoreAction";
import FlexView from "react-flexview/lib/FlexView";


export default class CommentInfo extends React.Component {

    constructor(props) {
        super(props)
        console.log('[CommentInfo] constructor')

        this.state = {
            isRequesting: false,
            commentInfo: null
        }
    }

    async _requestCommentInfo() {
        const commentKey = this.props.commentKey

        let mustConditionList = {"match": {"comment_key": commentKey}}
        console.log(mustConditionList)

        this.setState({
            isRequesting: true
        })
        let res = await requestSingleData('comments', commentKey)
        this.setState({
            isRequesting: false
        })

        if (res.isSuccess) {
            if (res.data != null) {
                this.setState({
                    commentInfo: res.data
                })
            } else {
                alert('삭제된 댓글입니다.')
            }
        } else {
            alert('조회를 실패하였습니다. \ndata: ' + JSON.stringify(res.data) + '\nerror: ', JSON.stringify(res.error))
        }
    }


    render() {
        console.log('[CommentInfo] render')

        const info = this.state.commentInfo
        console.log('[CommentInfo] render data : ', info)

        return (
            <div style={{padding: "20px"}}>
                <h5>댓글 정보</h5>

                <div className="card mb-4 py-3 border-left-primary">
                    {
                        (info == null) ? (
                            <div className={'card-body'}>
                                {
                                    this.state.isRequesting ? (
                                        <div>
                                            Requesting...
                                        </div>
                                    ) : (
                                        <button className={"btn btn-primary btn-icon-split btn"}
                                                onClick={() => this._requestCommentInfo()} >
                                            <span className="text">정보 조회하기</span>
                                        </button>
                                    )
                                }
                            </div>
                        ) : (
                            <div className={'card-body'}>

                                <div>
                                    <strong>댓글</strong> - {info.message}
                                </div>
                                <div>
                                    <strong>작성시간</strong> - {info.create_time}
                                </div>


                                <br />


                                <div>
                                    <strong>Creator ID</strong> - {info.creator.uid}
                                </div>
                                <div>
                                    <strong>Creator Nickname</strong> - {info.creator.nickname}
                                </div>
                                <div>
                                    <strong>Creator Image</strong> - {
                                    (
                                        <img className="img-profile rounded-circle"
                                             src={ info.creator.image_url.length > 0 ? info.creator.image_url : 'assets/img/image_profile_no_profile.png' }
                                             style={{width:'50px', height:'50px'}}
                                        />
                                    )
                                }
                                </div>

                                <br/>



                                <div>
                                    <strong>대상</strong> - { REPORT_TARGET.PROPS[targetStringToTarget(info.target)].NAME }
                                </div>
                                <div>
                                    <strong>대상 Key</strong> - {info.target_key}
                                </div>


                                <br/>

                                
                                <div>
                                    <strong>차단 상태</strong> - {
                                    info.censorship ? (
                                        <strong style={{color: '#d65544', fontSize: 23}}>차단됨</strong>
                                    ) : (
                                        <strong style={{color: '#41c989', fontSize: 23}}>차단되지 않음</strong>
                                    )
                                }
                                </div>


                                <div>
                                    <strong>신고 개수</strong> - {info.report_count}
                                </div>
                                <br/>



                                <div>
                                    <strong>좋아요 수</strong> - {info.like_count}
                                </div>

                            </div>
                        )
                    }
                </div>
            </div>
        )
    }
}