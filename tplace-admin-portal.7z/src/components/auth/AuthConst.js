
export const AUTH_CONST = {
    STATE: {
        NOT_DEFINED: 'not_defined',
        NOT_LOGIN: 'not_login',
        LOGIN: 'login'
    }
}