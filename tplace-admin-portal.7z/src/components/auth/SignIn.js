import {observer, inject} from 'mobx-react';
import {observable, action} from "mobx";
import React from 'react'
import 'startbootstrap-sb-admin-2/css/sb-admin-2.css'
import FlexView from 'react-flexview';
import {toJS} from "mobx";
import Modal from 'react-awesome-modal';
import { toast } from 'react-toastify';
import {RET_CODE} from '../../common/constants';

@inject("appStore") @observer
export default class SignIn extends React.Component {

    constructor(props) {
        super(props)

        this.state = {
            isModalOpen: false,
            signUpCheck : ''
        }
    }

    componentDidMount() {
        console.log('signin mounted');
        this.props.appStore.app.requestBranchList();
    }

    _onValueChanged(e) {
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    _openSignUpModal(){
        this.setState({isModalOpen:true, signUpCheck:''});
    }

    _closeSignUpModal(){
        this.setState({isModalOpen:false, signUpCheck:''});
    }


    _requestSignUp(){
        if(!this.state.signUpId){
            this.setState({
                signUpCheck:'아이디를 입력하여 주세요'
            });
            return;
        }

        if(!/^[A-Za-z][A-Za-z0-9]*$/.test(this.state.signUpId)){
            this.setState({
                signUpCheck:'영어+숫자 조합 작성하여주세요.'
            });
            return;
        }

        if(this.state.signUpId.length < 6 || this.state.signUpId.length > 14){
            this.setState({
                signUpCheck:'아이디는 6자 이상 14자 이하로 작성하여 주세요'
            });
            return;
        }

        if(!this.state.signUpName){
            this.setState({
                signUpCheck:'이름 입력하여 주세요'
            });
            return;
        }

        if(!this.state.signUpPassword){
            this.setState({
                signUpCheck:'비밀번호를 입력하여 주세요'
            });
            return;
        }

        if(this.state.signUpPassword.length < 8 || this.state.signUpPassword.length > 20){
            this.setState({
                signUpCheck:'비밀번호는 8자 이상 20자 이하로 작성하여 주세요'
            });
            return;
        }

        if(!this.state.signUpPassword){
            this.setState({
                signUpCheck:'비밀번호를 입력하여 주세요'
            });
            return;
        }

        if(this.state.signUpPassword !== this.state.signUpPassword2){
            this.setState({
                signUpCheck:'비밀번호가 일치하지 않습니다.'
            });
            return;
        }

        this.props.appStore.app.requestSignUp(this.state.signUpId, this.state.signUpPassword, this.state.signUpName, this._onSignUpComplete);

    }

    @action.bound
    _onSignUpComplete(retCode){
        console.log(retCode);
        if(retCode === RET_CODE.SUCCESS ){
            this._closeSignUpModal();

            toast("운영자 등록 요청이 되었습니다. 담당자에게 권한요청 해주세요.");
        }
        else if(retCode === RET_CODE.ALREADY_EXISTS_LOGIN_ID){
            this.setState({
                signUpCheck:'동일한 아이디가 존재합니다. 다른아이디로 다시 시도하여주세요.'
            });
        }
        else{
            this.setState({
                signUpCheck:'요청이 실패하였습니다. 다시 시도해주세요.'
            });
        }
    }

    _requestSignIn(){
        if(!this.state.loginId){
            toast("아이디를 입력하여주세요.");
            return;
        }
        if(!this.state.password){
            toast("패스워드를 입력하여주세요.");
            return;
        }
        let branchId = parseInt(this.state.branch);
        if(!branchId){
            toast("지점을 선택하여 주세요.");
            return;
        }

        this.props.appStore.app.requestSignIn(this.state.loginId, this.state.password, branchId, this._onSignInComplete);
    }

    @action.bound
    _onSignInComplete(retCode){
        console.log(retCode);
        if(retCode === RET_CODE.LOCKED_OPERATOR){
            toast("계정이 잠겨있습니다. 관리자에게 문의해주세요.");
        }
        else{
            toast('요청이 실패하였습니다. 다시 시도해주세요.');

        }
    }

    render() {

        let branches = toJS(this.props.appStore.app.branchList);

        return (
            <div className="container">

                <div className="row justify-content-center">
                    <div className="col-xl-10 col-lg-12 col-md-9">
                        <div className="card o-hidden border-0 shadow-lg my-5">
                            <div className="card-body p-0">
                                <div className="row">
                                    <div className="col-lg-6 d-none d-lg-block bg-login-image" />
                                    <div className="col-lg-6">
                                        <div className="p-5">
                                            <div className="text-center">
                                                <h1 className="h4 text-gray-900 mb-4">T Place Admin Login</h1>
                                            </div>
                                            <hr/>

                                                <FlexView grow column>
                                                    <FlexView vAlignContent={'center'} style={{marginBottom:20}}>
                                                        <FlexView className="h6" style={{width:120}}>
                                                            아이디
                                                        </FlexView>

                                                            <input type="text"
                                                                   className="form-control form-control-user"
                                                                   name={'loginId'} style={{imeMode:'disabled'}}
                                                                   onChange={(e) => this._onValueChanged(e)} />
                                                    </FlexView>

                                                    <FlexView vAlignContent={'center'} style={{marginBottom:20}}>
                                                        <FlexView className="h6" style={{width:120}}>
                                                            비밀번호
                                                        </FlexView>

                                                        <input type="password" style={{imeMode:'disabled'}}
                                                               className="form-control form-control-user"
                                                               name={'password'} style={{imeMode:'disabled'}}
                                                               onChange={(e) => this._onValueChanged(e)} />
                                                    </FlexView>

                                                    <FlexView style={{marginBottom:20}}>
                                                        <div className="input-group">
                                                            <select className="custom-select" id="inputGroupSelect01"  name={'branch'} onChange={(e) => this._onValueChanged(e)}>
                                                                <option defaultValue value={0}>지점선택</option>
                                                                {
                                                                    branches.map((branch,index)=>{
                                                                        return  <option value={branch.BRANCH_ID} key={index}>{branch.NAME}</option>

                                                                    })
                                                                }
                                                            </select>
                                                        </div>
                                                    </FlexView>
                                                    <button className={'btn btn-primary btn-icon-split btn'}
                                                            onClick={() => this._requestSignIn()}>
                                                        <span className="text">로그인</span>
                                                    </button>

                                                </FlexView>

                                            <hr/>
                                            <FlexView grow column  width={"100%"}>
                                                <button className={'btn btn-success btn-icon-split btn'}
                                                        onClick={() => this._openSignUpModal()}>
                                                    <span className="text">운영자 등록</span>
                                                </button>
                                            </FlexView>



                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <Modal
                    visible={this.state.isModalOpen} width="500" height="470" effect="fadeInDown" onClickAway={() => this._closeSignUpModal()}
                >
                    <div>
                        <div className="p-5">
                            <div className="text-center">
                                <h1 className="h4 text-gray-900 mb-4">운영자 등록</h1>
                            </div>
                            <hr/>

                            <FlexView grow column>
                                <FlexView vAlignContent={'center'} style={{marginBottom:20}}>
                                    <FlexView className="h6" style={{width:120}}>
                                        이름
                                    </FlexView>

                                    <input type="text"
                                           className="form-control form-control-user"
                                           name={'signUpName'}
                                           onChange={(e) => this._onValueChanged(e)} />
                                </FlexView>

                                <FlexView vAlignContent={'center'} style={{marginBottom:20}}>
                                    <FlexView className="h6" style={{width:120}}>
                                        아이디
                                    </FlexView>

                                    <input type="text"
                                           className="form-control form-control-user"
                                           name={'signUpId'}
                                           onChange={(e) => this._onValueChanged(e)} />
                                </FlexView>

                                <FlexView vAlignContent={'center'} style={{marginBottom:20}}>
                                    <FlexView className="h6" style={{width:120}}>
                                        비밀번호
                                    </FlexView>
                                        <input type="password"
                                           className="form-control form-control-user"
                                           name={'signUpPassword'} style={{imeMode:'disabled'}}
                                           onChange={(e) => this._onValueChanged(e)} />
                                </FlexView>

                                <FlexView vAlignContent={'center'} style={{marginBottom:20}}>
                                    <FlexView className="h6" style={{width:120}}>
                                        재입력
                                    </FlexView>
                                    <input type="password"
                                           className="form-control form-control-user"
                                           name={'signUpPassword2'}  style={{imeMode:'disabled'}}
                                           onChange={(e) => this._onValueChanged(e)} />
                                </FlexView>

                                <FlexView style={{color:'#aa2233', height:20, fontSize:14, marginLeft:90, marginBottom:40}} >
                                    {this.state.signUpCheck}
                                </FlexView>


                                <button className={'btn btn-primary btn-icon-split btn'}
                                        onClick={() => this._requestSignUp()}>
                                    <span className="text">요청</span>
                                </button>

                            </FlexView>
                        </div>
                    </div>
                </Modal>
            </div>
        )
    }

}


