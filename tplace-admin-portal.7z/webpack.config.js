const webpack = require('webpack');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');
const dotenv = require('dotenv');
const fs = require('fs'); // to check if the file exists
const path = require('path');
const register = require("babel-core/register");
const polyfill = require("babel-polyfill");
const HtmlWebpackPlugin = require('html-webpack-plugin');

const srcRoot = path.resolve(__dirname, 'src');



module.exports =  (env, argv)=>{
    console.log(argv.mode);

    const isDev = argv.mode == 'development';

    const currentPath = path.join(__dirname);

    // Create the fallback path (the production .env)
    const basePath = currentPath + '/.env';

    const envPath = basePath + '.' + argv.configName;
    const finalPath = fs.existsSync(envPath) ? envPath : basePath;
    const fileEnv = dotenv.config({ path: finalPath }).parsed;

    const envKeys = Object.keys(fileEnv).reduce((prev, next) => {
        prev[`process.env.${next}`] = JSON.stringify(fileEnv[next]);
        return prev;
    }, {});

    console.log(envKeys);

    return {
        entry: [
            'babel-polyfill',
            './src/index.js'
            ],
        module: {
            rules: [
                {
                    test: /\.(js|jsx)$/,
                    exclude: /node_modules/,
                    use: ['babel-loader']
                },
                {
                    test:/\.css$/,
                    use:['style-loader','css-loader']
                }
            ]
        },
        resolve: {
            extensions: ['*', '.js', '.jsx'],
            modules: [
                srcRoot,
                'node_modules'
            ]
        },
        performance: {
            hints: false
        },
        optimization: {
            splitChunks: {
                cacheGroups: {
                    vendor: {
                        test: /[\\/]node_modules[\\/]/,
                        name: 'vendor',
                        chunks: 'all',
                    }
                }
            }
        },
        output: {
            path: __dirname + '/dist',
            publicPath: '/',
            filename:  'js/[name].[hash].bundle.js',
            chunkFilename:  'js/[id].[chunkhash].chunk.js',
        },
        plugins: [
            new webpack.HotModuleReplacementPlugin(),
            new CleanWebpackPlugin(['dist']),
            new CopyWebpackPlugin([
                {from: './src/index.html'},
                {from: './src/assets', to: './assets'},
            ]),
            new HtmlWebpackPlugin({
                template: path.resolve(srcRoot, 'index.html'),
                chunksSortMode: 'dependency'
            }),
            new webpack.DefinePlugin(envKeys),
            new webpack.ProvidePlugin({
                $: 'jquery',
                jQuery: 'jquery'
            })
        ],
        devServer: {
            contentBase: './dist',
            port: 4040,
            historyApiFallback: true,
            hot: true,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*'
            }
        }
    }

};